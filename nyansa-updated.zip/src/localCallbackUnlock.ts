import type { PaidPlan } from './guestPayments'
import { verifyPaystack } from './paystackVerification'

export type CallbackUnlock = { reference: string; email: string; plan: PaidPlan; amount: number; currency: 'GHS'; user_id: string | null; environment: 'test' | 'live'; created_at: string; verified?: boolean }
const key = 'nyansa-callback-unlocks-v1'
export function readCallbackUnlocks(): CallbackUnlock[] {
  try { const value=JSON.parse(localStorage.getItem(key)||'[]'); return Array.isArray(value) ? value.filter((item:CallbackUnlock)=>item && typeof item.reference==='string' && ['premium_family_report','counselor_starter','counselor_pro'].includes(item.plan)) : [] } catch { return [] }
}
export function saveCallbackUnlock(item: CallbackUnlock) {
  if (item.verified !== true) throw new Error('An unverified callback cannot unlock access.')
  const entries=[item,...readCallbackUnlocks().filter(existing=>existing.reference!==item.reference)]
  localStorage.setItem(key,JSON.stringify(entries))
  window.dispatchEvent(new Event('nyansa:callback-unlock'))
}
export async function findVerifiedCallbackUnlock(plan: PaidPlan, userId: string | null, environment: 'test' | 'live') {
  const amounts: Record<PaidPlan, number> = { premium_family_report:2900,counselor_starter:40000,counselor_pro:90000 }
  const candidates = readCallbackUnlocks().filter(item=>item.verified===true && item.plan===plan && item.amount===amounts[plan] && item.currency==='GHS' && item.environment===environment && (item.user_id===null || item.user_id===userId) && (plan==='premium_family_report' || Date.parse(item.created_at)+90*86400000>Date.now()))
  let lastError: unknown = null
  for (const item of candidates) {
    try { await verifyPaystack({ reference:item.reference,email:item.email,plan:item.plan,amount:item.amount,user_id:item.user_id,partner_id:null,credits:null }); return item } catch (error) { lastError=error }
  }
  if (lastError) throw lastError
  return null
}
