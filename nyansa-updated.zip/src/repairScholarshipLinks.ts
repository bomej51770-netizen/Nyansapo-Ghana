const replacements: Record<string, string> = {
  'https://www.ashesi.edu.gh/admissions/financial-aid': 'https://ashesi.edu.gh/how-to-apply/',
  'https://www.berea.edu/admissions/international': 'https://www.berea.edu/admissions/admission-information/apply/checklist-items/international-faqs',
}

/** Repair outdated scholarship destinations rendered by the existing app bundle. */
export function repairScholarshipLinks() {
  const repair = () => {
    document.querySelectorAll<HTMLAnchorElement>('a[href]').forEach(link => {
      const replacement = replacements[link.href]
      if (replacement) link.href = replacement
    })
  }
  repair()
  const observer = new MutationObserver(repair)
  observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['href'] })
  return () => observer.disconnect()
}
