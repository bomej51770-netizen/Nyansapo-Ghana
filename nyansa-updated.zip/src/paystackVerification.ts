import { cloud } from './cloudProfile'

export type VerifyPaystackBody = { reference: string; email: string; plan: string; amount: number; user_id: string | null; partner_id: string | null; credits: number | null }
export async function verifyPaystack(body: VerifyPaystackBody): Promise<Record<string, unknown>> {
  if (!cloud) throw new Error('Payment verification is unavailable: Supabase is not configured.')
  const { data, error } = await cloud.functions.invoke('verify-paystack', { body })
  if (error) {
    let detail = error.message
    try { const response = (error as { context?: Response }).context; if (response && typeof response.clone === 'function') { const payload = await response.clone().json(); detail = payload?.error || payload?.message || detail } } catch { /* Retain the function error. */ }
    throw new Error(`Payment verification failed: ${detail || 'please try again.'}`)
  }
  if (data?.verified !== true) throw new Error(typeof data?.error === 'string' ? data.error : 'Paystack payment could not be verified. No access or credits were unlocked.')
  if (data.reference && data.reference !== body.reference) throw new Error('Payment verification returned a different reference. No access or credits were unlocked.')
  if (data.plan && data.plan !== body.plan) throw new Error('Payment verification returned a different plan. No access or credits were unlocked.')
  if (data.amount !== undefined && Number(data.amount) !== body.amount) throw new Error('Payment verification returned a different amount. No access or credits were unlocked.')
  if (data.user_id !== undefined && data.user_id !== body.user_id) throw new Error('Payment verification returned a different account. No access or credits were unlocked.')
  if (data.partner_id !== undefined && data.partner_id !== body.partner_id) throw new Error('Payment verification returned a different partner. No credits were unlocked.')
  if (data.credits !== undefined && data.credits !== body.credits) throw new Error('Payment verification returned a different credit bundle. No credits were unlocked.')
  return data as Record<string, unknown>
}
