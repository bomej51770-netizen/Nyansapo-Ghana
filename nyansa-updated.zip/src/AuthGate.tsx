import { useEffect, useRef, useState } from 'react'
import { cloud, restoreCloudProfile, useCloudProfile } from './cloudProfile'
import { pendingPaystackPlan, resumePaystackLocation } from './paymentResume'
import './auth.css'

const profileKey = 'nyansa-profile-v1'
const accountsKey = 'nyansa-local-handles-v1'
const activeKey = 'nyansa-active-handle-v1'

type LocalAccount = { salt: string; passwordHash: string; profile: string | null }
type LocalAccounts = Record<string, LocalAccount>

function readAccounts(): LocalAccounts {
  try { return JSON.parse(localStorage.getItem(accountsKey) || '{}') as LocalAccounts } catch { return {} }
}

async function hashPassword(password: string, salt: string) {
  const bytes = new TextEncoder()
  const key = await crypto.subtle.importKey('raw', bytes.encode(password), 'PBKDF2', false, ['deriveBits'])
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: bytes.encode(salt), iterations: 150000, hash: 'SHA-256' }, key, 256)
  return Array.from(new Uint8Array(bits), byte => byte.toString(16).padStart(2, '0')).join('')
}

function protectedPath() {
  return ['/match', '/results'].some(path => location.pathname === path || location.pathname.startsWith(path + '/'))
}

export default function AuthGate({ children }: { children: React.ReactNode }) {
  const [handle] = useState(() => localStorage.getItem(activeKey))
  const { ready, session, syncError } = useCloudProfile()
  const [protectedPage, setProtectedPage] = useState(protectedPath)
  const [mode, setMode] = useState<'create' | 'open'>(() => new URLSearchParams(window.location.search).get('checkout') === '1' && pendingPaystackPlan() ? 'open' : 'create')
  const [accountMethod, setAccountMethod] = useState<'handle' | 'email'>(() => new URLSearchParams(window.location.search).get('checkout') === '1' && pendingPaystackPlan() ? 'email' : 'handle')
  const [username, setUsername] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [message, setMessage] = useState('')
  const [busy, setBusy] = useState(false)
  const emailSubmitting = useRef(false)
  const resumeStarted = useRef(false)

  useEffect(() => {
    if (!ready || !session?.user.email || emailSubmitting.current || resumeStarted.current || !pendingPaystackPlan()) return
    if (window.location.pathname === '/' && new URLSearchParams(window.location.search).get('resume_checkout') === '1') return
    resumeStarted.current = true
    window.location.replace(resumePaystackLocation)
  }, [ready, session])

  useEffect(() => {
    const update = () => setProtectedPage(protectedPath())
    const push = history.pushState
    const replace = history.replaceState
    history.pushState = function (...args) { push.apply(this, args); update() }
    history.replaceState = function (...args) { replace.apply(this, args); update() }
    window.addEventListener('popstate', update)
    return () => { history.pushState = push; history.replaceState = replace; window.removeEventListener('popstate', update) }
  }, [])

  useEffect(() => {
    if (!handle || session) return
    const save = () => {
      const accounts = readAccounts()
      if (!accounts[handle]) return
      accounts[handle].profile = localStorage.getItem(profileKey)
      localStorage.setItem(accountsKey, JSON.stringify(accounts))
    }
    window.addEventListener('nyansa-profile', save)
    return () => window.removeEventListener('nyansa-profile', save)
  }, [handle, session])

  const submit = async (event: React.FormEvent) => {
    event.preventDefault()
    const name = username.trim().replace(/^@/, '').toLowerCase()
    if (!/^[a-z0-9_]{3,24}$/.test(name)) {
      setMessage('Use 3–24 letters, numbers or underscores for your handle.')
      return
    }
    setBusy(true); setMessage('')
    try {
      const accounts = readAccounts()
      if (mode === 'create') {
        if (accounts[name]) { setMessage('That handle already exists on this browser. Choose another or open your profile.'); setBusy(false); return }
        const salt = Array.from(crypto.getRandomValues(new Uint8Array(16)), byte => byte.toString(16).padStart(2, '0')).join('')
        const passwordHash = await hashPassword(password, salt)
        const previousProfile = localStorage.getItem('nyansa-local-access') === 'yes' && Object.keys(accounts).length === 0 ? localStorage.getItem(profileKey) : null
        accounts[name] = { salt, passwordHash, profile: previousProfile }
        localStorage.setItem(accountsKey, JSON.stringify(accounts))
      } else {
        const account = accounts[name]
        if (!account || await hashPassword(password, account.salt) !== account.passwordHash) {
          setMessage('Handle or password not recognised on this browser.'); setBusy(false); return
        }
      }
      const profile = accounts[name].profile
      if (profile) localStorage.setItem(profileKey, profile)
      else localStorage.removeItem(profileKey)
      localStorage.removeItem('nyansa-local-access')
      localStorage.setItem(activeKey, name)
      window.location.reload()
    } catch {
      setMessage('Could not save this profile. Check that browser storage is enabled and try again.')
      setBusy(false)
    }
  }

  const submitEmail = async (event: React.FormEvent) => {
    event.preventDefault()
    if (!cloud) { setMessage('Account access is temporarily unavailable. Please try again later.'); return }
    emailSubmitting.current = true; setBusy(true); setMessage('')
    try {
      const result = mode === 'create'
        ? await cloud.auth.signUp({ email, password, options: { emailRedirectTo: window.location.origin + '/match' } })
        : await cloud.auth.signInWithPassword({ email, password })
      if (result.error) { emailSubmitting.current = false; setMessage(result.error.message); setBusy(false); return }
      if (!result.data.session) { emailSubmitting.current = false; setMessage('Check your email for a confirmation link, then return to open your profile.'); setBusy(false); return }
      await restoreCloudProfile()
      if (pendingPaystackPlan()) window.location.assign(resumePaystackLocation)
      else window.location.reload()
    } catch { emailSubmitting.current = false; setMessage('Could not access your account. Please check your connection and try again.'); setBusy(false) }
  }

  const continueWithGoogle = async () => {
    if (!cloud) { setMessage('Account access is temporarily unavailable. Please try again later.'); return }
    setBusy(true); setMessage('')
    try {
      const settings = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/auth/v1/settings`, { headers: { apikey: import.meta.env.VITE_SUPABASE_ANON_KEY } })
      if (!settings.ok) throw new Error('Could not check Google sign-in availability. Please try again.')
      const config = await settings.json()
      if (!config.external?.google) { setMessage('Google sign-in must be enabled in the Supabase project before it can be used.'); setBusy(false); return }
      const { error } = await cloud.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: window.location.origin + '/match' } })
      if (error) { setMessage(error.message); setBusy(false) }
    } catch { setMessage('Could not start Google sign-in. Please check your connection and try again.'); setBusy(false) }
  }

  const closeProfile = async () => {
    if (session && cloud) await cloud.auth.signOut()
    localStorage.removeItem(activeKey)
    localStorage.removeItem(profileKey)
    window.location.assign('/')
  }

  const checkoutRequested = window.location.pathname === '/match' && new URLSearchParams(window.location.search).get('checkout') === '1' && !!pendingPaystackPlan()
  return <>
    {ready ? children : <div className="auth-loading">Loading your profile…</div>}
    {ready && (session || handle) && <div className="auth-account"><span>{session ? session.user.email : `@${handle} · This browser only`}</span><button onClick={closeProfile}>Close profile</button>{syncError && <small>Could not sync your profile. Check your connection.</small>}</div>}
    {ready && protectedPage && (!handle || checkoutRequested) && !session && <div className="auth-overlay" role="dialog" aria-modal="true" aria-labelledby="auth-title">
      <div className="auth-card">
        <a className="auth-back" href="/">← Back to Nyansa</a>
        <div className="auth-mark">✳</div>
        <p className="auth-eyebrow">YOUR NYANSA PROFILE</p>
        <h1 id="auth-title">Make it <em>yours.</em></h1>
        <p className="auth-intro">{accountMethod === 'handle' ? (mode === 'create' ? 'Choose a handle and password to create your profile.' : 'Enter your handle and password to reopen your profile.') : 'Use an email and password to access your profile across devices.'}</p>
        {checkoutRequested && <p className="auth-notice">Sign in with your Supabase email account to continue your selected checkout.</p>}
        {accountMethod === 'handle' ? <div className="auth-notice"><strong>Saved on this browser only</strong><p>Your profile is not synced between devices and can be lost if browser data is cleared. The password does not secure data from someone with access to this device; use a unique password and avoid shared devices.</p></div> : <button className="auth-google" type="button" hidden disabled={busy} onClick={continueWithGoogle}><span className="google-g">G</span> Continue with Google</button>}
        <form onSubmit={accountMethod === 'handle' ? submit : submitEmail}>
          {accountMethod === 'handle' ? <label>Username or handle<input type="text" autoComplete="username" required minLength={3} maxLength={25} value={username} onChange={e => setUsername(e.target.value)} placeholder="e.g. ama_owusu" /></label> : <label>Email address<input type="email" autoComplete="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" /></label>}
          <label>Password<span className="auth-password"><input type={showPassword ? 'text' : 'password'} autoComplete={mode === 'create' ? 'new-password' : 'current-password'} required minLength={8} value={password} onChange={e => setPassword(e.target.value)} placeholder="At least 8 characters" /><button type="button" aria-label={showPassword ? 'Hide password' : 'Show password'} aria-pressed={showPassword} onClick={() => setShowPassword(!showPassword)}>{showPassword ? 'Hide' : 'Show'}</button></span></label>
          {message && <p className="auth-message" role="status">{message}</p>}
          <button className="auth-submit" disabled={busy}>{busy ? 'Please wait…' : mode === 'create' ? 'Create my profile →' : 'Open my profile →'}</button>
        </form>
        <p className="auth-switch">{mode === 'create' ? (accountMethod === 'handle' ? 'Already have a handle on this browser?' : 'Already have an account?') : 'New to Nyansa?'} <button onClick={() => { setMode(mode === 'create' ? 'open' : 'create'); setMessage('') }}>{mode === 'create' ? 'Open your profile' : 'Create a profile'}</button></p>
        {!checkoutRequested && <p className="auth-switch"><button type="button" onClick={() => { setAccountMethod(accountMethod === 'handle' ? 'email' : 'handle'); setMessage(''); setPassword(''); setShowPassword(false) }}>{accountMethod === 'handle' ? 'Use email and password instead' : 'Use a username instead'}</button></p>}
      </div>
    </div>}
  </>
}
