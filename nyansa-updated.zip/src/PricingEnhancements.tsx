import { useEffect, useState } from 'react'
import './pricing-enhancements.css'

type Plan = { name: string; price: string; detail: string }
const planInfo: Record<string, Plan> = {
  'Counselor Starter': { name: 'Counselor Starter', price: 'GHS 400 / term', detail: 'Up to 150 students · cohort dashboard, CSV export and at-risk flags' },
  'Counselor Pro': { name: 'Counselor Pro', price: 'GHS 900 / term', detail: 'Unlimited students · premium reports, PTA pack and priority support' },
}

function addDescription(parent: Element, key: string, text: string, before?: Element | null) {
  if (parent.querySelector(`[data-pricing-note="${key}"]`)) return
  const note = document.createElement('p')
  note.dataset.pricingNote = key
  note.className = 'pricing-context'
  note.textContent = text
  if (before) parent.insertBefore(note, before)
  else parent.appendChild(note)
}

function enhancePricing() {
  if (window.location.pathname !== '/pricing') return
  const schools = document.getElementById('schools')
  if (schools) {
    const grid = schools.querySelector('[data-source-loc="src/pages/Pricing.tsx:67:8"]')
    addDescription(schools, 'schools-intro', 'Choose a plan for your student cohort. Prices shown are per term; a demo helps you explore the right fit before committing.', grid)
    schools.querySelectorAll('[data-source-loc="src/pages/Pricing.tsx:73:12"]').forEach(card => {
      const name = card.querySelector('h3')?.textContent?.trim() || ''
      if (name === 'District / Network') { card.remove(); return }
      const descriptions: Record<string, string> = {
        'Counselor Starter': 'A practical starting point for one school managing up to 150 students.',
        'Counselor Pro': 'For larger cohorts that need premium reports and additional support.',
      }
      if (descriptions[name]) addDescription(card, 'plan-detail', descriptions[name], card.querySelector('ul'))
      const tier = name === 'Counselor Starter' ? 'starter' : name === 'Counselor Pro' ? 'pro' : null
      const demo = card.querySelector('button[data-source-loc="src/pages/Pricing.tsx:77:14"]')
      if (tier && demo && !card.querySelector('[data-counselor-checkout]')) {
        const checkout = document.createElement('button')
        checkout.type = 'button'; checkout.dataset.counselorCheckout = tier; checkout.className = 'counselor-pay-button'
        checkout.textContent = tier === 'starter' ? 'Choose Starter · GHS 400' : 'Choose Pro · GHS 900'
        demo.insertAdjacentElement('beforebegin', checkout)
      }
    })
  }
  const studentCards = document.querySelectorAll('#students [data-source-loc="src/pages/Pricing.tsx:47:12"]')
  studentCards.forEach(card => {
    const heading = card.querySelector('h3')
    const name = heading?.textContent?.trim()
    if (name === 'Premium Family Report' || name === 'Student Full Report') {
      addDescription(card, 'premium-detail', 'A one-time GHS 29 report for students and families. Checkout is in test mode; access requires server verification.', card.querySelector('ul'))
      const clearer: Record<string, string> = { 'Printable 12-page strategy report': 'Printable personalised planning report', 'Deadline calendar + SMS reminders': 'Deadline planning checklist', 'Full requirements for every programme': 'Programme requirements to verify', 'Unlimited Essay Coach reviews': 'Essay planning and writing tools' }
      card.querySelectorAll('li').forEach(item => { const text = item.lastChild; if (text?.nodeType === Node.TEXT_NODE && text.textContent && clearer[text.textContent.trim()]) text.textContent = clearer[text.textContent.trim()] })
      if (heading && name !== 'Student Full Report') heading.textContent = 'Student Full Report'
      const checkout = card.querySelector('button[data-source-loc="src/pages/Pricing.tsx:55:16"]')
      if (checkout && !card.querySelector('[data-student-report-link]')) { const link = document.createElement('a'); link.href = '/report'; link.dataset.studentReportLink = 'true'; link.className = 'student-report-link'; link.textContent = 'Already unlocked? Open my report →'; checkout.insertAdjacentElement('afterend', link) }
    }
    if (name === 'Free' || name === 'Student Free') {
      addDescription(card, 'free-detail', 'Start with profile building, ranked matches and basic essay feedback at no cost.', card.querySelector('ul'))
      if (heading && name !== 'Student Free') heading.textContent = 'Student Free'
    }
  })
}

export default function PricingEnhancements() {
  const [plan, setPlan] = useState<Plan | null>(null)
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [school, setSchool] = useState('')
  const [students, setStudents] = useState('')
  const [notes, setNotes] = useState('')
  const [prepared, setPrepared] = useState(false)
  const [feedback, setFeedback] = useState('')

  useEffect(() => {
    enhancePricing()
    const observer = new MutationObserver(enhancePricing)
    observer.observe(document.body, { childList: true, subtree: true })
    const click = (event: MouseEvent) => {
      const target = event.target
      if (!(target instanceof Element)) return
      const homeButton = window.location.pathname === '/' ? target.closest<HTMLButtonElement>('button[data-home-demo]') : null
      const button = window.location.pathname === '/pricing' ? target.closest('button[data-source-loc="src/pages/Pricing.tsx:77:14"]') : null
      if (homeButton) {
        const name = homeButton.dataset.homeDemo || ''
        if (!planInfo[name]) return
        event.preventDefault(); event.stopPropagation(); setPlan(planInfo[name]); setPrepared(false); setFeedback(''); return
      }
      if (!button) return
      const name = button.closest('[data-source-loc="src/pages/Pricing.tsx:73:12"]')?.querySelector('h3')?.textContent?.trim() || ''
      if (!planInfo[name]) return
      event.preventDefault(); event.stopPropagation()
      setPlan(planInfo[name]); setPrepared(false); setFeedback('')
    }
    document.addEventListener('click', click, true)
    return () => { observer.disconnect(); document.removeEventListener('click', click, true) }
  }, [])

  useEffect(() => {
    if (!plan) return
    const closeOnEscape = (event: KeyboardEvent) => { if (event.key === 'Escape') setPlan(null) }
    document.addEventListener('keydown', closeOnEscape)
    return () => document.removeEventListener('keydown', closeOnEscape)
  }, [plan])

  if (!plan) return null
  const summary = `Demo request: ${plan.name}\nPlan: ${plan.price}\nName: ${name}\nSchool / organisation: ${school}\nEmail: ${email}\nPhone: ${phone || 'Not provided'}\nApproximate students: ${students}\nAdditional notes: ${notes || 'None'}`
  const emailLink = `mailto:?subject=${encodeURIComponent(`Nyansa demo request — ${plan.name}`)}&body=${encodeURIComponent(summary)}`
  const copy = async () => {
    try { await navigator.clipboard.writeText(summary); setFeedback('Request details copied.') }
    catch { setFeedback('Could not copy automatically. Select the request details below and copy them.') }
  }

  return <div className="demo-overlay" onMouseDown={event => { if (event.target === event.currentTarget) setPlan(null) }}>
    <section className="demo-card" role="dialog" aria-modal="true" aria-labelledby="demo-title">
      <div className="demo-stripe" />
      <div className="demo-content">
        <button className="demo-close" type="button" aria-label="Close demo request" onClick={() => setPlan(null)}>×</button>
        <p className="demo-eyebrow">FOR SCHOOLS · REQUEST A DEMO</p>
        <h2 id="demo-title">See Nyansa in action.</h2>
        <p className="demo-lead">Explore how your team can help students make more confident choices.</p>
        <div className="demo-plan"><div><span>YOUR SELECTED PLAN</span><strong>{plan.name}</strong></div><b>{plan.price}</b><p>{plan.detail}</p></div>
        {!prepared ? <>
          <p className="demo-help">Tell us a little about your school to prepare a demo request. No payment is required.</p>
          <form onSubmit={event => { event.preventDefault(); setPrepared(true); setFeedback('') }}>
            <div className="demo-grid"><label>Your name<input required autoComplete="name" value={name} onChange={event => setName(event.target.value)} placeholder="Full name" /></label><label>School or organisation<input required value={school} onChange={event => setSchool(event.target.value)} placeholder="School name" /></label><label>Work email<input required type="email" autoComplete="email" value={email} onChange={event => setEmail(event.target.value)} placeholder="you@school.edu" /></label><label>Phone <span>optional</span><input type="tel" autoComplete="tel" value={phone} onChange={event => setPhone(event.target.value)} placeholder="024 123 4567" /></label><label className="demo-full">Approximate number of students<input required type="number" min="1" max="1000000" value={students} onChange={event => setStudents(event.target.value)} placeholder="e.g. 120" /></label><label className="demo-full">What would you like to explore? <span>optional</span><textarea rows={2} value={notes} onChange={event => setNotes(event.target.value)} placeholder="Tell us about your school's needs" /></label></div>
            <button className="demo-primary" type="submit">Prepare demo request →</button>
          </form>
          <p className="demo-footnote">Your details stay in this browser unless you choose to share them. The request is not sent automatically.</p>
        </> : <div className="demo-ready" role="status">
          <div className="demo-check">✓</div><h3>Your request is ready.</h3>
          <p>No request has been sent yet. Open your email app, add the Nyansa team’s address and send the prepared details, or copy them to share another way.</p>
          <pre tabIndex={0}>{summary}</pre>
          <div className="demo-actions"><a className="demo-primary" href={emailLink}>Open email app ↗</a><button className="demo-secondary" type="button" onClick={copy}>Copy details</button></div>
          {feedback && <p className="demo-feedback">{feedback}</p>}
          <button className="demo-edit" type="button" onClick={() => setPrepared(false)}>← Edit details</button>
        </div>}
      </div>
    </section>
  </div>
}
