import { cloud } from './cloudProfile'
import { getPaystackPublicKey } from './PaystackCheckout'

export type PaidPlan = 'premium_family_report' | 'counselor_starter' | 'counselor_pro'
export type PaymentIntent = { reference: string; claim: string; email: string; plan: PaidPlan; amount: number; environment: 'live' | 'test'; owner_id: string | null; status?: string; active?: boolean }
const storageKey = 'nyansa-guest-payment-references-v1'
export function readPaymentIntents(): PaymentIntent[] { try { const rows=JSON.parse(localStorage.getItem(storageKey) || '[]'); return Array.isArray(rows) ? rows.filter((r:PaymentIntent) => r && typeof r.reference==='string' && typeof r.claim==='string' && ['premium_family_report','counselor_starter','counselor_pro'].includes(r.plan)) : [] } catch { return [] } }
export function savePaymentIntent(item: PaymentIntent) { const next=[item,...readPaymentIntents().filter(row=>row.reference!==item.reference)]; localStorage.setItem(storageKey,JSON.stringify(next)); return next }
export function removePaymentIntent(reference: string) { const next=readPaymentIntents().filter(row=>row.reference!==reference); localStorage.setItem(storageKey,JSON.stringify(next)); return next }
export async function paymentRequest(body: Record<string, unknown>) {
 let token: string | undefined
 if (cloud) { const { data } = await cloud.auth.getSession(); token=data.session?.access_token }
 const legacy = typeof body.claim === 'string' && /^[a-f0-9]{64}$/.test(body.claim)
 const response=await fetch(legacy ? '/api/guest-payment' : '/api/payments',{method:'POST',headers:{'Content-Type':'application/json',...(token?{Authorization:`Bearer ${token}`}:{})},body:JSON.stringify(body)})
 const data=await response.json().catch(()=>({}))
 if(!response.ok) throw new Error(data.error || 'Payment service is unavailable. Please try again.')
 return data
}
export async function checkPurchasedPlan(plan: PaidPlan) {
 const environment=getPaystackPublicKey()?.startsWith('pk_live_')?'live':'test'
 let accessError: unknown = null
 if(cloud){ const {data}=await cloud.auth.getSession();if(data.session){
  try{const account=await paymentRequest({action:'account_access',plan,environment});if(account.access)return account.receipt}catch(error){accessError=error}
  try{const response=await fetch('/api/guest-payment',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${data.session.access_token}`},body:JSON.stringify({action:'account_access',plan,environment})});if(response.ok){const legacy=await response.json();if(legacy.access)return legacy.receipt}}catch{/* The new payments table may still be available. */}
 } }
 for(const item of readPaymentIntents().filter(row=>row.plan===plan && row.environment===environment)){
  try{const result=await paymentRequest({action:'access',reference:item.reference,claim:item.claim});if(result.access)return result.receipt}catch(error){accessError=error}
 }
 if(accessError)throw accessError
 return null
}
