import './paystack.css'

type PaystackResponse = { reference?: string; trxref?: string }
type PaystackOptions = {
  key: string
  email: string
  amount: number
  currency: 'GHS'
  channels: string[]
  ref?: string
  metadata?: Record<string, string>
  callback: (response: PaystackResponse) => void
  onClose: () => void
  onError: (error: { message?: string }) => void
}
declare global { interface Window { PaystackPop?: { setup: (options: PaystackOptions) => { openIframe: () => void } } } }

export function loadPaystack(): Promise<void> {
  if (window.PaystackPop) return Promise.resolve()
  return new Promise((resolve, reject) => {
    const existing = document.querySelector<HTMLScriptElement>('script#nyansa-paystack-inline')
    const script = existing || document.createElement('script')
    const cleanup = () => { clearTimeout(timer); script.removeEventListener('load', onLoad); script.removeEventListener('error', onError) }
    const onLoad = () => { cleanup(); if (window.PaystackPop) resolve(); else { script.remove(); reject(new Error('Paystack could not be loaded.')) } }
    const onError = () => { cleanup(); script.remove(); reject(new Error('Could not load Paystack. Check your connection and try again.')) }
    const timer = setTimeout(onError, 15000)
    script.addEventListener('load', onLoad, { once: true })
    script.addEventListener('error', onError, { once: true })
    if (!existing) { script.src = 'https://js.paystack.co/v1/inline.js'; script.async = true; script.id = 'nyansa-paystack-inline'; document.head.appendChild(script) }
  })
}

export function getPaystackPublicKey() {
  return (import.meta.env.VITE_PAYSTACK_PUBLIC_KEY as string | undefined)?.replace(/^pk_test_pk_test_/, 'pk_test_')
}
