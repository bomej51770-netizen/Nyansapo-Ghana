import type { CallbackUnlock } from './localCallbackUnlock'
const key='nyansa-edge-payment-pending-v1'
export function readEdgePending(): CallbackUnlock[] { try { const rows=JSON.parse(localStorage.getItem(key)||'[]');return Array.isArray(rows)?rows.filter((item:CallbackUnlock)=>item&&typeof item.reference==='string'&&['premium_family_report','counselor_starter','counselor_pro'].includes(item.plan)):[] } catch { return [] } }
export function saveEdgePending(item:CallbackUnlock) { const rows=[item,...readEdgePending().filter(row=>row.reference!==item.reference)];localStorage.setItem(key,JSON.stringify(rows));return rows }
export function removeEdgePending(reference:string) { const rows=readEdgePending().filter(row=>row.reference!==reference);localStorage.setItem(key,JSON.stringify(rows));return rows }
