import { useEffect, useState } from 'react'
import { createClient, type Session } from '@supabase/supabase-js'

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined
const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined
export const cloud = url && key ? createClient(url, key) : null
const profileKey = 'nyansa-profile-v1'

export async function restoreCloudProfile() {
  if (!cloud) return
  const { data, error } = await cloud.auth.getUser()
  if (error) throw error
  const profile = data.user?.user_metadata?.nyansa_profile
  if (profile && typeof profile === 'object') localStorage.setItem(profileKey, JSON.stringify(profile))
  else localStorage.removeItem(profileKey)
  localStorage.removeItem('nyansa-active-handle-v1')
}

export function useCloudProfile() {
  const [ready, setReady] = useState(!cloud)
  const [session, setSession] = useState<Session | null>(null)
  const [syncError, setSyncError] = useState(false)
  useEffect(() => {
    if (!cloud) return
    let mounted = true
    cloud.auth.getSession().then(async ({ data }) => {
      if (data.session) {
        try { await restoreCloudProfile() } catch { localStorage.removeItem(profileKey); if (mounted) setSyncError(true) }
      }
      if (mounted) { setSession(data.session); setReady(true) }
    })
    const { data: listener } = cloud.auth.onAuthStateChange((_event, current) => { if (mounted) setSession(current) })
    return () => { mounted = false; listener.subscription.unsubscribe() }
  }, [])
  useEffect(() => {
    if (!cloud || !session) return
    let timer: ReturnType<typeof setTimeout>
    const save = () => {
      clearTimeout(timer)
      timer = setTimeout(async () => {
        try {
          const raw = localStorage.getItem(profileKey)
          if (!raw) return
          const { error } = await cloud!.auth.updateUser({ data: { nyansa_profile: JSON.parse(raw) } })
          setSyncError(!!error)
        } catch { setSyncError(true) }
      }, 500)
    }
    window.addEventListener('nyansa-profile', save)
    return () => { clearTimeout(timer); window.removeEventListener('nyansa-profile', save) }
  }, [session?.user.id])
  return { ready, session, syncError }
}
