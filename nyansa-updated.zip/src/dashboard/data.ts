export type Field = 'Computing' | 'Engineering' | 'Health' | 'Education' | 'Business' | 'Arts' | 'Agriculture'
export type Category = 'Public University' | 'Technical University' | 'College of Education' | 'Nursing & Midwifery' | 'Private University' | 'Specialized University'
export type Region = 'Greater Accra' | 'Ashanti' | 'Central' | 'Northern' | 'Western' | 'Eastern' | 'Volta' | 'Bono' | 'Bono East' | 'Ahafo' | 'Western North' | 'Upper East' | 'Upper West' | 'Oti' | 'Savannah' | 'North East'
type Seed = { programme: string; field: Field; required?: string[]; id?: string; screeningCutoff?: number }
export type Institution = { id: string; name: string; short: string; type: Category; location: string; region: Region; url?: string; detail: string; planningBand: readonly [number, number]; streams: readonly string[]; source: string; sourceLabel: string; seeds: Seed[] }
export type Programme = { id: string; institutionId: string; institution: string; short: string; programme: string; field: Field; cutoff: number | null; planningBand: readonly [number, number]; required: string[]; type: Category; location: string; region: Region; url?: string }

export const regions: Region[] = ['Greater Accra','Ashanti','Central','Northern','Western','Eastern','Volta','Bono','Bono East','Ahafo','Western North','Upper East','Upper West','Oti','Savannah','North East']
export const categories: Category[] = ['Public University','Technical University','College of Education','Nursing & Midwifery','Private University','Specialized University']
const gtec = 'https://gtec.edu.gh/explore-institutions/'
const nmc = 'https://www.nmc.gov.gh/web/find-accredited-institutions'
const coe = 'https://admission.coeportal.edu.gh/ADMISSION_PROCEDURE_2023.pdf'
const band: Record<Category, readonly [number, number]> = { 'Public University':[6,24], 'Technical University':[12,36], 'College of Education':[12,36], 'Nursing & Midwifery':[6,30], 'Private University':[6,36], 'Specialized University':[6,30] }
const streams = ['Regular','Fee-Paying','Distance / Weekend'] as const
const seed = (programme: string, field: Field, required: string[] = [], id?: string, screeningCutoff?: number): Seed => ({ programme,field,required,id,screeningCutoff })
function school(id:string,name:string,short:string,type:Category,location:string,region:Region,seeds:Seed[],url?:string):Institution {
  return { id,name,short,type,location,region,seeds,url,planningBand:band[type],streams,source:type==='Nursing & Midwifery'?nmc:type==='College of Education'?coe:gtec,sourceLabel:type==='Nursing & Midwifery'?'NMC institution list':type==='College of Education'?'2023 colleges admission guide':'GTEC institution directory',detail:seeds.map(s=>s.programme).join(' · ') }
}
const education = () => [seed('Teaching and education pathways','Education')]
const nursing = () => [seed('Nursing and midwifery pathways','Health')]
const technical = () => [seed('Applied engineering and technology pathways','Engineering'),seed('Business and HND pathways','Business')]
const privateStudy = (first:string,field:Field,second:string,other:Field) => [seed(first,field),seed(second,other)]

// These category-wide bands are illustrative comparison aids, not official or
// programme-specific cut-offs. Programme names, streams and current accreditation
// must be checked with each institution and regulator before applying.
export const institutions: Institution[] = [
  school('ug','University of Ghana','UG','Public University','Accra','Greater Accra',[seed('BSc Computer Science','Computing',['Elective Mathematics'],'ug-cs',10),seed('BSc Nursing','Health',['Biology','Chemistry'],'ug-nursing',12)],'https://www.ug.edu.gh'),
  school('knust','Kwame Nkrumah University of Science and Technology','KNUST','Public University','Kumasi','Ashanti',[seed('BSc Computer Science','Computing',['Elective Mathematics'],'knust-cs',7),seed('BSc Civil Engineering','Engineering',['Elective Mathematics','Physics'],'knust-civil',8)],'https://www.knust.edu.gh'),
  school('ucc','University of Cape Coast','UCC','Public University','Cape Coast','Central',[seed('BSc Nursing','Health',['Biology','Chemistry'],'ucc-nursing',11),seed('B.Ed Mathematics','Education',['Elective Mathematics'])],'https://ucc.edu.gh'),
  school('uew','University of Education, Winneba','UEW','Public University','Winneba','Central',[seed('B.Ed Mathematics','Education',['Elective Mathematics'],'uew-maths',20),seed('Teacher education pathways','Education')],'https://www.uew.edu.gh'),
  school('uds','University for Development Studies','UDS','Public University','Tamale','Northern',[seed('Nursing and health pathways','Health'),seed('Agriculture and development pathways','Agriculture')],'https://www.uds.edu.gh'),
  school('umat','University of Mines and Technology','UMaT','Public University','Tarkwa','Western',[seed('Mining and mineral engineering pathways','Engineering'),seed('Computing pathways','Computing')],'https://umat.edu.gh'),
  school('uhas','University of Health and Allied Sciences','UHAS','Public University','Ho','Volta',[seed('Nursing and allied health pathways','Health'),seed('Public health pathways','Health')],'https://www.uhas.edu.gh'),
  school('uenr','University of Energy and Natural Resources','UENR','Public University','Sunyani','Bono',[seed('Energy and natural resources pathways','Engineering'),seed('Computing and science pathways','Computing')],'https://uenr.edu.gh'),
  school('upsa','University of Professional Studies, Accra','UPSA','Public University','Accra','Greater Accra',[seed('Accounting and business pathways','Business'),seed('Law and professional studies pathways','Arts')],'https://upsa.edu.gh'),
  school('aamusted','Akenten Appiah-Menka University of Skills Training and Entrepreneurial Development','AAMUSTED','Public University','Kumasi','Ashanti',[seed('Technical and vocational teacher education','Education'),seed('Business and entrepreneurship pathways','Business')]),
  school('cktutas','C. K. Tedam University of Technology and Applied Sciences','CKT-UTAS','Public University','Navrongo','Upper East',[seed('Applied science and technology pathways','Engineering'),seed('Computing pathways','Computing')]),
  school('sddubids','Simon Diedong Dombo University of Business and Integrated Development Studies','SDD-UBIDS','Public University','Wa','Upper West',[seed('Business and management pathways','Business'),seed('Development studies pathways','Arts')]),
  school('gimpa','Ghana Institute of Management and Public Administration','GIMPA','Public University','Accra','Greater Accra',[seed('Public administration pathways','Business'),seed('Law and governance pathways','Arts')],'https://gimpa.edu.gh'),
  school('unimac','University of Media, Arts and Communication','UniMAC','Public University','Accra','Greater Accra',[seed('Journalism and media pathways','Arts'),seed('Film and communication pathways','Arts')]),
  school('gctu','Ghana Communication Technology University','GCTU','Public University','Accra','Greater Accra',[seed('Information technology pathways','Computing'),seed('Telecommunications engineering pathways','Engineering')],'https://gctu.edu.gh'),
  school('atu','Accra Technical University','ATU','Technical University','Accra','Greater Accra',[seed('BTech Accounting','Business',[],'atu-account',24),seed('BTech Computer Science','Computing',[],'atu-cs',24)],'https://www.atu.edu.gh'),
  school('kstu','Kumasi Technical University','KsTU','Technical University','Kumasi','Ashanti',technical(),'https://www.kstu.edu.gh'),
  school('tktu','Takoradi Technical University','TTU','Technical University','Takoradi','Western',technical()),
  school('cctu','Cape Coast Technical University','CCTU','Technical University','Cape Coast','Central',technical()),
  school('ktu','Koforidua Technical University','KTU','Technical University','Koforidua','Eastern',technical()),
  school('htu','Ho Technical University','HTU','Technical University','Ho','Volta',technical()),
  school('stu','Sunyani Technical University','STU','Technical University','Sunyani','Bono',technical()),
  school('tatu','Tamale Technical University','TaTU','Technical University','Tamale','Northern',technical()),
  school('btu','Bolgatanga Technical University','BTU','Technical University','Bolgatanga','Upper East',technical()),
  school('dhltu','Dr. Hilla Limann Technical University','DHLTU','Technical University','Wa','Upper West',technical(),'https://www.dhltu.edu.gh/'),
  school('wesco','Wesley College of Education','WESCO','College of Education','Kumasi','Ashanti',education()),
  school('pce-akropong','Presbyterian College of Education, Akropong','PCE','College of Education','Akropong','Eastern',education()),
  school('accra-coe','Accra College of Education','Accra CoE','College of Education','Accra','Greater Accra',education()),
  school('komenda','Komenda College of Education','Komenda CoE','College of Education','Komenda','Central',education()),
  school('st-louis','St. Louis College of Education, Kumasi','St. Louis','College of Education','Kumasi','Ashanti',education()),
  school('bagabaga','Bagabaga College of Education','Bagabaga','College of Education','Tamale','Northern',education()),
  school('st-monica','St. Monica’s College of Education','St. Monica’s','College of Education','Mampong','Ashanti',education()),
  school('ada','Ada College of Education','Ada CoE','College of Education','Ada','Greater Accra',education()),
  school('holy-child','Holy Child College of Education','Holy Child','College of Education','Sekondi-Takoradi','Western',education()),
  school('mount-mary','Mount Mary College of Education','Mount Mary','College of Education','Somanya','Eastern',education()),
  school('tamale-coe','Tamale College of Education','Tamale CoE','College of Education','Tamale','Northern',education()),
  school('jasikan','Jasikan College of Education','Jasikan','College of Education','Jasikan','Oti',education()),
  school('berekum','Berekum College of Education','Berekum','College of Education','Berekum','Bono',education()),
  school('enchi','Enchi College of Education','Enchi','College of Education','Enchi','Western North',education()),
  school('nusrat','Nusrat Jahan Ahmadiyya College of Education','Nusrat Jahan','College of Education','Wa','Upper West',education()),
  school('korlebu','Nursing & Midwifery Training School, Korle-Bu','Korle-Bu','Nursing & Midwifery','Accra','Greater Accra',nursing()),
  school('komfo','Nursing & Midwifery Training College, Kumasi (Komfo Anokye)','Komfo Anokye','Nursing & Midwifery','Kumasi','Ashanti',nursing()),
  school('cape-nmtc','Nursing & Midwifery Training College, Cape Coast','Cape Coast NMTC','Nursing & Midwifery','Cape Coast','Central',nursing()),
  school('tamale-nmtc','Nursing & Midwifery Training School, Tamale','Tamale NMTS','Nursing & Midwifery','Tamale','Northern',nursing()),
  school('ho-ntc','Nurses Training College, Ho','Ho NTC','Nursing & Midwifery','Ho','Volta',[seed('General nursing and public health pathways','Health')]),
  school('sunyani-nmtc','Nursing & Midwifery Training College, Sunyani','Sunyani NMTC','Nursing & Midwifery','Sunyani','Bono',nursing()),
  school('koforidua-nmtc','Nursing & Midwifery Training College, Koforidua','Koforidua NMTC','Nursing & Midwifery','Koforidua','Eastern',nursing()),
  school('bolga-ntc','Nurses Training College, Bolgatanga','Bolgatanga NTC','Nursing & Midwifery','Bolgatanga','Upper East',[seed('General nursing pathways','Health')]),
  school('sekondi-nmtc','Nursing & Midwifery Training College, Sekondi','Sekondi NMTC','Nursing & Midwifery','Sekondi','Western',nursing()),
  school('pantang-ntc','Nurses Training College, Pantang','Pantang NTC','Nursing & Midwifery','Pantang','Greater Accra',[seed('Mental health nursing pathways','Health')]),
  school('ashesi','Ashesi University','Ashesi','Private University','Berekuso','Eastern',privateStudy('Computing pathways','Computing','Engineering pathways','Engineering'),'https://www.ashesi.edu.gh'),
  school('central','Central University','Central','Private University','Miotso','Greater Accra',privateStudy('Business pathways','Business','Health sciences pathways','Health'),'https://central.edu.gh'),
  school('vvu','Valley View University','VVU','Private University','Oyibi','Greater Accra',privateStudy('Business pathways','Business','Nursing pathways','Health'),'https://vvu.edu.gh'),
  school('pentecost','Pentecost University','Pentecost','Private University','Accra','Greater Accra',privateStudy('Business pathways','Business','Computing pathways','Computing')),
  school('methodist','Methodist University Ghana','Methodist','Private University','Accra','Greater Accra',privateStudy('Business pathways','Business','Computing pathways','Computing')),
  school('presby-uni','Presbyterian University, Ghana','Presbyterian','Private University','Abetifi','Eastern',privateStudy('Business pathways','Business','Health pathways','Health')),
  school('regent','Regent University College of Science and Technology','Regent','Private University','Accra','Greater Accra',privateStudy('Computing pathways','Computing','Business pathways','Business')),
  school('wisconsin','Wisconsin International University College, Ghana','Wisconsin','Private University','Accra','Greater Accra',privateStudy('Business pathways','Business','Nursing pathways','Health')),
  school('acity','Academic City University','Academic City','Private University','Accra','Greater Accra',privateStudy('Engineering pathways','Engineering','Computing pathways','Computing'),'https://acity.edu.gh'),
  school('lancaster','Lancaster University Ghana','Lancaster','Private University','Accra','Greater Accra',privateStudy('Business pathways — verify current availability','Business','Computing pathways — verify current availability','Computing')),
  school('rmu','Regional Maritime University','RMU','Specialized University','Accra','Greater Accra',privateStudy('Maritime engineering pathways','Engineering','Maritime business pathways','Business')),
  school('all-nations','All Nations University','ANU','Private University','Koforidua','Eastern',privateStudy('Engineering pathways','Engineering','Business pathways','Business')),
  school('techiman-ntc','Nurses Training College, Techiman Krobo','Techiman NTC','Nursing & Midwifery','Techiman','Bono East',nursing()),
  school('goaso-mts','Midwifery Training School, Goaso','Goaso MTS','Nursing & Midwifery','Goaso','Ahafo',[seed('Midwifery pathways','Health')]),
  school('nalerigu','College of Nursing and Midwifery, Nalerigu','Nalerigu','Nursing & Midwifery','Nalerigu','North East',nursing()),
  school('damongo','Nurses Training College, Damongo','Damongo NTC','Nursing & Midwifery','Damongo','Savannah',[seed('General nursing pathways','Health')]),
]
export const programmes: Programme[] = institutions.flatMap(i => i.seeds.map((s,index) => ({ id:s.id || `${i.id}-${index+1}`,institutionId:i.id,institution:i.name,short:i.short,programme:s.programme,field:s.field,cutoff:s.screeningCutoff ?? null,planningBand:i.planningBand,required:s.required || [],type:i.type,location:i.location,region:i.region,url:i.url })))

export { scholarships } from './scholarshipData'
export type { Scholarship, ScholarshipCategory } from './scholarshipData'
