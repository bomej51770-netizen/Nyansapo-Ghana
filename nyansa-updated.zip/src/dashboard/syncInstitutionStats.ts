import { institutions, programmes, scholarships } from './data'

/** Keep the existing homepage counters aligned with the dashboard dataset. */
export function syncInstitutionStats() {
  const update = () => {
    if (window.location.pathname !== '/') return
    const set = (selector: string, text: string) => { const node = document.querySelector(selector); if (node && node.textContent !== text) node.textContent = text }
    set('[data-source-loc="src/pages/Home.tsx:49:19"]', String(institutions.length))
    set('[data-source-loc="src/pages/Home.tsx:49:95"]', 'institutions across Ghana')
    set('[data-source-loc="src/pages/Home.tsx:50:19"]', String(programmes.length))
    set('[data-source-loc="src/pages/Home.tsx:50:86"]', 'programmes & pathways to explore')
    set('[data-source-loc="src/pages/Home.tsx:51:19"]', String(scholarships.length))
  }
  update()
  const observer = new MutationObserver(update)
  observer.observe(document.body, { childList: true, subtree: true })
  return () => observer.disconnect()
}
