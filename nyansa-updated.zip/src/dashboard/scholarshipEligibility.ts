import { useEffect, useState } from 'react'
import type { Criterion, Scholarship } from './scholarshipData'

export type ScholarshipFilters = { aggregate:number; incomeLevel:string; financialNeed:string; fieldOfStudy:string; region:string; community:string; gender:string; parentalLoss:string; institutionType:string; institution:string }
export type Check = { label:string; status:'met'|'not_met'|'unknown'; detail:string }
export type Assessment = { badge:'Qualified'|'Partial Match'; checks:Check[]; met:number; notMet:number; unknown:number }
export const defaultScholarshipFilters:ScholarshipFilters = { aggregate:14,incomeLevel:'Not provided',financialNeed:'Unknown',fieldOfStudy:'Any field',region:'Unknown',community:'Unknown',gender:'Unknown',parentalLoss:'Unknown',institutionType:'Unknown',institution:'Unknown' }
const storageKey='nyansa-scholarship-filters-v1'
function readFilters():ScholarshipFilters { try { const raw=JSON.parse(localStorage.getItem(storageKey)||'{}'); return { ...defaultScholarshipFilters,...raw,aggregate:Math.max(6,Math.min(36,Number(raw.aggregate)||14)) } } catch { return defaultScholarshipFilters } }
export function useScholarshipFilters() {
 const [filters,setState]=useState<ScholarshipFilters>(readFilters)
 useEffect(()=>{const update=()=>setState(readFilters());window.addEventListener('storage',update);return()=>window.removeEventListener('storage',update)},[])
 const update=(patch:Partial<ScholarshipFilters>)=>setState(current=>{const next={...current,...patch};try{localStorage.setItem(storageKey,JSON.stringify(next))}catch{/* Filters remain in memory. */}return next})
 return {filters,update}
}
function unknown<T>(label:string,rule:Criterion<T>,prefix=''):Check { return { label,status:'unknown',detail:`${prefix}${rule.confidence==='unconfirmed'?'Unconfirmed: ':''}${rule.note}` } }
function compare(label:string,rule:Criterion<unknown>,matches:boolean,detail:string):Check { if(rule.confidence!=='reported')return unknown(label,rule);return { label,status:matches?'met':'not_met',detail:`${detail} ${rule.note}` } }
export function assessScholarship(s:Scholarship,f:ScholarshipFilters):Assessment {
 const c=s.eligibility,checks:Check[]=[]
 checks.push(c.maxAggregate.value===null?unknown('WASSCE aggregate',c.maxAggregate,`Selected ${f.aggregate}. `):compare('WASSCE aggregate',c.maxAggregate,f.aggregate<=c.maxAggregate.value,`Selected ${f.aggregate}; stated maximum ${c.maxAggregate.value}.`))
 if(c.incomeLevel.value===null)checks.push(unknown('Household income',c.incomeLevel,`${f.incomeLevel}. `))
 else if(c.incomeLevel.confidence!=='reported')checks.push(unknown('Household income',c.incomeLevel,`${f.incomeLevel}. `))
 else if(f.financialNeed==='Unknown')checks.push({label:'Household income',status:'unknown',detail:`${f.incomeLevel}. Indicate whether you report financial need; the provider makes its own assessment.`})
 else checks.push(compare('Household income',c.incomeLevel,f.financialNeed==='Yes',`${f.incomeLevel}; financial need ${f.financialNeed==='Yes'?'self-reported':'not indicated'}.`))
 if(c.fieldOfStudy.value===null)checks.push(unknown('Field of study',c.fieldOfStudy))
 else if(f.fieldOfStudy==='Any field')checks.push({label:'Field of study',status:'unknown',detail:`No field selected. ${c.fieldOfStudy.note}`})
 else if(f.fieldOfStudy==='STEM' && c.fieldOfStudy.confidence==='reported' && !c.fieldOfStudy.value.some(field=>['STEM','Engineering','Computing','Science','Health'].includes(field)))checks.push({label:'Field of study',status:'not_met',detail:`STEM selected; the reported focus differs. ${c.fieldOfStudy.note}`})
 else if(f.fieldOfStudy==='STEM')checks.push({label:'Field of study',status:'unknown',detail:`STEM selected broadly; confirm the specific programme. ${c.fieldOfStudy.note}`})
 else checks.push(compare('Field of study',c.fieldOfStudy,c.fieldOfStudy.value.includes(f.fieldOfStudy),`Selected ${f.fieldOfStudy}.`))
 const community=c.regionOrCommunity.value
 if(!community)checks.push(unknown('Region / community',c.regionOrCommunity))
 else if(c.regionOrCommunity.confidence!=='reported')checks.push(unknown('Region / community',c.regionOrCommunity,`${f.region==='Unknown'?'Region not provided':`Selected ${f.region}`}. `))
 else if((community.regions&&f.region==='Unknown')||(community.community&&f.community==='Unknown'))checks.push({label:'Region / community',status:'unknown',detail:`More information needed. ${c.regionOrCommunity.note}`})
 else checks.push(compare('Region / community',c.regionOrCommunity,(!community.regions||community.regions.includes(f.region))&&(!community.community||community.community===f.community),`Selected ${f.region}; ${f.community}.`))
 const focus=c.genderOrSpecialFocus.value
 if(!focus)checks.push(unknown('Gender / special focus',c.genderOrSpecialFocus))
 else if(c.genderOrSpecialFocus.confidence!=='reported')checks.push(unknown('Gender / special focus',c.genderOrSpecialFocus))
 else if((focus.gender&&(f.gender==='Unknown'||f.gender==='Prefer not to say'))||(focus.parentalLoss&&f.parentalLoss==='Unknown'))checks.push({label:'Gender / special focus',status:'unknown',detail:`More information needed. ${c.genderOrSpecialFocus.note}`})
 else checks.push(compare('Gender / special focus',c.genderOrSpecialFocus,(!focus.gender||f.gender.toLowerCase()===focus.gender)&&(!focus.parentalLoss||f.parentalLoss==='Yes'),`Selected ${f.gender}; parental loss: ${f.parentalLoss}.`))
 const inst=c.institutionType.value
 if(!inst)checks.push(unknown('Institution type',c.institutionType))
 else if(c.institutionType.confidence!=='reported')checks.push(unknown('Institution type',c.institutionType))
 else if((inst.types&&f.institutionType==='Unknown')||(inst.institutions&&f.institution==='Unknown'))checks.push({label:'Institution type',status:'unknown',detail:`More information needed. ${c.institutionType.note}`})
 else checks.push(compare('Institution type',c.institutionType,(!inst.types||inst.types.includes(f.institutionType))&&(!inst.institutions||inst.institutions.includes(f.institution)),`Selected ${f.institutionType}${f.institution!=='Unknown'?` / ${f.institution}`:''}.`))
 const met=checks.filter(c=>c.status==='met').length,notMet=checks.filter(c=>c.status==='not_met').length,unknownCount=checks.filter(c=>c.status==='unknown').length
 return {badge:met>0&&notMet===0&&s.verification!=='Programme unconfirmed'?'Qualified':'Partial Match',checks,met,notMet,unknown:unknownCount}
}
