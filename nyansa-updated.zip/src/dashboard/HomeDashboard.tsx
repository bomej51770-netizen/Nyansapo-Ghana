import { lazy, Suspense, useEffect, useRef, useState } from 'react'
import { BookOpen, Building2, Check, Compass, GraduationCap, Sparkles, WalletCards } from 'lucide-react'
import GetMatched from './GetMatched'
import { cloud } from '../cloudProfile'
import { clearPendingPaystackPlan, pendingPaystackPlan, type PendingPaystackPlan } from '../paymentResume'
import './home-dashboard.css'

const Universities = lazy(() => import('./Directories').then(module => ({ default: module.Universities })))
const Scholarships = lazy(() => import('./Directories').then(module => ({ default: module.Scholarships })))
const ScholarshipEligibilityView = lazy(() => import('./ScholarshipEligibilityView'))
const EssayBuilder = lazy(() => import('./EssayBuilder'))
const Schools = lazy(() => import('./Schools'))
type Tab = 'match' | 'universities' | 'scholarships' | 'essay' | 'pricing' | 'schools'
const tabs: { id: Tab; label: string; icon: typeof Compass }[] = [
  { id: 'match', label: 'Get Matched', icon: Compass },
  { id: 'universities', label: 'Universities', icon: Building2 },
  { id: 'scholarships', label: 'Scholarships', icon: Sparkles },
  { id: 'essay', label: 'Essay Coach', icon: BookOpen },
  { id: 'pricing', label: 'Pricing', icon: WalletCards },
  { id: 'schools', label: 'For Schools', icon: GraduationCap },
]

function HomePricing({ openMatch }: { openMatch: () => void }) {
  return <main className="db-main home-pricing"><div className="db-breadcrumb">YOUR WORKSPACE <span>/</span> PRICING</div><div className="home-pricing-heading"><p className="db-kicker">SIMPLE, TRANSPARENT PRICING</p><h1>Choose your <em>next step.</em></h1><p>Start free, or explore additional tools for students and schools.</p></div><div className="home-price-grid">
    <article className="home-price-card"><span>FOR STUDENTS</span><h2>Student Free</h2><p className="home-price">GHS 0 <small>· forever</small></p><p>Everything you need to start exploring.</p><ul><li><Check size={15}/> WASSCE grade calculator</li><li><Check size={15}/> Indicative programme matches</li><li><Check size={15}/> Scholarship finder & essay tools</li></ul><button className="home-price-outline" onClick={openMatch}>Start matching →</button></article>
    <article className="home-price-card featured"><span>FOR STUDENTS & FAMILIES</span><h2>Student Full Report</h2><p className="home-price">GHS 29 <small>· one-time</small></p><p>A printable planning summary for your next steps.</p><ul><li><Check size={15}/> Best-6 and grade overview</li><li><Check size={15}/> Your saved programme shortlist</li><li><Check size={15}/> Next-step planning checklist</li></ul><button className="home-price-gold" data-home-student-checkout>Get the report →</button><a href="/report">Already unlocked? Open my report →</a><small>Test checkout; unlock requires server verification.</small></article>
    <article className="home-price-card"><span>FOR SCHOOLS</span><h2>Counselor Starter</h2><p className="home-price">GHS 400 <small>· per term</small></p><p>A practical starting point for your school.</p><ul><li><Check size={15}/> Up to 150 students</li><li><Check size={15}/> Cohort dashboard & CSV export</li><li><Check size={15}/> At-risk student flags</li></ul><button className="home-price-green" data-counselor-checkout="starter">Choose Starter →</button><button className="home-price-demo" data-home-demo="Counselor Starter">Request a demo</button></article>
    <article className="home-price-card"><span>FOR SCHOOLS</span><h2>Counselor Pro</h2><p className="home-price">GHS 900 <small>· per term</small></p><p>More support for larger student cohorts.</p><ul><li><Check size={15}/> Larger cohorts</li><li><Check size={15}/> Premium & trade-off reports</li><li><Check size={15}/> PTA presentation pack</li></ul><button className="home-price-green" data-counselor-checkout="pro">Choose Pro →</button><button className="home-price-demo" data-home-demo="Counselor Pro">Request a demo</button></article>
  </div><p className="home-price-note">Payments are processed by Paystack. Plan activation requires secure verification; test payments do not create paid licences.</p></main>
}

export default function HomeDashboard() {
  const [tab, setTab] = useState<Tab>('match')
  const [scholarshipView, setScholarshipView] = useState<'directory' | 'eligibility'>('directory')
  const [essayScholarship, setEssayScholarship] = useState<string | undefined>()
  const [resumePlan, setResumePlan] = useState<PendingPaystackPlan | null>(null)
  const [resumeError, setResumeError] = useState('')
  const resumed = useRef(false)
  useEffect(() => {
    if (new URLSearchParams(window.location.search).get('resume_checkout') !== '1') return
    const plan = pendingPaystackPlan()
    if (!plan) return
    if (!cloud) { setResumeError('Account access is unavailable. Sign in and choose your plan again.'); return }
    let active = true
    void cloud.auth.getSession().then(({ data, error }) => {
      if (!active) return
      if (error || !data.session?.user.email) { setResumeError('Your sign-in could not be confirmed. Sign in and return to your plan.'); return }
      setTab('pricing'); setResumePlan(plan)
    }).catch(() => { if (active) setResumeError('Your sign-in could not be confirmed. Check your connection and try again.') })
    return () => { active = false }
  }, [])
  useEffect(() => {
    if (tab !== 'pricing' || !resumePlan || resumed.current) return
    const selector = resumePlan === 'student_report' ? 'button[data-home-student-checkout]' : `button[data-counselor-checkout="${resumePlan === 'counselor_starter' ? 'starter' : 'pro'}"]`
    const button = document.querySelector<HTMLButtonElement>(`#home-dashboard ${selector}`)
    if (!button || pendingPaystackPlan() !== resumePlan) return
    resumed.current = true; clearPendingPaystackPlan()
    const url = new URL(window.location.href); url.searchParams.delete('resume_checkout')
    window.history.replaceState(window.history.state, '', `${url.pathname}${url.search}${url.hash}`)
    requestAnimationFrame(() => { document.getElementById('home-dashboard')?.scrollIntoView({ behavior: 'smooth', block: 'start' }); button.click() })
  }, [tab, resumePlan])
  useEffect(() => {
    const click = (event: MouseEvent) => {
      const target = event.target
      if (!(target instanceof Element) || window.location.pathname !== '/' || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return
      const match = target.closest('a[data-source-loc="src/pages/Home.tsx:41:14"]')
      const scholarships = target.closest('a[data-source-loc="src/pages/Home.tsx:44:14"]')
      if (!match && !scholarships) return
      event.preventDefault(); event.stopPropagation(); if (scholarships) setScholarshipView('directory'); setTab(scholarships ? 'scholarships' : 'match')
      requestAnimationFrame(() => document.getElementById('home-dashboard')?.scrollIntoView({ behavior: 'smooth', block: 'start' }))
    }
    document.addEventListener('click', click, true)
    return () => document.removeEventListener('click', click, true)
  }, [])
  return <section className="home-workspace" aria-labelledby="home-workspace-title"><div className="home-workspace-intro"><div><p className="db-kicker">YOUR NYANSA WORKSPACE</p><h2 id="home-workspace-title">Your next step, <em>all in one place.</em></h2><p>Explore your options, save your favourites and make a plan that feels right for you.</p>{resumeError && <p className="match-message" role="alert">{resumeError}</p>}</div><span aria-hidden="true">✳</span></div><div className="home-workspace-tabs" role="tablist" aria-label="Dashboard workspace">{tabs.map(item => <button key={item.id} type="button" role="tab" aria-selected={tab === item.id} className={tab === item.id ? 'active' : ''} onClick={() => setTab(item.id)}><item.icon size={16}/><span>{item.label}</span></button>)}</div><div className="home-workspace-view" role="tabpanel"><Suspense fallback={<div className="db-loading">Loading your workspace…</div>}>{tab === 'match' ? <GetMatched/> : tab === 'universities' ? <Universities/> : tab === 'scholarships' ? scholarshipView === 'eligibility' ? <ScholarshipEligibilityView onBack={() => setScholarshipView('directory')} onDraftEssay={id => { setEssayScholarship(id); setTab('essay'); requestAnimationFrame(() => document.getElementById('home-dashboard')?.scrollIntoView({ behavior:'smooth', block:'start' })) }}/> : <Scholarships onOpenEligibility={() => { setScholarshipView('eligibility'); requestAnimationFrame(() => document.getElementById('home-dashboard')?.scrollIntoView({ behavior:'smooth', block:'start' })) }} onDraftEssay={id => { setEssayScholarship(id); setTab('essay'); requestAnimationFrame(() => document.getElementById('home-dashboard')?.scrollIntoView({ behavior:'smooth', block:'start' })) }}/> : tab === 'essay' ? <EssayBuilder scholarshipId={essayScholarship}/> : tab === 'pricing' ? <HomePricing openMatch={() => setTab('match')}/> : <Schools/>}</Suspense></div></section>
}
