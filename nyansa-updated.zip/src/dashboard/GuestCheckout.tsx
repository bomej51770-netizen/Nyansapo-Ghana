import { useEffect, useRef, useState } from 'react'
import { cloud } from '../cloudProfile'
import { getPaystackPublicKey, loadPaystack } from '../PaystackCheckout'
import type { PaidPlan } from '../guestPayments'
import { saveCallbackUnlock, type CallbackUnlock } from '../localCallbackUnlock'
import { readEdgePending, removeEdgePending, saveEdgePending } from '../edgePaymentPending'
import { verifyPaystack } from '../paystackVerification'
import CheckoutToast from './CheckoutToast'
import { clearPendingPaystackPlan } from '../paymentResume'
import '../counselor/counselor-checkout.css'

type PlanInfo = { title:string; display:string; amount:number; unit:string }
const plans:Record<PaidPlan,PlanInfo> = { premium_family_report:{title:'Premium Family Report',display:'GHS 29',amount:2900,unit:'one-time'},counselor_starter:{title:'Counselor Starter',display:'GHS 400',amount:40000,unit:'per term'},counselor_pro:{title:'Counselor Pro',display:'GHS 900',amount:90000,unit:'per term'} }
export default function GuestCheckout() {
 const [plan,setPlan]=useState<PaidPlan|null>(null),[email,setEmail]=useState(''),[loading,setLoading]=useState(false),[busy,setBusy]=useState(false),[message,setMessage]=useState(''),[toast,setToast]=useState(''),[signedIn,setSignedIn]=useState(false),[unlocked,setUnlocked]=useState<CallbackUnlock|null>(null),[pending,setPending]=useState<CallbackUnlock[]>([])
 const loadingAttempt=useRef(0),opening=useRef(false),completed=useRef(false)
 useEffect(()=>{const click=(event:MouseEvent)=>{const target=event.target;if(!(target instanceof Element)||!['/','/pricing'].includes(window.location.pathname))return;const student=(window.location.pathname==='/'&&target.closest('button[data-home-student-checkout]'))||(window.location.pathname==='/pricing'&&target.closest('button[data-source-loc="src/pages/Pricing.tsx:55:16"]'));const counselor=target.closest<HTMLButtonElement>('button[data-counselor-checkout]');const tier=counselor?.dataset.counselorCheckout;const chosen:PaidPlan|null=student?'premium_family_report':tier==='starter'?'counselor_starter':tier==='pro'?'counselor_pro':null;if(!chosen)return;event.preventDefault();event.stopPropagation();if(opening.current)return;clearPendingPaystackPlan();const attempt=++loadingAttempt.current;setPlan(chosen);setPending(readEdgePending().filter(item=>item.plan===chosen));setEmail('');setLoading(true);setMessage('');setToast('');if(!cloud){setSignedIn(false);setLoading(false);return}void cloud.auth.getSession().then(({data})=>{if(attempt!==loadingAttempt.current)return;setSignedIn(!!data.session);setEmail(data.session?.user.email||'');setLoading(false)}).catch(()=>{if(attempt!==loadingAttempt.current)return;setSignedIn(false);setLoading(false)})};document.addEventListener('click',click,true);return()=>document.removeEventListener('click',click,true)},[])
 const verifyAndUnlock=async(record:CallbackUnlock)=>{
  setBusy(true);setMessage('')
  try{
   await verifyPaystack({reference:record.reference,email:record.email,plan:record.plan,amount:record.amount,user_id:record.user_id,partner_id:null,credits:null})
   const verified={...record,verified:true};saveCallbackUnlock(verified)
   try{setPending(removeEdgePending(record.reference).filter(item=>item.plan===record.plan))}catch{/* The verified receipt remains available. */}
   setUnlocked(verified);setPlan(null);setToast(record.environment==='test'?'Test payment verified. Preview unlocked on this device.':'Payment verified. Your plan is unlocked on this device.')
  }catch(error){const text=error instanceof Error?error.message:'Payment verification failed.';setMessage(`${text} No access was unlocked. Keep the reference and retry verification.`);setToast(text)}
  finally{opening.current=false;setBusy(false)}
 }
 const pay=async(event:React.FormEvent)=>{
  event.preventDefault();if(!plan||opening.current)return;opening.current=true;setBusy(true);setMessage('');setToast('');completed.current=false
  try{
   const key=getPaystackPublicKey();if(!key||!/^pk_(test|live)_[a-zA-Z0-9]+$/.test(key))throw new Error('Paystack public key is missing or invalid. No payment was started.')
   const normalized=email.trim().toLowerCase(),environment=key.startsWith('pk_live_')?'live':'test'
   let userId:string|null=null
   try{if(cloud){const {data}=await cloud.auth.getSession();userId=data.session?.user.id||null}}catch{/* Guest checkout remains available. */}
   try{await loadPaystack()}catch{throw new Error('Paystack could not load. Check your connection or content blocker and try again.')}
   const reference=`nyansa_${environment}_${crypto.randomUUID().replaceAll('-','')}`
   window.PaystackPop!.setup({key,email:normalized,amount:plans[plan].amount,currency:'GHS',channels:['mobile_money','card'],ref:reference,metadata:{product:'nyansa_paid_plan',plan,email:normalized,user_id:userId||'guest'},
    callback:result=>{
     if(completed.current)return
     completed.current=true
     const received=result.reference
     if(!received||received!==reference){opening.current=false;setBusy(false);setMessage('Paystack did not return the expected reference. Access was not unlocked.');return}
     const record:CallbackUnlock={reference:received,email:normalized,plan,amount:plans[plan].amount,currency:'GHS',user_id:userId,environment,created_at:new Date().toISOString()}
     try{setPending(saveEdgePending(record).filter(item=>item.plan===plan))}catch{setMessage(`Keep your payment reference ${received}; browser storage is unavailable.`)}
     void verifyAndUnlock(record)
    },
    onClose:()=>{if(!completed.current){opening.current=false;setBusy(false);setMessage('Checkout was closed. No access was unlocked.')}},
    onError:error=>{opening.current=false;setBusy(false);const text=error?.message||'Paystack checkout failed. Please try again.';setMessage(text);setToast(text)}
   }).openIframe()
  }catch(e){opening.current=false;setBusy(false);const text=e instanceof Error?e.message:'Could not start checkout.';setMessage(text);setToast(text)}
 }
 if(!plan)return <><CheckoutToast message={toast} dismiss={()=>setToast('')}/>{unlocked&&<span className="sr-only">{plans[unlocked.plan].title} was verified and unlocked on this device.</span>}</>
 return <><CheckoutToast message={toast} dismiss={()=>setToast('')}/><div className="payment-overlay" role="dialog" aria-modal="true" aria-labelledby="guest-payment-title"><div className="payment-card counselor-checkout-card"><div className="payment-stripe"/><div className="payment-body"><button className="payment-close" type="button" aria-label="Close checkout" disabled={busy} onClick={()=>{loadingAttempt.current++;setPlan(null)}}>×</button><p className="payment-eyebrow">PAYSTACK CHECKOUT</p><h2 id="guest-payment-title">{plans[plan].title}</h2><p className="payment-price">{plans[plan].display} <span>· {plans[plan].unit}</span></p><p className="payment-copy">Pay by mobile money or card. Access unlocks only after the payment is verified.</p>{getPaystackPublicKey()?.startsWith('pk_test_')&&<p className="cc-test">Test mode: verified test payments unlock a preview, not a paid licence.</p>}{loading?<p className="payment-copy">Checking your account…</p>:<form onSubmit={event=>void pay(event)}><label htmlFor="guest-payment-email">Email address</label><input id="guest-payment-email" type="email" required maxLength={254} autoComplete="email" value={email} onChange={event=>setEmail(event.target.value)} placeholder="you@example.com"/><p className="payment-note">{signedIn?'Prefilled from your account.':'Guest checkout: keep this browser to recover your reference.'}</p><button className="payment-button" disabled={busy}>{busy?'Processing…':`Pay ${plans[plan].display} →`}</button></form>}{message&&<p className="payment-message" role="status">{message}</p>}{pending.length>0&&<div className="cc-pending"><h3>References awaiting verification</h3><p>Keep your reference; no access is unlocked until verification succeeds.</p>{pending.map(item=><div className="cc-reference" key={item.reference}><div><strong>{plans[item.plan].title}</strong><code>{item.reference}</code></div><button type="button" disabled={busy} onClick={()=>void verifyAndUnlock(item)}>Retry verification</button></div>)}</div>}<p className="payment-note">Verification is performed by the payment service; no secret key is stored in your browser.</p></div></div></div></>
}
