import { lazy, Suspense, useEffect, useState } from 'react'
import { createPortal } from 'react-dom'
import { BookOpen, Building2, Compass, GraduationCap, Menu, Sparkles, WalletCards, X } from 'lucide-react'
import GetMatched from './GetMatched'
import HomeDashboard from './HomeDashboard'
import '../counselor/counselor.css'
import './dashboard.css'

const Universities = lazy(() => import('./Directories').then(module => ({ default: module.Universities })))
const Scholarships = lazy(() => import('./Directories').then(module => ({ default: module.Scholarships })))
const ScholarshipEligibilityView = lazy(() => import('./ScholarshipEligibilityView'))
const EssayBuilder = lazy(() => import('./EssayBuilder'))
const Schools = lazy(() => import('./Schools'))
const CounselorMatcher = lazy(() => import('../counselor/CounselorMatcher'))
const StudentReport = lazy(() => import('./StudentReport'))

const tabs = [
 { href:'/match', label:'Get Matched', mobile:'Match', icon:Compass },
 { href:'/universities', label:'Universities', mobile:'Universities', icon:Building2 },
 { href:'/scholarships', label:'Scholarships', mobile:'Funding', icon:Sparkles },
 { href:'/essay', label:'Essay Coach', mobile:'Essay', icon:BookOpen },
 { href:'/pricing', label:'Pricing', mobile:'Pricing', icon:WalletCards },
 { href:'/schools', label:'For Schools', mobile:'Schools', icon:GraduationCap },
]
function currentRoute() { return window.location.pathname + window.location.search }
export default function DashboardShell({ children }: { children: React.ReactNode }) {
 const [route,setRoute]=useState(currentRoute)
 const [menu,setMenu]=useState(false)
 const [homeHost,setHomeHost]=useState<HTMLElement | null>(null)
 useEffect(() => {
  const change = () => { setRoute(currentRoute()); setMenu(false) }
  const push = history.pushState, replace = history.replaceState
  history.pushState = function (...args) { push.apply(this,args); change() }
  history.replaceState = function (...args) { replace.apply(this,args); change() }
  window.addEventListener('popstate',change)
  return () => { history.pushState=push; history.replaceState=replace; window.removeEventListener('popstate',change) }
 },[])
 const url = new URL(route,window.location.origin), path = url.pathname, legacy=url.searchParams.get('legacy') === '1'
 const homepage = path==='/'
 const match = path==='/match'
 const eligibility = path==='/scholarships' && (url.searchParams.get('view')==='eligibility' || legacy)
 const custom = eligibility || (!legacy && (match || ['/universities','/scholarships','/essay','/schools','/counselor-matcher','/report'].includes(path)))
 const [legacyLoaded,setLegacyLoaded] = useState(!custom)
 useEffect(() => { if (!custom) setLegacyLoaded(true) }, [custom])
 useEffect(() => {
  if (!homepage) return
  let host: HTMLElement | null = null
  const attach = () => {
   const main = document.querySelector('#nyansa-root main[data-source-loc="src/components/Layout.tsx:50:6"]')
   if (!main || !main.parentElement) return
   const existing = document.getElementById('home-dashboard')
   if (existing) { if (host !== existing) { host = existing; setHomeHost(existing) } return }
   host = document.createElement('div'); host.id = 'home-dashboard'; main.insertAdjacentElement('afterend', host); setHomeHost(host)
  }
  attach()
  const observer = new MutationObserver(attach); observer.observe(document.body, { childList: true, subtree: true })
  return () => { observer.disconnect(); host?.remove(); setHomeHost(null) }
 }, [homepage])
 const active = match || path==='/results' || path==='/report' ? '/match' : path==='/counselors' || path==='/counselor-matcher' ? '/schools' : path
 const title = tabs.find(t=>t.href===active)?.label || 'Nyansa'
 return <div className={homepage?'homepage-shell':'dashboard-shell'}>{!homepage && <><div className="dashboard-kente"/><header className="dashboard-header"><div className="dashboard-header-inner"><a href="/" className="dashboard-brand"><span className="dashboard-brand-mark">✳</span><span>Nyansa</span><small>GHANA</small></a><nav className="dashboard-desktop-nav" aria-label="Main navigation">{tabs.map(t=><a href={t.href} className={active===t.href?'active':''} key={t.href}>{t.label}</a>)}</nav><a className="dashboard-profile" href="/match">My profile <span>↗</span></a><div className="dashboard-mobile-title">{title}</div><button className="dashboard-menu-button" aria-label={menu?'Close menu':'Open menu'} aria-expanded={menu} onClick={()=>setMenu(!menu)}>{menu?<X size={21}/>:<Menu size={21}/>}</button></div>{menu && <nav className="dashboard-drawer" aria-label="Mobile menu">{tabs.map(t=><a href={t.href} className={active===t.href?'active':''} key={t.href}><t.icon size={17}/>{t.label}</a>)}<a href="/match">My profile →</a></nav>}</header></>}
 <div className={homepage?'homepage-legacy':custom?'dashboard-legacy-hidden':'dashboard-legacy'}>{legacyLoaded && children}</div>
 {homepage && homeHost && createPortal(<HomeDashboard/>, homeHost)}
 {custom && <Suspense fallback={<div className="db-loading">Loading your dashboard…</div>}>{match ? <GetMatched/> : path==='/universities' ? <Universities/> : path==='/scholarships' ? eligibility ? <ScholarshipEligibilityView/> : <Scholarships/> : path==='/essay' ? <EssayBuilder/> : path==='/schools' ? <Schools/> : path==='/report' ? <StudentReport/> : <CounselorMatcher/>}</Suspense>}
 {!homepage && <><footer className="dashboard-footer"><div><span>✳</span><b>Nyansa</b><small>Better choices, built on wisdom.</small></div><p>Planning estimates only. Confirm fees, deadlines and entry requirements directly with each institution.</p></footer>
 <nav className="dashboard-bottom-nav" aria-label="Mobile navigation">{tabs.map(t=><a href={t.href} className={active===t.href?'active':''} key={t.href}><t.icon size={19} strokeWidth={active===t.href?2.3:1.7}/><span>{t.mobile}</span></a>)}</nav></>}
 </div>
}
