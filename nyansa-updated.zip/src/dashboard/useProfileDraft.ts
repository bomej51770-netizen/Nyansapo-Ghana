import { useCallback, useEffect, useRef, useState } from 'react'
import { cloud } from '../cloudProfile'

type Envelope<T> = { value: T; updatedAt: number }
export function useProfileDraft<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(initial)
  const [ready, setReady] = useState(false)
  const [status, setStatus] = useState('Loading…')
  const scope = useRef('local-guest')
  const cloudUser = useRef(false)
  const latest = useRef<Envelope<T> | null>(null)
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const saveCloud = useCallback(async (entry: Envelope<T>) => {
    if (!cloud || !cloudUser.current) return
    try { const { error } = await cloud.auth.updateUser({ data: { [key]: entry } }); setStatus(error ? 'Saved on this device · sync unavailable' : 'Saved to your account') }
    catch { setStatus('Saved on this device · sync unavailable') }
  }, [key])
  useEffect(() => {
    let active = true
    const load = async () => {
      let remote: Envelope<T> | null = null
      try {
        if (cloud) {
          const { data } = await cloud.auth.getSession()
          if (data.session) {
            scope.current = data.session.user.id; cloudUser.current = true
            const result = await cloud.auth.getUser()
            if (result.error) throw result.error
            const record = result.data.user?.user_metadata?.[key]
            if (record && typeof record.updatedAt === 'number' && record.value) remote = record as Envelope<T>
          } else scope.current = `local-${localStorage.getItem('nyansa-active-handle-v1') || 'guest'}`
        } else scope.current = `local-${localStorage.getItem('nyansa-active-handle-v1') || 'guest'}`
      } catch { cloudUser.current = false }
      let local: Envelope<T> | null = null
      try { local = JSON.parse(localStorage.getItem(`nyansa-${key}-${scope.current}`) || 'null') } catch { /* Start clean. */ }
      const chosen = local && (!remote || local.updatedAt > remote.updatedAt) ? local : remote
      if (active) { if (chosen?.value) { setValue(chosen.value); latest.current = chosen } setStatus(cloudUser.current ? (local && (!remote || local.updatedAt > remote.updatedAt) ? 'Saved on this device · sync pending' : remote ? 'Saved to your account' : 'Ready to save to your account') : 'Saved on this device'); setReady(true); if (cloudUser.current && local && (!remote || local.updatedAt > remote.updatedAt)) timer.current = setTimeout(() => { timer.current = null; void saveCloud(local) }, 900) }
    }
    void load()
    return () => { active = false; if (timer.current) { clearTimeout(timer.current); timer.current = null; if (latest.current) void saveCloud(latest.current) } }
  }, [key, saveCloud])
  const update = (next: T | ((previous: T) => T)) => {
    setValue(previous => {
      const result = typeof next === 'function' ? (next as (v: T) => T)(previous) : next
      const entry = { value: result, updatedAt: Date.now() }; latest.current = entry
      try { localStorage.setItem(`nyansa-${key}-${scope.current}`, JSON.stringify(entry)); setStatus(cloudUser.current ? 'Saving…' : 'Saved on this device') } catch { setStatus('Device storage unavailable') }
      if (timer.current) clearTimeout(timer.current)
      if (cloudUser.current) timer.current = setTimeout(() => { timer.current = null; void saveCloud(entry) }, 900)
      return result
    })
  }
  return { value, update, ready, status }
}
