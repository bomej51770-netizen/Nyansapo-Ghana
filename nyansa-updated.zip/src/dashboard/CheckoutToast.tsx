import { useEffect } from 'react'
import './checkout-toast.css'
export default function CheckoutToast({ message, dismiss }: { message: string; dismiss: () => void }) {
  useEffect(() => { if (!message) return; const timer = setTimeout(dismiss, 8000); return () => clearTimeout(timer) }, [message, dismiss])
  if (!message) return null
  return <div className="checkout-toast" role="alert"><span>{message}</span><button type="button" aria-label="Dismiss notification" onClick={dismiss}>×</button></div>
}
