import { scholarships, type Scholarship } from './scholarshipData'
import { assessScholarship, defaultScholarshipFilters } from './scholarshipEligibility'

type LegacyScholarship = { id:string; name:string; provider:string; coverage:string; value:string; destination:'ghana'|'abroad'; deadline:string; requirements:string[]; link:string; institutions?:string[]; institutionTypes?:string[]; fields?:string[] }
type LegacyProfile = { income?:number; region?:string; interests?:string[]; gender?:string; typePref?:string }
const knownInstitutions:Record<string,string> = { UG:'ug',KNUST:'knust',Ashesi:'ashesi',UCC:'ucc',UDS:'uds',UEW:'uew',UMaT:'umat' }
const knownTypes:Record<string,string> = { 'Public University':'Public','Technical University':'Technical','Private University':'Private' }
const knownFields:Record<string,string> = { Computing:'computing',Engineering:'engineering',Health:'health',Science:'science',Education:'education',Business:'business',Arts:'arts',Agriculture:'agriculture' }
function legacyEntry(s:Scholarship):LegacyScholarship {
 const criterion=s.eligibility.institutionType
 const institutionIds=criterion.confidence==='reported' ? criterion.value?.institutions?.map(name=>knownInstitutions[name]).filter(Boolean) : undefined
 const types=criterion.confidence==='reported' ? criterion.value?.types?.map(name=>knownTypes[name]).filter(Boolean) : undefined
 const fields=s.eligibility.fieldOfStudy.confidence==='reported' ? s.eligibility.fieldOfStudy.value?.map(name=>knownFields[name]).filter(Boolean) : undefined
 return { id:s.id,name:s.name,provider:s.provider,coverage:s.coverage==='Full Ride'?'Full':s.coverage==='Loan'?'Loan':s.coverage==='Stipend/Allowance'?'Partial':'Tuition',value:s.note,destination:s.category==='International'||s.id==='secretariat-bilateral'?'abroad':'ghana',deadline:'Check provider',requirements:s.documents,link:s.link,...(institutionIds?.length?{institutions:institutionIds}:{}),...(types?.length?{institutionTypes:types}:{}),...(fields?.length?{fields}:{}) }
}
function legacyAssess(s:LegacyScholarship,profile:LegacyProfile,aggregate:number) {
 const source=scholarships.find(item=>item.id===s.id)
 if(!source)return {s,status:'possible',checks:[{ok:false,soft:true,text:'Eligibility requires provider confirmation.'}],score:0}
 const fields:Record<string,string> = {computing:'Computing',engineering:'Engineering',health:'Health',science:'Science',education:'Education',business:'Business',arts:'Arts',agriculture:'Agriculture'}
 const incomes=['Below GHS 1,500 / month','GHS 1,500–4,000 / month','GHS 4,000–10,000 / month','Above GHS 10,000 / month']
 const filters={...defaultScholarshipFilters,aggregate:Math.max(6,Math.min(54,aggregate)),incomeLevel:profile.income===undefined?'Not provided':incomes[profile.income]||'Not provided',region:profile.region||'Unknown',fieldOfStudy:fields[profile.interests?.[0]||'']||'Any field',gender:profile.gender==='female'?'Female':profile.gender==='male'?'Male':'Unknown'}
 const result=assessScholarship(source,filters)
 return {s,status:result.notMet?'not':'possible',checks:result.checks.map(check=>({ok:check.status==='met',soft:check.status==='unknown',text:`${check.label}: ${check.detail}`})),score:result.met*5-result.notMet*15}
}
declare global { interface Window { __NYANSA_LEGACY_SCHOLARSHIPS__?:LegacyScholarship[]; __NYANSA_LEGACY_ASSESS__?:typeof legacyAssess } }
export function installLegacyScholarshipBridge() { window.__NYANSA_LEGACY_SCHOLARSHIPS__=scholarships.map(legacyEntry); window.__NYANSA_LEGACY_ASSESS__=legacyAssess }
