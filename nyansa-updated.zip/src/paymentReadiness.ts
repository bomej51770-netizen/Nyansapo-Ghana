import type { Session } from '@supabase/supabase-js'

export async function ensurePaymentReady(session: Session, product: 'student_report' | 'counselor_term', publicKey: string) {
  const environment = publicKey.startsWith('pk_test_') ? 'test' : 'live'
  const response = await fetch('/api/payment-readiness', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session.access_token}` }, body: JSON.stringify({ product, environment }) })
  const data = await response.json().catch(() => ({}))
  if (!response.ok || data.ready !== true) throw new Error(data.error || 'Secure checkout is unavailable. No payment was started.')
}
