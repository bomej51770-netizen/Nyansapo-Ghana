import { useEffect } from 'react'
import AuthGate from './AuthGate'
import { repairScholarshipLinks } from './repairScholarshipLinks'
import PricingEnhancements from './PricingEnhancements'
import { addCounselorMatcherLink } from './counselor/addCounselorMatcherLink'
import PartnerOnboarding from './partners/PartnerOnboarding'
import DashboardShell from './dashboard/DashboardShell'
import GuestCheckout from './dashboard/GuestCheckout'
import { syncInstitutionStats } from './dashboard/syncInstitutionStats'
import { installLegacyScholarshipBridge } from './dashboard/legacyScholarshipBridge'

function NyansaApp() {
  useEffect(() => {
    if (document.querySelector('[data-nyansa-app]')) return
    installLegacyScholarshipBridge()
    const script = document.createElement('script')
    script.type = 'module'
    script.src = '/nyansa-legacy-shared.js'
    script.dataset.nyansaApp = 'true'
    document.body.appendChild(script)
  }, [])

  return <div id="nyansa-root" />
}

function App() {
  useEffect(() => repairScholarshipLinks(), [])
  useEffect(() => addCounselorMatcherLink(), [])
  useEffect(() => syncInstitutionStats(), [])
  return <AuthGate><DashboardShell><NyansaApp /></DashboardShell><GuestCheckout /><PricingEnhancements /><PartnerOnboarding /></AuthGate>
}

export default App
