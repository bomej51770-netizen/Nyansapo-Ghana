export type PendingPaystackPlan = 'student_report' | 'counselor_starter' | 'counselor_pro'
const storageKey = 'pending_paystack_plan'
export function rememberPaystackPlan(plan: PendingPaystackPlan): boolean { try { localStorage.setItem(storageKey, plan); return true } catch { return false } }
export function pendingPaystackPlan(): PendingPaystackPlan | null { try { const value = localStorage.getItem(storageKey); return value === 'student_report' || value === 'counselor_starter' || value === 'counselor_pro' ? value : null } catch { return null } }
export function clearPendingPaystackPlan() { try { localStorage.removeItem(storageKey) } catch { /* Storage can be unavailable. */ } }
export const resumePaystackLocation = '/?resume_checkout=1#home-dashboard'
