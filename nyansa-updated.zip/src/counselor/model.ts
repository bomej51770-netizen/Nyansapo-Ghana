export const gradeOptions = ['A1', 'B2', 'B3', 'C4', 'C5', 'C6', 'D7', 'E8', 'F9'] as const
export type Grade = '' | typeof gradeOptions[number]
export const gradeKeys = ['english', 'maths', 'science', 'social', 'elective1', 'elective2', 'elective3', 'elective4'] as const
export type GradeKey = typeof gradeKeys[number]
export type Student = { id: string; name: string; interest: string; grades: Record<GradeKey, Grade>; notes: string; recommendation: string }
export type Cohort = { id: string; name: string; plan: 'Starter' | 'Pro'; students: Student[] }
export type Status = 'At-Risk' | 'Needs Trade-Off' | 'Safe Match' | 'Needs Grades'
export const labels: Record<GradeKey, string> = { english: 'English', maths: 'Core Maths', science: 'Science', social: 'Social Studies', elective1: 'Elective 1', elective2: 'Elective 2', elective3: 'Elective 3', elective4: 'Elective 4' }
export function blankStudent(name = ''): Student { return { id: crypto.randomUUID(), name, interest: 'Undecided', grades: { english: '', maths: '', science: '', social: '', elective1: '', elective2: '', elective3: '', elective4: '' }, notes: '', recommendation: '' } }
export function assess(s: Student) {
  const n = (grade: Grade) => grade ? Number(grade.slice(1)) : 0
  const core = [n(s.grades.science), n(s.grades.social)].filter(Boolean).sort((a, b) => a - b)
  const electives = [s.grades.elective1, s.grades.elective2, s.grades.elective3, s.grades.elective4].map(n).filter(Boolean).sort((a, b) => a - b)
  const english = n(s.grades.english), maths = n(s.grades.maths)
  const aggregate = english && maths && core.length && electives.length >= 3 ? english + maths + core[0] + electives[0] + electives[1] + electives[2] : null
  const coreWarnings = (['english', 'maths', 'science', 'social'] as GradeKey[]).filter(k => n(s.grades[k]) >= 7).map(k => `${labels[k]} ${s.grades[k]}`)
  let status: Status = 'Needs Grades'
  if (coreWarnings.length) status = 'At-Risk'
  else if (aggregate !== null) status = aggregate > 24 || electives.slice(0, 3).some(v => v >= 7) ? 'Needs Trade-Off' : 'Safe Match'
  return { aggregate, status, coreWarnings, electiveWarning: electives.some(v => v >= 7) }
}
export const demoCohorts = (): Cohort[] => {
  const ama = blankStudent('Ama Mensah'); ama.interest = 'Engineering & technology'; ama.grades = { english: 'B3', maths: 'B2', science: 'B3', social: 'C4', elective1: 'B3', elective2: 'C4', elective3: 'B2', elective4: 'C5' }
  const kwame = blankStudent('Kwame Asare'); kwame.interest = 'Business'; kwame.grades = { english: 'C5', maths: 'D7', science: 'C6', social: 'C5', elective1: 'C5', elective2: 'C6', elective3: 'D7', elective4: 'C6' }
  const efua = blankStudent('Efua Boateng'); efua.interest = 'Health'; efua.grades = { english: 'C4', maths: 'C5', science: 'C5', social: 'C6', elective1: 'C5', elective2: 'C6', elective3: 'C6', elective4: '' }
  return [{ id: crypto.randomUUID(), name: '2026 Sample Cohort', plan: 'Starter', students: [ama, kwame, efua] }]
}
export function parseCSV(text: string): string[][] {
  const rows: string[][] = []; let row: string[] = []; let field = ''; let quoted = false
  const input = text.replace(/^\uFEFF/, '')
  for (let i = 0; i < input.length; i++) { const c = input[i]; if (quoted) { if (c === '"' && input[i + 1] === '"') { field += '"'; i++ } else if (c === '"') quoted = false; else field += c } else if (c === '"' && field === '') quoted = true; else if (c === ',') { row.push(field); field = '' } else if (c === '\n' || c === '\r') { if (c === '\r' && input[i + 1] === '\n') i++; row.push(field); rows.push(row); row = []; field = '' } else field += c }
  if (quoted) throw new Error('CSV has an unclosed quoted field.')
  if (field || row.length) { row.push(field); rows.push(row) }
  return rows.filter(r => r.some(x => x.trim()))
}
export const csvHeaders = ['Name', 'Interest', ...gradeKeys.map(k => labels[k]), 'Aggregate', 'Status', 'Core warnings', 'Notes', 'Recommended choice']
export function escapeCSV(value: string | number | null) { const text = String(value ?? ''); const safe = /^[=+\-@\t\r]/.test(text) ? "'" + text : text; return '"' + safe.replace(/"/g, '""') + '"' }
export function csvFor(students: Student[]) { return [csvHeaders.map(escapeCSV).join(','), ...students.map(s => { const a = assess(s); return [s.name, s.interest, ...gradeKeys.map(k => s.grades[k]), a.aggregate, a.status, a.coreWarnings.join('; '), s.notes, s.recommendation].map(escapeCSV).join(',') })].join('\r\n') }
export function importStudents(text: string): Student[] {
  const rows = parseCSV(text); if (!rows.length) throw new Error('The CSV file is empty.')
  const headers = rows[0].map(v => v.trim().toLowerCase()); const nameIndex = headers.indexOf('name'); if (nameIndex < 0) throw new Error('CSV needs a Name column. Download the template for the grade columns.')
  return rows.slice(1).map((row, index) => { const name = (row[nameIndex] || '').trim(); if (!name) throw new Error(`Row ${index + 2} needs a student name.`); const s = blankStudent(name); const interest = headers.indexOf('interest'); if (interest >= 0 && row[interest]?.trim()) s.interest = row[interest].trim(); for (const k of gradeKeys) { const col = headers.indexOf(labels[k].toLowerCase()); if (col < 0) continue; const value = (row[col] || '').trim().toUpperCase(); if (value && !gradeOptions.includes(value as typeof gradeOptions[number])) throw new Error(`Row ${index + 2}: ${labels[k]} must be A1–F9 or blank.`); s.grades[k] = value as Grade } const notes = headers.indexOf('notes'), choice = headers.indexOf('recommended choice'); if (notes >= 0) s.notes = row[notes] || ''; if (choice >= 0) s.recommendation = row[choice] || ''; return s })
}
