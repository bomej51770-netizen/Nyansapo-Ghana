export function addCounselorMatcherLink() {
  const add = () => {
    if (window.location.pathname !== '/counselors') return
    const page = document.querySelector('[data-source-loc="src/pages/Counselors.tsx:70:4"]')
    if (!page || page.querySelector('[data-matcher-link]')) return
    const card = document.createElement('div')
    card.dataset.matcherLink = 'true'
    card.className = 'counselor-link-banner'
    const text = document.createElement('div')
    const title = document.createElement('strong'); title.textContent = 'New · Cohort & Trade-Off Matcher'
    const description = document.createElement('p'); description.textContent = 'Enter WASSCE grades, flag students needing support and compare possible pathways.'
    text.append(title, description)
    const link = document.createElement('a'); link.href = '/counselor-matcher'; link.textContent = 'Open matcher →'
    card.append(text, link)
    const first = page.firstElementChild
    if (first) first.insertAdjacentElement('afterend', card); else page.prepend(card)
  }
  add(); const observer = new MutationObserver(add); observer.observe(document.body, { childList: true, subtree: true }); return () => observer.disconnect()
}
