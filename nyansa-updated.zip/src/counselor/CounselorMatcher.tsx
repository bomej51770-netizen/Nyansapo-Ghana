import { useEffect, useMemo, useRef, useState } from 'react'
import { ArrowLeft, ArrowRight, BookOpen, ChevronDown, Download, FileUp, GraduationCap, Plus, ShieldCheck, Users, X } from 'lucide-react'
import type { User } from '@supabase/supabase-js'
import { cloud } from '../cloudProfile'
import { checkPurchasedPlan } from '../guestPayments'
import { findVerifiedCallbackUnlock } from '../localCallbackUnlock'
import { assess, blankStudent, csvFor, csvHeaders, demoCohorts, escapeCSV, gradeKeys, gradeOptions, importStudents, labels, type Cohort, type Grade, type GradeKey, type Student } from './model'
import './counselor.css'

const interestOptions = ['Undecided', 'Engineering & technology', 'Computing', 'Business', 'Health', 'Education', 'Arts & humanities']
function saveFile(filename: string, content: string) { const url = URL.createObjectURL(new Blob(['\ufeff', content], { type: 'text/csv;charset=utf-8' })); const link = document.createElement('a'); link.href = url; link.download = filename; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000) }
function safeName(value: string) { return value.replace(/[^a-z0-9-]+/gi, '-').replace(/^-|-$/g, '').toLowerCase() || 'cohort' }

export default function CounselorMatcher() {
  const [user, setUser] = useState<User | null>(null)
  const [cohorts, setCohorts] = useState<Cohort[]>(demoCohorts)
  const [cohortId, setCohortId] = useState('')
  const [status, setStatus] = useState('All students')
  const [search, setSearch] = useState('')
  const [newName, setNewName] = useState('')
  const [drawerId, setDrawerId] = useState<string | null>(null)
  const [notice, setNotice] = useState('Loading workspace…')
  const [message, setMessage] = useState('')
  const [storage, setStorage] = useState<'loading' | 'cloud' | 'local' | 'demo'>('loading')
  const [dirty, setDirty] = useState(false)
  const [saving, setSaving] = useState(false)
  const [entitlement, setEntitlement] = useState<{ plan: 'starter' | 'pro'; term_status: string; term_start: string; term_end: string } | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)
  const cohort = cohorts.find(c => c.id === cohortId) || cohorts[0]
  const students = cohort?.students || []
  const total = students.length
  const counts = useMemo(() => ({ risk: students.filter(s => assess(s).status === 'At-Risk').length, trade: students.filter(s => assess(s).status === 'Needs Trade-Off').length, safe: students.filter(s => assess(s).status === 'Safe Match').length }), [students])
  const filtered = students.filter(s => (status === 'All students' || assess(s).status === status || (status === 'Core warning' && assess(s).coreWarnings.length > 0)) && s.name.toLowerCase().includes(search.toLowerCase()))
  const selected = students.find(s => s.id === drawerId)

  useEffect(() => {
    let active = true
    const load = async () => {
      if (!cloud) { if (active) { setStorage('demo'); setNotice('Demo workspace · sign in with email to save your own cohorts.') }; return }
      const { data: auth } = await cloud.auth.getSession()
      const current = auth.session?.user || null
      if (!active) return
      setUser(current)
      if (!current) { setStorage('demo'); setNotice('Demo workspace · sign in with email to save your own cohorts.'); return }
      try {
        const { data, error } = await cloud.from('counselor_workspaces').select('cohorts').eq('owner_id', current.id).maybeSingle()
        if (error) throw error
        if (!active) return
        const backup = localStorage.getItem(`nyansa-counselor-${current.id}`)
        if (backup) {
          const parsed = JSON.parse(backup) as Cohort[]
          if (Array.isArray(parsed) && parsed.length) { setCohorts(parsed); setCohortId(parsed[0].id); setDirty(true); setNotice('A browser backup is available. Review it and select Save workspace to sync it to your account.') }
        }
        else if (data && Array.isArray(data.cohorts) && data.cohorts.length) { setCohorts(data.cohorts as Cohort[]); setCohortId(data.cohorts[0].id); setNotice('Cloud workspace · changes are saved when you select Save workspace.') }
        else setNotice('Example cohort · edit it or add your own, then save to your account.')
        setStorage('cloud')
      } catch {
        if (!active) return
        try { const saved = localStorage.getItem(`nyansa-counselor-${current.id}`); if (saved) { const parsed = JSON.parse(saved) as Cohort[]; if (Array.isArray(parsed) && parsed.length) { setCohorts(parsed); setCohortId(parsed[0].id) } } } catch { /* Start with example data. */ }
        setStorage('local'); setNotice('Database unavailable · example or account-scoped browser data only. Not synced; avoid shared devices.')
      }
    }
    void load()
    return () => { active = false }
  }, [])

  useEffect(() => {
    let active = true
    const load = async () => {
      const key = (import.meta.env.VITE_PAYSTACK_PUBLIC_KEY as string | undefined)?.replace(/^pk_test_pk_test_/, 'pk_test_')
      const environment = key?.startsWith('pk_live_') ? 'live' : 'test'
      let currentUser = user?.id || null
      try { if (cloud) { const { data } = await cloud.auth.getSession(); currentUser = data.session?.user.id || null } } catch { /* Guest preview remains available. */ }
      try {
        for (const plan of ['counselor_pro', 'counselor_starter'] as const) {
          const local = await findVerifiedCallbackUnlock(plan, currentUser, environment)
          if (local) {
            if (active) setEntitlement({ plan: plan === 'counselor_pro' ? 'pro' : 'starter', term_status: environment === 'test' ? 'test_active' : 'active', term_start: local.created_at, term_end: new Date(Date.parse(local.created_at) + 90 * 86400000).toISOString() })
            return
          }
        }
      } catch { /* Try existing server-verified account entitlements. */ }
      try {
        for (const plan of ['counselor_pro', 'counselor_starter'] as const) {
          const receipt = await checkPurchasedPlan(plan)
          if (receipt && ['verified', 'test_verified'].includes(receipt.status) && receipt.term_end && new Date(receipt.term_end).getTime() > Date.now()) {
            if (active) setEntitlement({ plan: plan === 'counselor_pro' ? 'pro' : 'starter', term_status: receipt.status === 'test_verified' ? 'test_active' : 'active', term_start: receipt.term_start, term_end: receipt.term_end })
            return
          }
        }
      } catch { /* Try existing account entitlements. */ }
      if (!user || !cloud) { if (active) setEntitlement(null); return }
      const { data, error } = await cloud.from('counselor_entitlements').select('plan,term_status,term_start,term_end').eq('owner_id', user.id).eq('environment', environment).maybeSingle()
      if (active && !error && data) setEntitlement(data as typeof entitlement)
    }
    void load()
    return () => { active = false }
  }, [user?.id])

  const updateCohort = (fn: (c: Cohort) => Cohort) => { if (!cohort) return; setCohorts(old => old.map(c => c.id === cohort.id ? fn(c) : c)); setDirty(true) }
  const updateStudent = (id: string, change: Partial<Student>) => updateCohort(c => ({ ...c, students: c.students.map(s => s.id === id ? { ...s, ...change } : s) }))
  const updateGrade = (student: Student, key: GradeKey, value: Grade) => updateStudent(student.id, { grades: { ...student.grades, [key]: value } })
  const addStudent = () => {
    const name = newName.trim(); if (!name) { setMessage('Enter a student name first.'); return }
    if (cohort.plan === 'Starter' && total >= 150) { setMessage('Starter supports up to 150 students per cohort. Choose Pro for a larger cohort.'); return }
    updateCohort(c => ({ ...c, students: [...c.students, blankStudent(name)] })); setNewName(''); setMessage('Student added. Enter their grades below.')
  }
  const importFile = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]; event.target.value = ''; if (!file) return
    try { const incoming = importStudents(await file.text()); if (!incoming.length) throw new Error('No student rows found.'); if (cohort.plan === 'Starter' && total + incoming.length > 150) throw new Error('Import exceeds the Starter limit of 150 students for this cohort.'); updateCohort(c => ({ ...c, students: [...c.students, ...incoming] })); setMessage(`Imported ${incoming.length} student${incoming.length === 1 ? '' : 's'}. Review their grades before saving.`) } catch (e) { setMessage(e instanceof Error ? e.message : 'Could not read the CSV file.') }
  }
  const saveWorkspace = async () => {
    if (!user || !cloud) { setMessage('Sign in with an email account to save cohorts. Demo changes are temporary.'); return }
    setSaving(true); setMessage('')
    try {
      const { error } = await cloud.from('counselor_workspaces').upsert({ owner_id: user.id, cohorts, updated_at: new Date().toISOString() }, { onConflict: 'owner_id' })
      if (error) throw error
      localStorage.removeItem(`nyansa-counselor-${user.id}`)
      setStorage('cloud'); setDirty(false); setNotice('Saved to your Supabase account.'); setMessage('Workspace saved.')
    } catch {
      try { localStorage.setItem(`nyansa-counselor-${user.id}`, JSON.stringify(cohorts)); setStorage('local'); setDirty(false); setNotice('Saved on this browser only · database unavailable. Not synced; avoid shared devices.'); setMessage('Saved locally, not to Supabase. Configure the counselor_workspaces table for cloud saving.') }
      catch { setMessage('Could not save to Supabase or this browser. Export a CSV to avoid losing your work.') }
    } finally { setSaving(false) }
  }
  const addCohort = () => { const name = window.prompt('Name your new cohort:')?.trim(); if (!name) return; const next: Cohort = { id: crypto.randomUUID(), name, plan: 'Starter', students: [] }; setCohorts(c => [...c, next]); setCohortId(next.id); setDirty(true); setMessage('New cohort created. Save your workspace to keep it.') }
  const removeStudent = (id: string) => { if (window.confirm('Remove this student from the cohort?')) { updateCohort(c => ({ ...c, students: c.students.filter(s => s.id !== id) })); if (drawerId === id) setDrawerId(null) } }
  const planChange = (value: 'Starter' | 'Pro') => { if (value === 'Starter' && total > 150) { setMessage('Starter is limited to 150 students per cohort. Reduce the cohort before switching.'); return } updateCohort(c => ({ ...c, plan: value })) }

  return <div className="cm-app">
    <div className="cm-stripe" />
    <header className="cm-header"><a href="/" className="cm-brand"><span>✳</span>Nyansa <small>GHANA</small></a><nav><a href="/counselors"><ArrowLeft size={15} /> Counselor dashboard</a><a href="/pricing#schools">School pricing</a></nav><span className="cm-header-tag">COUNSELOR WORKSPACE</span></header>
    <main className="cm-main">
      <div className="cm-breadcrumb"><a href="/counselors">For schools</a><span>/</span> Cohort & trade-off matcher</div>
      <div className="cm-title-row"><div><p className="cm-eyebrow">COUNSELOR TOOLS <span>✳</span> WORKSPACE</p><h1>A clearer path for <em>every student.</em></h1><p className="cm-subtitle">Track a cohort, spot students who need support and explore the trade-offs together.</p></div><a className="cm-back" href="/counselors">Back to dashboard <ArrowRight size={15}/></a></div>
      <div className={`cm-storage ${storage}`}><ShieldCheck size={17}/><span>{notice}{dirty ? ' · Unsaved changes' : ''}</span>{!user && <a href="/match">Sign in with email →</a>}</div>
      <div className="cm-layout"><aside className="cm-sidebar"><div className="cm-side-head"><span>YOUR COHORTS</span><button onClick={addCohort} aria-label="Add cohort"><Plus size={17}/></button></div><div className="cm-cohort-list">{cohorts.map(c => <button key={c.id} className={cohort?.id === c.id ? 'active' : ''} onClick={() => { setCohortId(c.id); setDrawerId(null); setStatus('All students'); setMessage('') }}><span className="cm-cohort-icon"><Users size={17}/></span><span><strong>{c.name}</strong><small>{c.students.length} students · {c.plan}</small></span><ArrowRight size={14}/></button>)}</div><button className="cm-new-cohort" onClick={addCohort}><Plus size={15}/> New cohort</button><div className="cm-side-note"><BookOpen size={17}/><b>Before you advise</b><p>Flags are planning prompts, not admission decisions. Always check current entry requirements with the institution.</p></div></aside>
      <section className="cm-workspace">{cohort && <>
        <div className="cm-workspace-head"><div><p className="cm-eyebrow">COHORT OVERVIEW</p><h2>{cohort.name}</h2><p>WASSCE / mock grades · {total} student{total === 1 ? '' : 's'}</p></div><div className="cm-head-actions"><button className="cm-outline" onClick={() => saveFile(`${safeName(cohort.name)}-cohort.csv`, csvFor(students))}><Download size={16}/> Export CSV</button><button className="cm-primary" onClick={saveWorkspace} disabled={saving}>{saving ? 'Saving…' : 'Save workspace'}</button></div></div>
        <div className="cm-plan"><div><span className="cm-plan-icon"><GraduationCap size={20}/></span><div><b>Counselor {cohort.plan}</b><p>{cohort.plan === 'Starter' ? 'GHS 400 / term · Up to 150 students, dashboard, CSV export & flags' : 'GHS 900 / term · Larger cohorts, premium and trade-off reports'}</p></div></div><label>Planning plan <select value={cohort.plan} onChange={e => planChange(e.target.value as 'Starter' | 'Pro')}><option>Starter</option><option>Pro</option></select></label></div><p className="cm-plan-disclaimer">Plan selection is for planning only; it does not purchase or verify a licence. <a href="/pricing#schools">See school pricing →</a></p>{entitlement && <p className="cm-entitlement">Verified {entitlement.term_status === 'test_active' ? 'test ' : ''}{entitlement.plan} term · {new Date(entitlement.term_end).getTime() > Date.now() ? 'ends' : 'expired'} {new Date(entitlement.term_end).toLocaleDateString()} {entitlement.term_status === 'test_active' && '· not a paid licence'}</p>}
        <div className="cm-stats"><div><span>STUDENTS</span><strong>{total}</strong><small>in this cohort</small></div><div><span>AT-RISK</span><strong className="rust">{counts.risk}</strong><small>core grade warning</small></div><div><span>NEEDS TRADE-OFF</span><strong className="ochre">{counts.trade}</strong><small>review alternatives</small></div><div><span>SAFE MATCH</span><strong className="green">{counts.safe}</strong><small>planning indicator only</small></div></div>
        <div className="cm-table-card"><div className="cm-table-heading"><div><p className="cm-eyebrow">THE COHORT</p><h3>Student gradebook <span>{total}</span></h3><p>Enter grades or import the template. Changes apply immediately.</p></div><div className="cm-table-actions"><button className="cm-outline" onClick={() => saveFile('nyansa-grade-template.csv', csvHeaders.map(escapeCSV).join(','))}><Download size={15}/> Template</button><button className="cm-outline" onClick={() => fileRef.current?.click()}><FileUp size={15}/> Import CSV</button><input ref={fileRef} type="file" accept=".csv,text/csv" hidden onChange={importFile}/></div></div>
        <div className="cm-controls"><div className="cm-add"><input value={newName} onChange={e => setNewName(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') addStudent() }} placeholder="Student name" aria-label="New student name"/><button onClick={addStudent}><Plus size={15}/> Add student</button></div><input className="cm-search" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search students…" aria-label="Search students"/><label className="cm-filter"><span>Filter</span><select value={status} onChange={e => setStatus(e.target.value)}><option>All students</option><option>At-Risk</option><option>Needs Trade-Off</option><option>Safe Match</option><option>Needs Grades</option><option>Core warning</option></select><ChevronDown size={14}/></label></div>
        {message && <p className="cm-message" role="status">{message}</p>}
        <div className="cm-table-scroll"><table className="cm-table"><thead><tr><th>STUDENT / INTEREST</th>{gradeKeys.map(k => <th key={k}>{labels[k].toUpperCase()}</th>)}<th>AGG.</th><th>FLAG</th><th></th></tr></thead><tbody>{filtered.map(s => { const a = assess(s); return <tr key={s.id}><td className="cm-student"><input aria-label={`Name for ${s.name}`} value={s.name} onChange={e => updateStudent(s.id, { name: e.target.value })}/><select aria-label={`Interest for ${s.name}`} value={s.interest} onChange={e => updateStudent(s.id, { interest: e.target.value })}>{!interestOptions.includes(s.interest) && <option>{s.interest}</option>}{interestOptions.map(i => <option key={i}>{i}</option>)}</select></td>{gradeKeys.map(k => <td key={k}><select aria-label={`${labels[k]} grade for ${s.name}`} value={s.grades[k]} onChange={e => updateGrade(s, k, e.target.value as Grade)}><option value="">—</option>{gradeOptions.map(g => <option key={g}>{g}</option>)}</select></td>)}<td className="cm-aggregate">{a.aggregate ?? '—'}</td><td><span className={`cm-badge ${a.status.toLowerCase().replaceAll(' ', '-').replaceAll('--', '-')}`}>{a.status}</span>{a.coreWarnings.length > 0 && <small className="cm-warning">Core: {a.coreWarnings.join(', ')}</small>}{a.electiveWarning && <small className="cm-warning">D7+ elective</small>}</td><td><button className="cm-review" onClick={() => setDrawerId(s.id)}>Review →</button><button className="cm-remove" onClick={() => removeStudent(s.id)} aria-label={`Remove ${s.name}`}><X size={14}/></button></td></tr> })}</tbody></table>{filtered.length === 0 && <div className="cm-empty">No students match this view. Add a student or change the filter.</div>}</div>
        <div className="cm-table-footer"><span>Showing {filtered.length} of {total} students</span><span>Aggregate = English + Core Maths + best of Science / Social Studies + best 3 electives.</span></div></div>
        <div className="cm-disclaimer"><b>Use with care.</b> D7 or lower in any entered core subject triggers an At-Risk warning. A complete aggregate above 24 or a selected elective of D7 or lower triggers Needs Trade-Off; other complete records are labelled Safe Match. These are simple planning rules, not verified cut-offs, eligibility checks or admission guarantees. Elective subject names and programme-specific requirements must be checked separately.</div>
      </>}</section></div>
    </main>
    {selected && <TradeOffDrawer student={selected} close={() => setDrawerId(null)} update={change => updateStudent(selected.id, change)}/>}
  </div>
}

function TradeOffDrawer({ student, close, update }: { student: Student; close: () => void; update: (change: Partial<Student>) => void }) {
  const a = assess(student)
  const options = [
    { title: 'Competitive university', type: 'ASPIRATIONAL', examples: 'e.g. University of Ghana or KNUST', fit: 'Explore programmes aligned with the student’s interest.', trade: 'More competitive; check subject prerequisites and current cut-offs.' },
    { title: 'Alternative public university', type: 'COMPARE', examples: 'e.g. a regional public university', fit: 'Compare a related programme with potentially broader entry options.', trade: 'Check location, total living costs and programme-specific entry rules.' },
    { title: 'Technical / HND', type: 'ALTERNATIVE PATH', examples: 'e.g. an accredited technical university', fit: 'Consider practical or applied programmes relevant to the student’s goals.', trade: 'Check the qualification, progression routes and required electives.' },
    { title: 'Nursing pathway', type: 'ALTERNATIVE PATH', examples: 'e.g. an accredited nursing training institution', fit: 'Explore for students interested in health and patient care.', trade: 'Verify subject requirements, accreditation and intake availability.' },
    { title: 'College of Education', type: 'ALTERNATIVE PATH', examples: 'e.g. an accredited college of education', fit: 'Consider for students interested in teaching.', trade: 'Check teaching specialisms, admission requirements and location.' },
  ]
  useEffect(() => {
    const container = document.querySelector('.cm-notes')
    if (!container) return
    const button = document.createElement('button')
    button.type = 'button'
    button.className = 'cm-report-button'
    button.textContent = 'Download trade-off report'
    button.onclick = () => {
      const summary = [`NYANSA · TRADE-OFF & COUNSELING REPORT`, `Student: ${student.name}`, `Interest: ${student.interest}`, `Aggregate: ${a.aggregate ?? 'Incomplete'}`, `Planning flag: ${a.status}`, `Core warnings: ${a.coreWarnings.join(', ') || 'None'}`, '', 'POSSIBLE PATHWAYS', ...options.map(o => `\n${o.title} — ${o.examples}\nFit: ${o.fit}\nTrade-off: ${o.trade}`), '', 'STREAMS: Verify Regular, Fee-Paying and Distance availability, entry requirements and fees.', `Recommended choice: ${student.recommendation || 'Not selected'}`, `Counseling notes: ${student.notes || 'None'}`, '', 'Planning aid only: confirm entry requirements, cut-offs, fees and accreditation with each institution.'].join('\n')
      const url = URL.createObjectURL(new Blob([summary], { type: 'text/plain;charset=utf-8' }))
      const link = document.createElement('a'); link.href = url; link.download = `${safeName(student.name)}-trade-off-report.txt`; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000)
    }
    container.appendChild(button)
    return () => button.remove()
  }, [student])
  return <div className="cm-drawer-overlay" onMouseDown={e => { if (e.currentTarget === e.target) close() }}><aside className="cm-drawer" role="dialog" aria-modal="true" aria-labelledby="trade-title"><div className="cm-drawer-head"><div><p className="cm-eyebrow">STUDENT REVIEW</p><h2 id="trade-title">Trade-Off & Counseling</h2><p>{student.name} · {student.interest} · Aggregate {a.aggregate ?? 'incomplete'}</p></div><button onClick={close} aria-label="Close student review"><X size={20}/></button></div><div className="cm-drawer-body"><div className="cm-student-alert"><span className={`cm-badge ${a.status.toLowerCase().replaceAll(' ', '-').replaceAll('--', '-')}`}>{a.status}</span><p>{a.coreWarnings.length ? `Core warning: ${a.coreWarnings.join(', ')}.` : 'Use these options as starting points for a conversation.'} {a.electiveWarning ? 'An elective has D7 or lower.' : ''}</p></div><p className="cm-drawer-intro">Compare possible routes side by side. These examples are not personalised admission predictions. Confirm the student’s elective subjects, cut-offs, fees and programme availability.</p><div className="cm-options">{options.map(o => <article key={o.title}><span>{o.type}</span><h3>{o.title}</h3><p className="cm-option-examples">{o.examples}</p><p><b>Programme fit</b>{o.fit}</p><p><b>Trade-off / check</b>{o.trade}</p></article>)}</div><div className="cm-streams"><h3>Compare admission streams</h3><div><p><b>Regular</b>Check standard entry requirements and published fees.</p><p><b>Fee-Paying</b>May cost more; availability and entry criteria vary by programme.</p><p><b>Distance</b>May offer flexibility; confirm the programme, entry criteria and study format.</p></div></div><div className="cm-notes"><h3>Counselor's recommendation</h3><label>Recommended choice<select value={student.recommendation} onChange={e => update({ recommendation: e.target.value })}><option value="">Select a path to discuss</option>{options.map(o => <option key={o.title}>{o.title}</option>)}</select></label><label>Counseling notes<textarea rows={4} value={student.notes} onChange={e => update({ notes: e.target.value })} placeholder="Record agreed next steps, questions and follow-up…"/></label><p>Notes and choices are included when you save the workspace. Avoid sensitive personal information.</p><button onClick={close}>Done · return to cohort</button></div></div></aside></div>
}
