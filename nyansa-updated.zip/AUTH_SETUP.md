# Email and Google account setup

Handle/password profiles work locally in a single browser. To enable email and Google accounts with cross-device profile restoration, connect a Supabase project:

1. Set `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` to your project's URL and public anon key in the deployment environment, then redeploy. Never use the service-role key.
2. Enable email/password authentication and configure the site URL. Add `https://YOUR-SITE/match` to allowed redirect URLs.
3. Enable Google in Supabase Auth and configure its Google OAuth client and Supabase callback URL.

Cloud profiles are stored in the authenticated user's Supabase user metadata. Email and Google options clearly report that setup is needed when the environment variables are absent. Local handles remain device-only and are not automatically linked to cloud accounts.
