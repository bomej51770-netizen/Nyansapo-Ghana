import { defineConfig, loadEnv, type Plugin } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import { existsSync, readFileSync, unlinkSync } from 'node:fs'
import { resolve } from 'node:path'

function sharedLegacyScholarships(): Plugin {
  const transform = () => {
    let code = readFileSync(resolve(process.cwd(), 'public/nyansa-app.js'), 'utf8')
    const start = code.indexOf('Lh=['), end = code.indexOf('];function cc(s)', start)
    if (start < 0 || end < 0) throw new Error('Legacy scholarship boundary was not found.')
    code = code.slice(0, start) + 'Lh=window.__NYANSA_LEGACY_SCHOLARSHIPS__' + code.slice(end + 1)
    const assessStart = code.indexOf('function gb(s,i,l){'), assessEnd = code.indexOf('function SC(s,i){', assessStart)
    if (assessStart < 0 || assessEnd < 0) throw new Error('Legacy eligibility boundary was not found.')
    code = code.slice(0, assessStart) + 'function gb(s,i,l){return window.__NYANSA_LEGACY_ASSESS__(s,i,l)}' + code.slice(assessEnd)
    const aidStart = code.indexOf('function SC(s,i){'), aidEnd = code.indexOf('function Co(s,i){', aidStart)
    if (aidStart < 0 || aidEnd < 0) throw new Error('Legacy aid calculation boundary was not found.')
    code = code.slice(0, aidStart) + 'function SC(s,i){return 0}' + code.slice(aidEnd)
    return code.replace('children:"Scholarships found"', 'children:"Potential funding"')
      .replace('s.scholarships.filter(d=>d.status==="eligible").length', 's.scholarships.filter(d=>d.status!=="not").length')
      .replace('const T=i.scholarships.filter(j=>j.status==="eligible")', 'const T=i.scholarships.filter(j=>j.status!=="not")')
  }
  return {
    name: 'shared-legacy-scholarships',
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        if (!['/nyansa-legacy-shared.js', '/nyansa-app.js'].includes((req.url || '').split('?')[0])) return next()
        res.setHeader('Content-Type', 'text/javascript; charset=utf-8'); res.end(transform())
      })
    },
    generateBundle() { this.emitFile({ type: 'asset', fileName: 'nyansa-legacy-shared.js', source: transform() }) },
    writeBundle(options) { const old = resolve(options.dir || 'dist', 'nyansa-app.js'); if (existsSync(old)) unlinkSync(old) },
  }
}

// https://vite.dev/config/
export default defineConfig(async ({ mode }) => {
  const plugins = [react(), tailwindcss(), sharedLegacyScholarships()];
  try {
    // @ts-ignore
    const m = await import('./.vite-source-tags.js');
    plugins.push(m.sourceTags());
  } catch {}

  const env = loadEnv(mode, process.cwd(), ['VITE_', 'NEXT_PUBLIC_']);
  const processEnvDefines: Record<string, string> = {};
  for (const [key, value] of Object.entries(env)) {
    processEnvDefines[`process.env.${key}`] = JSON.stringify(value);
  }

  return {
    plugins,
    envPrefix: ['VITE_', 'NEXT_PUBLIC_'],
    define: processEnvDefines,
  };
})
