import { createHash, randomBytes, timingSafeEqual } from 'node:crypto'

const plans = { premium_family_report: 2900, counselor_starter: 40000, counselor_pro: 90000 }
function send(res, status, body) { res.setHeader('Cache-Control', 'no-store'); return res.status(status).json(body) }
function hash(token) { return createHash('sha256').update(token).digest('hex') }
function sameHash(left, right) { try { const a = Buffer.from(left, 'hex'), b = Buffer.from(right, 'hex'); return a.length === 32 && b.length === 32 && timingSafeEqual(a, b) } catch { return false } }
function emailValid(value) { return typeof value === 'string' && value.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) }

export default async function handler(req, res) {
  if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return send(res, 405, { error: 'Method not allowed.' }) }
  const url = (process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL || '').replace(/\/$/, '')
  const anon = process.env.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY
  const service = process.env.SUPABASE_SERVICE_ROLE_KEY, secret = process.env.PAYSTACK_SECRET_KEY
  if (!url || !anon || !service) return send(res, 503, { error: 'Payment storage is not configured. No unlock has been confirmed.' })
  let body = req.body; if (typeof body === 'string') { try { body = JSON.parse(body) } catch { return send(res, 400, { error: 'Invalid request.' }) } }
  const action = body?.action
  if (!['prepare','verify','access','account_access'].includes(action)) return send(res, 400, { error: 'Invalid request.' })
  const token = /^Bearer\s+(\S+)$/i.exec(req.headers.authorization || '')?.[1]
  const serviceHeaders = { apikey: service, Authorization: `Bearer ${service}`, 'Content-Type': 'application/json' }
  try {
    let user = null
    if (token) {
      const response = await fetch(`${url}/auth/v1/user`, { headers: { apikey: anon, Authorization: `Bearer ${token}` } })
      if (!response.ok) return send(res, 401, { error: 'Your session expired. Sign in again or continue as a guest.' })
      user = await response.json()
      if (!user.id || !user.email) return send(res, 401, { error: 'The signed-in account could not be confirmed.' })
    }
    if (action === 'prepare') {
      const plan = body.plan, environment = body.environment
      const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : ''
      if (!Object.hasOwn(plans, plan) || !emailValid(email) || !['test','live'].includes(environment)) return send(res, 400, { error: 'Enter a valid email and choose a plan.' })
      if (!secret || !/^sk_(test|live)_/.test(secret) || (secret.startsWith('sk_test_') ? 'test' : 'live') !== environment) return send(res, 503, { error: 'Secure payment verification is not configured. No payment was started.' })
      const probe = await fetch(`${url}/rest/v1/rpc/complete_nyansa_payment`, { method:'POST', headers:serviceHeaders, body:JSON.stringify({ p_reference:null,p_claim_hash:null,p_paid_at:null }) })
      const rejection = await probe.json().catch(() => ({}))
      if (probe.status !== 400 || rejection.code !== 'P0001' || rejection.message !== 'Invalid payment') return send(res, 503, { error: 'Payment storage is not ready. No payment was started; contact the site owner.' })
      if (user) {
        const functionName = plan === 'premium_family_report' ? 'activate_student_report' : 'activate_counselor_payment'
        const probeBody = { p_reference:null,p_user_id:null,p_amount:0,p_currency:'GHS',p_environment:environment,p_paid_at:null }
        if (plan !== 'premium_family_report') probeBody.p_plan = null
        const check = await fetch(`${url}/rest/v1/rpc/${functionName}`, { method:'POST', headers:serviceHeaders, body:JSON.stringify(probeBody) })
        const err = await check.json().catch(() => ({}))
        if (check.status !== 400 || err.code !== 'P0001' || !['Invalid payment','Invalid payment data'].includes(err.message)) return send(res, 503, { error: 'Account unlock storage is not ready. No payment was started.' })
      }
      const reference = `nyansa_${randomBytes(16).toString('hex')}`, claim = randomBytes(32).toString('hex')
      const insert = await fetch(`${url}/rest/v1/nyansa_payment_intents`, { method:'POST', headers:{ ...serviceHeaders, Prefer:'return=minimal' }, body:JSON.stringify({ reference,claim_hash:hash(claim),owner_id:user?.id || null,email,plan,amount:plans[plan],currency:'GHS',environment,status:'pending' }) })
      if (!insert.ok) return send(res, 503, { error: 'Payment storage is unavailable. No payment was started.' })
      return send(res, 200, { reference, claim, email, plan, amount:plans[plan], environment, owner_id:user?.id || null })
    }
    if (action === 'account_access') {
      const plan = body.plan, environment = body.environment
      if (!user) return send(res, 401, { error: 'Sign in to check your account.' })
      if (!Object.hasOwn(plans, plan) || !['test','live'].includes(environment)) return send(res, 400, { error: 'Invalid plan.' })
      const query = `${url}/rest/v1/nyansa_payment_intents?select=reference,plan,status,email,environment,term_start,term_end&owner_id=eq.${encodeURIComponent(user.id)}&plan=eq.${encodeURIComponent(plan)}&environment=eq.${environment}&status=in.(verified,test_verified)&order=created_at.desc&limit=1`
      const response = await fetch(query, { headers:serviceHeaders }); if (!response.ok) return send(res, 503, { error:'Payment access is temporarily unavailable.' })
      const data = await response.json(); return send(res, 200, { access:!!data?.length, receipt:data?.[0] || null })
    }
    const reference = body.reference, claim = body.claim
    if (typeof reference !== 'string' || !/^[A-Za-z0-9._=-]{1,100}$/.test(reference) || typeof claim !== 'string' || !/^[a-f0-9]{64}$/.test(claim)) return send(res, 400, { error: 'Invalid payment reference or recovery key.' })
    const found = await fetch(`${url}/rest/v1/nyansa_payment_intents?select=reference,claim_hash,owner_id,email,plan,amount,currency,environment,status,term_start,term_end&reference=eq.${encodeURIComponent(reference)}&limit=1`, { headers:serviceHeaders })
    if (!found.ok) return send(res, 503, { error: 'Payment storage is unavailable. Keep your reference and retry.' })
    const rows = await found.json(), item = Array.isArray(rows) ? rows[0] : null
    if (!item || !sameHash(item.claim_hash, hash(claim))) return send(res, 404, { error: 'Payment record not found for this recovery key.' })
    if (item.owner_id && (!user || user.id !== item.owner_id)) return send(res, 401, { error: 'Sign in to the account that started this payment.' })
    if (action === 'access') return send(res, 200, { access:['verified','test_verified'].includes(item.status), receipt:{ reference:item.reference,plan:item.plan,status:item.status,email:item.email,environment:item.environment,term_start:item.term_start,term_end:item.term_end } })
    if (!secret || !/^sk_(test|live)_/.test(secret) || (secret.startsWith('sk_test_') ? 'test' : 'live') !== item.environment) return send(res, 503, { error: 'Payment verification is unavailable. Keep your reference and retry.' })
    const verify = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, { headers:{ Authorization:`Bearer ${secret}`, Accept:'application/json' } })
    if (!verify.ok) return send(res, 502, { error:'Paystack could not verify this reference yet. Keep it and retry.' })
    const result = await verify.json(), payment = result.data
    let metadata = payment?.metadata; if (typeof metadata === 'string') { try { metadata = JSON.parse(metadata) } catch { metadata = null } }
    const normalizedEmail = String(item.email).trim().toLowerCase()
    if (!result.status || !payment || payment.status !== 'success' || payment.reference !== reference || payment.currency !== 'GHS' || payment.amount !== plans[item.plan] || payment.amount !== item.amount || payment.domain !== item.environment || metadata?.product !== 'nyansa_paid_plan' || metadata?.plan !== item.plan || String(metadata?.email || '').trim().toLowerCase() !== normalizedEmail || String(payment.customer?.email || '').trim().toLowerCase() !== normalizedEmail || String(metadata?.user_id || 'guest') !== String(item.owner_id || 'guest')) return send(res, 400, { error:'Payment details could not be confirmed for this plan. No unlock was confirmed.' })
    const paidAt = payment.paid_at || payment.paidAt; if (!paidAt || Number.isNaN(Date.parse(paidAt))) return send(res, 400, { error:'Paystack did not provide a valid payment date.' })
    const saved = await fetch(`${url}/rest/v1/rpc/complete_nyansa_payment`, { method:'POST',headers:serviceHeaders,body:JSON.stringify({ p_reference:reference,p_claim_hash:hash(claim),p_paid_at:paidAt }) })
    if (!saved.ok) return send(res, 503, { error:'Payment was checked but the unlock could not be saved. Keep the reference and retry after setup.' })
    const receipt = await saved.json()
    if (!receipt || receipt.reference !== reference || receipt.plan !== item.plan || !['verified','test_verified'].includes(receipt.status)) return send(res, 503, { error:'The unlock could not be confirmed. Keep the reference and retry.' })
    return send(res, 200, { verified:true, receipt:{ ...receipt, environment:item.environment } })
  } catch { return send(res, 503, { error:'Payment service is unavailable. Keep any reference and retry.' }) }
}
