import { createClient } from '@supabase/supabase-js'
function send(res, status, body) { res.setHeader('Cache-Control','no-store'); return res.status(status).json(body) }
export default async function handler(req,res) {
 if(req.method!=='GET'){res.setHeader('Allow','GET');return send(res,405,{error:'Method not allowed.'})}
 const url=process.env.SUPABASE_URL||process.env.VITE_SUPABASE_URL, anon=process.env.SUPABASE_ANON_KEY||process.env.VITE_SUPABASE_ANON_KEY, service=process.env.SUPABASE_SERVICE_ROLE_KEY
 if(!url||!anon||!service)return send(res,503,{error:'SUPABASE_SERVICE_ROLE_KEY or Supabase server configuration is missing.'})
 const token=/^Bearer\s+(\S+)$/i.exec(req.headers.authorization||'')?.[1]
 if(!token)return send(res,401,{error:'Sign in to view approved institutions.'})
 try{
  const auth=createClient(url,anon,{auth:{persistSession:false,autoRefreshToken:false}})
  const {data:identity,error:authError}=await auth.auth.getUser(token)
  if(authError||!identity.user)return send(res,401,{error:authError?.message||'Your session is invalid or expired.'})
  const db=createClient(url,service,{auth:{persistSession:false,autoRefreshToken:false}})
  const {data,error}=await db.from('institution_partners').select('id,institution_name,institution_type').eq('status','approved').order('institution_name')
  if(error){console.error('Institution directory:',error.message);return send(res,503,{error:error.message})}
  return send(res,200,{partners:data||[]})
 }catch(error){const text=error instanceof Error?error.message:'Unable to load approved institutions.';console.error('Institution directory:',text);return send(res,503,{error:text})}
}
