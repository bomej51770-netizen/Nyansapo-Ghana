function send(res, status, body) { res.setHeader('Cache-Control', 'no-store'); return res.status(status).json(body) }
export default async function handler(req, res) {
  if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return send(res, 405, { error: 'Method not allowed.' }) }
  const url = (process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL || '').replace(/\/$/, '')
  const anon = process.env.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY
  const service = process.env.SUPABASE_SERVICE_ROLE_KEY, secret = process.env.PAYSTACK_SECRET_KEY
  if (!url || !anon || !service || !secret || !/^sk_(test|live)_/.test(secret)) return send(res, 503, { error: 'Server-side verification is not configured.' })
  const token = /^Bearer\s+(\S+)$/i.exec(req.headers.authorization || '')?.[1]
  if (!token) return send(res, 401, { error: 'Sign in to verify this payment.' })
  let body = req.body; if (typeof body === 'string') { try { body = JSON.parse(body) } catch { return send(res, 400, { error: 'Invalid request.' }) } }
  const reference = body?.reference
  if (typeof reference !== 'string' || !/^[A-Za-z0-9._=-]{1,100}$/.test(reference)) return send(res, 400, { error: 'Invalid reference.' })
  try {
    const auth = await fetch(`${url}/auth/v1/user`, { headers: { apikey: anon, Authorization: `Bearer ${token}` } })
    if (!auth.ok) return send(res, 401, { error: 'Your session has expired. Sign in again.' })
    const user = await auth.json(); if (!user.id || !user.email) return send(res, 401, { error: 'An email account is required.' })
    const response = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, { headers: { Authorization: `Bearer ${secret}`, Accept: 'application/json' } })
    if (!response.ok) return send(res, 502, { error: 'Paystack could not verify this reference yet.' })
    const result = await response.json(), payment = result.data
    let metadata = payment?.metadata; if (typeof metadata === 'string') { try { metadata = JSON.parse(metadata) } catch { metadata = null } }
    const environment = secret.startsWith('sk_test_') ? 'test' : 'live', email = String(user.email).trim().toLowerCase()
    if (!result.status || !payment || payment.status !== 'success' || payment.reference !== reference || payment.currency !== 'GHS' || payment.amount !== 2900 || payment.domain !== environment || metadata?.product !== 'student_report' || metadata?.user_id !== user.id || String(metadata?.email || '').trim().toLowerCase() !== email || String(payment.customer?.email || '').trim().toLowerCase() !== email) return send(res, 400, { error: 'Payment details do not match this account and report.' })
    const paidAt = payment.paid_at || payment.paidAt; if (!paidAt || Number.isNaN(Date.parse(paidAt))) return send(res, 400, { error: 'Paystack did not provide a valid payment date.' })
    const saved = await fetch(`${url}/rest/v1/rpc/activate_student_report`, { method: 'POST', headers: { apikey: service, Authorization: `Bearer ${service}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ p_reference: reference, p_user_id: user.id, p_amount: 2900, p_currency: 'GHS', p_environment: environment, p_paid_at: paidAt }) })
    if (!saved.ok) return send(res, 503, { error: 'Payment was checked, but the report could not be unlocked. Keep your reference and retry after setup.' })
    const receipt = await saved.json(); if (!receipt || receipt.reference !== reference || !['unlocked','test_unlocked'].includes(receipt.status)) return send(res, 503, { error: 'The report unlock could not be confirmed. Keep the reference and retry.' })
    return send(res, 200, { verified:true, reference:receipt.reference, status:receipt.status })
  } catch { return send(res, 503, { error:'Verification is temporarily unavailable. Keep the reference and retry.' }) }
}
