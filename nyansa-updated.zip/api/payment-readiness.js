function send(res, status, body) { res.setHeader('Cache-Control', 'no-store'); return res.status(status).json(body) }
export default async function handler(req, res) {
  if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return send(res, 405, { error: 'Method not allowed.' }) }
  const url = (process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL || '').replace(/\/$/, '')
  const anon = process.env.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY
  const service = process.env.SUPABASE_SERVICE_ROLE_KEY, secret = process.env.PAYSTACK_SECRET_KEY
  if (!url || !anon || !service || !secret || !/^sk_(test|live)_/.test(secret)) return send(res, 503, { error: 'Secure checkout verification is not configured yet. No payment was started.' })
  const token = /^Bearer\s+(\S+)$/i.exec(req.headers.authorization || '')?.[1]
  if (!token) return send(res, 401, { error: 'Sign in before starting checkout.' })
  let body = req.body; if (typeof body === 'string') { try { body = JSON.parse(body) } catch { return send(res, 400, { error: 'Invalid checkout request.' }) } }
  const product = body?.product, environment = body?.environment
  if (!['student_report', 'counselor_term'].includes(product) || !['test', 'live'].includes(environment)) return send(res, 400, { error: 'Invalid checkout request.' })
  if ((secret.startsWith('sk_test_') ? 'test' : 'live') !== environment) return send(res, 503, { error: 'The Paystack public and server keys use different environments. No payment was started.' })
  try {
    const auth = await fetch(`${url}/auth/v1/user`, { headers: { apikey: anon, Authorization: `Bearer ${token}` } })
    if (!auth.ok) return send(res, 401, { error: 'Your session has expired. Sign in again.' })
    const user = await auth.json(); if (!user.id || !user.email) return send(res, 401, { error: 'An authenticated email account is required.' })
    const tables = product === 'student_report' ? ['student_report_payments', 'student_report_entitlements'] : ['counselor_payment_transactions', 'counselor_entitlements']
    for (const table of tables) {
      const check = await fetch(`${url}/rest/v1/${table}?select=owner_id&limit=0`, { headers: { apikey: service, Authorization: `Bearer ${service}` } })
      if (!check.ok) return send(res, 503, { error: 'Payment records are not available yet. No payment was started; contact the site owner.' })
    }
    // A deliberately invalid request checks that the service-only activation function
    // exists and rejects invalid input before a customer is sent to Paystack.
    const functionName = product === 'student_report' ? 'activate_student_report' : 'activate_counselor_payment'
    const probeBody = { p_reference: null, p_user_id: null, p_amount: 0, p_currency: 'GHS', p_environment: environment, p_paid_at: null }
    if (product === 'counselor_term') probeBody.p_plan = null
    const probe = await fetch(`${url}/rest/v1/rpc/${functionName}`, { method: 'POST', headers: { apikey: service, Authorization: `Bearer ${service}`, 'Content-Type': 'application/json' }, body: JSON.stringify(probeBody) })
    const rejection = await probe.json().catch(() => ({}))
    const expected = product === 'student_report' ? 'Invalid payment' : 'Invalid payment data'
    if (probe.status !== 400 || rejection.code !== 'P0001' || rejection.message !== expected) return send(res, 503, { error: 'Payment verification is not fully configured. No payment was started; contact the site owner.' })
    return send(res, 200, { ready: true })
  } catch { return send(res, 503, { error: 'Secure checkout is temporarily unavailable. No payment was started.' }) }
}
