import { createHmac, randomBytes, timingSafeEqual } from 'node:crypto'

const plans = { premium_family_report: 2900, counselor_starter: 40000, counselor_pro: 90000 }
const day = 24 * 60 * 60 * 1000
function send(res, status, body) { res.setHeader('Cache-Control', 'no-store'); return res.status(status).json(body) }
function emailValid(value) { return typeof value === 'string' && value.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) }
function sign(payload, key) { const data = Buffer.from(JSON.stringify(payload)).toString('base64url'); const mac = createHmac('sha256', key).update(`nyansa-payment-v1.${data}`).digest('base64url'); return `${data}.${mac}` }
function readClaim(claim, key) {
  if (typeof claim !== 'string' || claim.length > 2048) return null
  const parts = claim.split('.'); if (parts.length !== 2 || !/^[A-Za-z0-9_-]+$/.test(parts[0]) || !/^[A-Za-z0-9_-]+$/.test(parts[1])) return null
  const expected = createHmac('sha256', key).update(`nyansa-payment-v1.${parts[0]}`).digest(), supplied = Buffer.from(parts[1], 'base64url')
  if (supplied.length !== expected.length || !timingSafeEqual(expected, supplied)) return null
  try { const data = JSON.parse(Buffer.from(parts[0], 'base64url').toString('utf8')); return data && typeof data === 'object' ? data : null } catch { return null }
}
function validClaim(item, reference) { return item && item.reference === reference && /^nyansa_(test|live)_[a-f0-9]{32}$/.test(reference) && Object.hasOwn(plans, item.plan) && emailValid(item.email) && ['test','live'].includes(item.environment) && reference.startsWith(`nyansa_${item.environment}_`) && (item.owner_id === null || (typeof item.owner_id === 'string' && /^[0-9a-f-]{36}$/i.test(item.owner_id))) }
function rowMatches(row, item) { return row && row.reference === item.reference && (row.user_id ?? null) === item.owner_id && String(row.email || '').trim().toLowerCase() === item.email && row.plan === item.plan && row.amount === plans[item.plan] && row.currency === 'GHS' && row.status === 'success' && !Number.isNaN(Date.parse(row.created_at)) }
function verificationError(message, code) { const error = new Error(message); error.paymentCode = code; return error }
async function verifyPaystack(reference, item, secret) {
  const response = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, { headers: { Authorization: `Bearer ${secret}`, Accept: 'application/json' } })
  if (!response.ok) throw verificationError('Paystack could not verify this reference yet. Keep it and retry.', 'unavailable')
  const result = await response.json(), payment = result.data
  let metadata = payment?.metadata; if (typeof metadata === 'string') { try { metadata = JSON.parse(metadata) } catch { metadata = null } }
  if (!result.status || !payment || payment.status !== 'success' || payment.reference !== reference || payment.currency !== 'GHS' || payment.amount !== plans[item.plan] || payment.domain !== item.environment || metadata?.product !== 'nyansa_paid_plan' || metadata?.plan !== item.plan || String(metadata?.email || '').trim().toLowerCase() !== item.email || String(payment.customer?.email || '').trim().toLowerCase() !== item.email || String(metadata?.user_id || 'guest') !== String(item.owner_id || 'guest')) throw verificationError('Payment details do not match this plan. No unlock has been confirmed.', 'mismatch')
  if (Number.isNaN(Date.parse(payment.paid_at || payment.paidAt || ''))) throw verificationError('Paystack did not provide a valid payment date.', 'mismatch')
  return payment
}
function receipt(row, environment, term, active = true) { return { reference:row.reference,plan:row.plan,status:environment==='test'?'test_verified':'verified',email:row.email,environment,term_start:term?.start || null,term_end:term?.end || null,active } }
function simpleTerm(payment) { const start=Date.parse(payment.paid_at || payment.paidAt); return { start:new Date(start).toISOString(), end:new Date(start+90*day).toISOString() } }
async function accountTerms(url, headers, userId, environment, secret, knownPayment) {
  const query=`${url}/rest/v1/payments?select=user_id,email,plan,amount,currency,reference,status,created_at&user_id=eq.${encodeURIComponent(userId)}&plan=in.(counselor_starter,counselor_pro)&status=eq.success&order=created_at.asc&limit=101`
  const response=await fetch(query,{headers}); if(!response.ok)throw new Error('Counselor payment history is temporarily unavailable.')
  const rows=await response.json(); if(!Array.isArray(rows))throw new Error('Payment history could not be confirmed.')
  if(rows.length>100)throw new Error('Payment history needs manual review before access can be confirmed.')
  const verified=[]
  for(const row of rows){
    if(typeof row.reference!=='string'||!new RegExp(`^nyansa_${environment}_[a-f0-9]{32}$`).test(row.reference))continue
    const item={reference:row.reference,email:String(row.email||'').trim().toLowerCase(),plan:row.plan,environment,owner_id:userId}
    if(!rowMatches(row,item))continue
    try{const payment=knownPayment?.reference===row.reference?knownPayment:await verifyPaystack(row.reference,item,secret);verified.push({row,paid:Date.parse(payment.paid_at||payment.paidAt)})}catch(error){if(error?.paymentCode!=='mismatch')throw error}
  }
  verified.sort((a,b)=>a.paid-b.paid||a.row.reference.localeCompare(b.row.reference))
  let current=null
  for(const {row,paid} of verified){const start=current && current.plan===row.plan && Date.parse(current.end)>paid?Date.parse(current.end):paid;current={row,plan:row.plan,start:new Date(start).toISOString(),end:new Date(start+90*day).toISOString()}}
  return current
}

export default async function handler(req, res) {
  if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return send(res, 405, { error: 'Method not allowed.' }) }
  const url=(process.env.SUPABASE_URL||process.env.VITE_SUPABASE_URL||'').replace(/\/$/,'')
  const anon=process.env.SUPABASE_ANON_KEY||process.env.VITE_SUPABASE_ANON_KEY, service=process.env.SUPABASE_SERVICE_ROLE_KEY, secret=process.env.PAYSTACK_SECRET_KEY, claimKey=process.env.PAYMENT_CLAIM_SECRET||secret
  if (!url || !anon || !service || !secret || !/^sk_(test|live)_/.test(secret) || !claimKey) return send(res,503,{error:'Secure payment verification is unavailable. No unlock has been confirmed.'})
  let body=req.body; if(typeof body==='string'){try{body=JSON.parse(body)}catch{return send(res,400,{error:'Invalid request.'})}}
  if (!['prepare','verify','access','account_access'].includes(body?.action)) return send(res,400,{error:'Invalid request.'})
  const token=/^Bearer\s+(\S+)$/i.exec(req.headers.authorization||'')?.[1], headers={apikey:service,Authorization:`Bearer ${service}`,'Content-Type':'application/json'}
  try {
    let user=null
    if(token){const response=await fetch(`${url}/auth/v1/user`,{headers:{apikey:anon,Authorization:`Bearer ${token}`}});if(!response.ok)return send(res,401,{error:'Your session expired. Sign in again or continue as a guest.'});user=await response.json();if(!user.id||!user.email)return send(res,401,{error:'The signed-in account could not be confirmed.'})}
    if(body.action==='prepare'){
      const plan=body.plan, environment=body.environment, email=typeof body.email==='string'?body.email.trim().toLowerCase():''
      if(!Object.hasOwn(plans,plan)||!emailValid(email)||!['test','live'].includes(environment))return send(res,400,{error:'Enter a valid email and choose a plan.'})
      if((secret.startsWith('sk_test_')?'test':'live')!==environment)return send(res,503,{error:'Paystack keys use different environments. No payment was started.'})
      const check=await fetch(`${url}/rest/v1/payments?select=id,user_id,email,plan,amount,currency,reference,status,created_at&limit=0`,{headers})
      if(!check.ok)return send(res,503,{error:'Payment storage is temporarily unavailable. No payment was started.'})
      const reference=`nyansa_${environment}_${randomBytes(16).toString('hex')}`
      const item={reference,email,plan,environment,owner_id:user?.id||null}
      return send(res,200,{...item,claim:sign(item,claimKey),amount:plans[plan]})
    }
    if(body.action==='account_access'){
      const plan=body.plan, environment=body.environment
      if(!user)return send(res,401,{error:'Sign in to check your account.'})
      if(!Object.hasOwn(plans,plan)||!['test','live'].includes(environment))return send(res,400,{error:'Invalid plan.'})
      if((secret.startsWith('sk_test_')?'test':'live')!==environment)return send(res,503,{error:'Payment verification is temporarily unavailable.'})
      if(plan!=='premium_family_report'){
        const current=await accountTerms(url,headers,user.id,environment,secret)
        const active=!!current && current.plan===plan && Date.parse(current.end)>Date.now()
        return send(res,200,{access:active,receipt:active?receipt(current.row,environment,current):null})
      }
      const query=`${url}/rest/v1/payments?select=user_id,email,plan,amount,currency,reference,status,created_at&user_id=eq.${encodeURIComponent(user.id)}&plan=eq.${encodeURIComponent(plan)}&status=eq.success&order=created_at.desc&limit=100`
      const response=await fetch(query,{headers});if(!response.ok)return send(res,503,{error:'Payment access is temporarily unavailable.'})
      const rows=await response.json();if(!Array.isArray(rows))throw new Error('Invalid storage response')
      for(const row of rows){
        if(row.plan!==plan || typeof row.reference!=='string' || !new RegExp(`^nyansa_${environment}_[a-f0-9]{32}$`).test(row.reference))continue
        const item={reference:row.reference,email:String(row.email||'').trim().toLowerCase(),plan:row.plan,environment,owner_id:user.id}
        if(!rowMatches(row,item))continue
        try{await verifyPaystack(row.reference,item,secret);return send(res,200,{access:true,receipt:receipt(row,environment,null)})}catch(error){if(error?.paymentCode!=='mismatch')throw error}
      }
      return send(res,200,{access:false,receipt:null})
    }
    const reference=body.reference, item=readClaim(body.claim,claimKey)
    if(typeof reference!=='string'||!validClaim(item,reference))return send(res,400,{error:'Invalid payment reference or recovery key.'})
    if(item.owner_id && (!user||user.id!==item.owner_id))return send(res,401,{error:'Sign in to the account that started this payment.'})
    if((secret.startsWith('sk_test_')?'test':'live')!==item.environment)return send(res,503,{error:'Payment verification is temporarily unavailable. Keep your reference and retry.'})
    const query=`${url}/rest/v1/payments?select=user_id,email,plan,amount,currency,reference,status,created_at&reference=eq.${encodeURIComponent(reference)}&limit=1`
    let payment=null
    if(body.action==='verify'){
      payment=await verifyPaystack(reference,item,secret)
      const record={user_id:item.owner_id,email:item.email,plan:item.plan,amount:plans[item.plan],currency:'GHS',reference,status:'success',created_at:new Date().toISOString()}
      const saved=await fetch(`${url}/rest/v1/payments?on_conflict=reference`,{method:'POST',headers:{...headers,Prefer:'resolution=ignore-duplicates,return=minimal'},body:JSON.stringify(record)})
      if(!saved.ok)return send(res,503,{error:'Payment was verified but could not be saved. Keep your reference and retry after storage is configured.'})
    }
    const response=await fetch(query,{headers});if(!response.ok)return send(res,503,{error:'Payment storage is unavailable. Keep your reference and retry.'})
    const rows=await response.json(), row=Array.isArray(rows)?rows[0]:null
    if(!rowMatches(row,item))return body.action==='access'?send(res,200,{access:false,receipt:null}):send(res,503,{error:'The saved payment could not be confirmed. Keep your reference and retry.'})
    if(body.action==='access')payment=await verifyPaystack(reference,item,secret)
    let term=item.plan==='premium_family_report'?null:simpleTerm(payment), active=true
    if(term && item.owner_id){const current=await accountTerms(url,headers,item.owner_id,item.environment,secret,payment);active=!!current && current.plan===item.plan && Date.parse(current.end)>Date.now();if(active)term=current}
    else if(term)active=Date.parse(term.end)>Date.now()
    const result=receipt(row,item.environment,term,active)
    if(body.action==='access' && !active)return send(res,200,{access:false,receipt:result})
    return body.action==='verify'?send(res,200,{verified:true,receipt:result}):send(res,200,{access:true,receipt:result})
  } catch(error) { return send(res,error?.paymentCode==='mismatch'?400:503,{error:error instanceof Error?error.message:'Payment service is unavailable. Keep any reference and retry.'}) }
}
