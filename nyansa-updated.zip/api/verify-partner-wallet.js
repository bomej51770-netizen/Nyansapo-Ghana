import { createClient } from '@supabase/supabase-js'
const bundles = { 50: 50000, 100: 100000, 150: 150000 }
function send(res, status, body) { res.setHeader('Cache-Control', 'no-store'); return res.status(status).json(body) }
function dbError(res, error) { const text=error?.message || 'Supabase request failed.'; console.error('Partner wallet:',text); return send(res,503,{error:text}) }
export default async function handler(req, res) {
  if(req.method!=='POST'){res.setHeader('Allow','POST');return send(res,405,{error:'Method not allowed.'})}
  const url=process.env.SUPABASE_URL||process.env.VITE_SUPABASE_URL, anon=process.env.SUPABASE_ANON_KEY||process.env.VITE_SUPABASE_ANON_KEY, service=process.env.SUPABASE_SERVICE_ROLE_KEY, secret=process.env.PAYSTACK_SECRET_KEY
  if(!url||!anon||!service||!secret||!/^sk_(test|live)_/.test(secret))return send(res,503,{error:'Supabase server credentials or Paystack secret are not configured.'})
  const token=/^Bearer\s+(\S+)$/i.exec(req.headers.authorization||'')?.[1];if(!token)return send(res,401,{error:'Sign in to verify this payment.'})
  let body=req.body;if(typeof body==='string'){try{body=JSON.parse(body)}catch{return send(res,400,{error:'Invalid request.'})}}
  const {reference,partner_id:partnerId,credits}=body||{},action=body?.action||'verify'
  if(!['preflight','verify'].includes(action)||typeof reference!=='string'||!/^[A-Za-z0-9._=-]{1,100}$/.test(reference)||typeof partnerId!=='string'||!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(partnerId)||![50,100,150].includes(credits))return send(res,400,{error:'Invalid payment reference, partner or bundle.'})
  try{
    const auth=createClient(url,anon,{auth:{persistSession:false,autoRefreshToken:false}})
    const {data:identity,error:authError}=await auth.auth.getUser(token)
    const user=identity.user;if(authError||!user?.id||!user.email)return send(res,401,{error:authError?.message||'Your session is invalid or expired.'})
    const db=createClient(url,service,{auth:{persistSession:false,autoRefreshToken:false}})
    const {data:profile,error:profileError}=await db.from('institution_partners').select('*').eq('id',partnerId).eq('user_id',user.id).maybeSingle()
    if(profileError)return dbError(res,profileError)
    if(!profile||profile.status!=='approved')return send(res,403,{error:'Only the approved partner account can verify this top-up.'})
    const environment=secret.startsWith('sk_test_')?'test':'live',email=String(user.email).trim().toLowerCase()
    if(environment==='test'&&process.env.ALLOW_PARTNER_TEST_CREDITS!=='true')return send(res,503,{error:'Test crediting is disabled. Configure an isolated test project before retrying.'})
    const {data:ready,error:readyError}=await db.from('institution_partner_wallet_readiness').select('wallet_ready').maybeSingle()
    if(readyError)return dbError(res,readyError)
    if(!ready?.wallet_ready)return send(res,503,{error:'Wallet credit trigger is not enabled. No payment was started.'})
    if(action==='preflight')return send(res,200,{ready:true,environment})
    const payResponse=await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`,{headers:{Authorization:`Bearer ${secret}`,Accept:'application/json'}})
    if(!payResponse.ok)return send(res,502,{error:'Paystack could not verify this reference yet. Please retry.'})
    const result=await payResponse.json(),payment=result.data;let metadata=payment?.metadata
    if(typeof metadata==='string'){try{metadata=JSON.parse(metadata)}catch{metadata=null}}
    if(!result.status||!payment||payment.status!=='success'||payment.reference!==reference||payment.currency!=='GHS'||payment.amount!==bundles[credits]||payment.domain!==environment||metadata?.product!=='partner_wallet'||String(metadata?.credits)!==String(credits)||metadata?.partner_id!==partnerId||metadata?.user_id!==user.id||String(metadata?.email||'').trim().toLowerCase()!==email||String(payment.customer?.email||'').trim().toLowerCase()!==email)return send(res,400,{error:'Payment details do not match this account and bundle. Credit has not been confirmed.'})
    const paidAt=payment.paid_at||payment.paidAt;if(!paidAt||Number.isNaN(Date.parse(paidAt)))return send(res,400,{error:'Paystack did not provide a valid payment date.'})
    const {error:insertError}=await db.from('institution_partner_wallet_events').insert({reference,partner_id:partnerId,user_id:user.id,email,credits,amount:bundles[credits],currency:'GHS',environment,paid_at:paidAt})
    if(insertError&&insertError.code!=='23505')return dbError(res,insertError)
    const {data:event,error:eventError}=await db.from('institution_partner_wallet_events').select('*').eq('reference',reference).maybeSingle()
    if(eventError)return dbError(res,eventError)
    if(!event||event.partner_id!==partnerId||event.user_id!==user.id||event.email!==email||event.credits!==credits||event.amount!==bundles[credits]||event.currency!=='GHS'||event.environment!==environment)return send(res,409,{error:'Payment reference conflicts with another wallet event.'})
    if(event.credited!==true)return send(res,503,{error:'Wallet credit trigger did not confirm this payment. Keep the reference and contact support.'})
    const {data:current,error:balanceError}=await db.from('institution_partners').select('lead_credits').eq('id',partnerId).eq('user_id',user.id).maybeSingle()
    if(balanceError)return dbError(res,balanceError)
    if(!current||!Number.isInteger(current.lead_credits))return send(res,503,{error:'The wallet balance could not be confirmed. Keep the reference and retry.'})
    return send(res,200,{verified:true,reference,credits,environment,balance:current.lead_credits})
  }catch(error){const text=error instanceof Error?error.message:'Verification is temporarily unavailable.';console.error('Partner wallet:',text);return send(res,503,{error:text})}
}
