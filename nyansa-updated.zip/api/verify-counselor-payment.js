const amounts = { starter: 40000, pro: 90000 }

function send(res, status, body) {
  res.setHeader('Cache-Control', 'no-store')
  return res.status(status).json(body)
}

export default async function handler(req, res) {
  if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return send(res, 405, { error: 'Method not allowed.' }) }
  const supabaseUrl = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL
  const anonKey = process.env.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY
  const paystackSecret = process.env.PAYSTACK_SECRET_KEY
  if (!supabaseUrl || !anonKey || !serviceKey || !paystackSecret || !/^sk_(test|live)_/.test(paystackSecret)) return send(res, 503, { error: 'Server-side payment verification is not configured.' })
  const token = /^Bearer\s+(\S+)$/i.exec(req.headers.authorization || '')?.[1]
  if (!token) return send(res, 401, { error: 'Sign in to verify this payment.' })
  let body = req.body
  if (typeof body === 'string') { try { body = JSON.parse(body) } catch { return send(res, 400, { error: 'Invalid request.' }) } }
  const reference = body?.reference, plan = body?.plan
  if (typeof reference !== 'string' || !/^[A-Za-z0-9._=-]{1,100}$/.test(reference) || (plan !== 'starter' && plan !== 'pro')) return send(res, 400, { error: 'Invalid payment reference or plan.' })
  try {
    const authResponse = await fetch(`${supabaseUrl.replace(/\/$/, '')}/auth/v1/user`, { headers: { apikey: anonKey, Authorization: `Bearer ${token}` } })
    if (!authResponse.ok) return send(res, 401, { error: 'Your session is invalid or expired. Sign in again.' })
    const user = await authResponse.json()
    if (!user.id || !user.email) return send(res, 401, { error: 'An authenticated email account is required.' })
    const payResponse = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, { headers: { Authorization: `Bearer ${paystackSecret}`, Accept: 'application/json' } })
    if (!payResponse.ok) return send(res, 502, { error: 'Paystack could not verify this reference yet. Please retry.' })
    const result = await payResponse.json()
    const payment = result.data
    let metadata = payment?.metadata
    if (typeof metadata === 'string') { try { metadata = JSON.parse(metadata) } catch { metadata = null } }
    const environment = paystackSecret.startsWith('sk_test_') ? 'test' : 'live'
    const email = String(user.email).trim().toLowerCase()
    if (!result.status || !payment || payment.status !== 'success' || payment.reference !== reference || payment.currency !== 'GHS' || payment.amount !== amounts[plan] || payment.domain !== environment || metadata?.product !== 'counselor_term' || metadata?.plan !== plan || metadata?.user_id !== user.id || String(metadata?.email || '').trim().toLowerCase() !== email || String(payment.customer?.email || '').trim().toLowerCase() !== email) return send(res, 400, { error: 'Payment details did not match this account and plan. No activation was confirmed.' })
    const paidAt = payment.paid_at || payment.paidAt
    if (!paidAt || Number.isNaN(Date.parse(paidAt))) return send(res, 400, { error: 'Paystack did not provide a valid payment date.' })
    const dbResponse = await fetch(`${supabaseUrl.replace(/\/$/, '')}/rest/v1/rpc/activate_counselor_payment`, { method: 'POST', headers: { apikey: serviceKey, Authorization: `Bearer ${serviceKey}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ p_reference: reference, p_user_id: user.id, p_plan: plan, p_amount: amounts[plan], p_currency: 'GHS', p_environment: environment, p_paid_at: paidAt }) })
    if (!dbResponse.ok) return send(res, 503, { error: 'Payment was checked, but the term could not be saved. Keep the reference and retry after database setup.' })
    const receipt = await dbResponse.json()
    if (!receipt || receipt.reference !== reference || receipt.plan !== plan || !['active', 'test_active'].includes(receipt.term_status)) return send(res, 503, { error: 'The saved term could not be confirmed. Keep the reference and retry.' })
    return send(res, 200, { verified: true, reference: receipt.reference, plan: receipt.plan, term_status: receipt.term_status, term_start: receipt.term_start, term_end: receipt.term_end })
  } catch { return send(res, 503, { error: 'Verification is temporarily unavailable. Keep the reference and retry.' }) }
}
