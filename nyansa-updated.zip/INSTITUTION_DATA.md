# Ghana institution data and verification

The dashboard dataset contains 66 institution entries across all 16 regions: 15 public universities, 10 technical universities, 15 colleges of education, 14 nursing/midwifery institutions, 11 private universities and one specialized university (Regional Maritime University). The directory and matcher derive from the same `institutions` array in `src/dashboard/data.ts`. Four additional nursing/midwifery entries cover Ahafo, Bono East, North East and Savannah.

## Sources and limits

- Ghana Tertiary Education Commission: [Explore Institutions](https://gtec.edu.gh/explore-institutions/) and [Accredited Institutions](https://gtec.edu.gh/accredited-institutions/). GTEC advises checking current institutional, campus and programme accreditation. Its live list was not available as a complete machine-readable list during this update, so **current accreditation of every listed institution and programme has not been independently confirmed**.
- [Nursing and Midwifery Council accredited institutions list](https://www.nmc.gov.gh/web/find-accredited-institutions): used as a reference for nursing/midwifery entries, including Techiman Krobo, Goaso, Nalerigu and Damongo. Confirm current names, programme approval and intake directly with NMC and the institution; the Komfo Anokye/Kumasi naming should be independently confirmed.
- [Colleges of Education 2023 admissions guide](https://admission.coeportal.edu.gh/ADMISSION_PROCEDURE_2023.pdf) and the [public college list](https://en.wikipedia.org/wiki/List_of_colleges_of_education_in_Ghana) are historical references for college names; they do not establish current accreditation or programme availability.
- [Dr. Hilla Limann Technical University](https://www.dhltu.edu.gh/) identifies its location as Wa, Upper West. It is separate from Tamale Technical University.
- [EducationGhana accreditation overview](https://educateghana.com/accredited-tertiary-institutions-in-ghana-updated-directory/) notes that accreditation and individual programme approvals can change.

## Cut-offs and matching

The 06–24, 12–36, 06–30 and similar ranges in the app are **illustrative category-wide exploration bands**, not institution-specific or official cut-offs. A small number of older example screening values retained from the previous app are also unverified and explicitly labelled as examples. Broad study-area labels, elective examples, streams and deadlines are prompts to investigate, not claims that every institution currently offers them. No exact application dates are invented.

“Safe Match” and other labels are simple planning heuristics, not admission predictions. Programmes lacking a specific example figure remain tentative rather than being classified safe. Students must confirm current cut-offs, electives, stream/sitting rules, fees, accreditation and deadlines with the institution and appropriate regulator.
