# Counselor cohort workspace

The matcher uses the existing Supabase client and email authentication. Run `supabase/counselor_workspaces.sql` in the project SQL editor to create the workspace table and owner-only RLS policy. Each authenticated counselor saves their cohort array, students, notes and choices under their user ID. Select **Save workspace** after making changes. CSV exports contain the whole current cohort.

If no user is signed in, sample data is temporary and saving is unavailable. If the table or connection is unavailable for a signed-in user, saving falls back to browser storage keyed by that user's ID; it is not encrypted, synced, or private from device users. An explicit notice appears. Avoid real student data on shared devices. Create the table and save again to use cloud storage.

Starter enforces a 150-student limit per cohort; Pro supports larger cohorts. The plan selector is a planning aid, not a payment or licence entitlement check. Admission flags are simple planning heuristics, not verified institutional cut-offs. Always confirm individual entry requirements, elective subjects, streams, fees and accreditation.
