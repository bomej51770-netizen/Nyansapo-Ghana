# Routing diagnosis

The supplied home page and the application's registered routes (`/`, `/match`, `/results`, `/universities`, `/scholarships`, `/essay`, `/counselors`, and `/pricing`) returned HTTP 200 when checked. The profile-building route is `/match`, not `/profile` or `/login`. No failing internal URL was supplied, so the specific request behind the reported `404 NOT_FOUND` could not be established from that message alone.

The app uses client-side routing, and this deployment previously had no Vercel rewrite. `vercel.json` now serves the app entry point for direct visits to client-side routes such as `/match`; existing static assets remain served normally.

Two separate, reproducible 404s were found in the Scholarship Finder's external links:

- **Ashesi Financial Aid:** `https://www.ashesi.edu.gh/admissions/financial-aid` returned 404. It now points to Ashesi's current `https://ashesi.edu.gh/how-to-apply/` admissions page, which includes financial-aid application information.
- **Berea Tuition Promise + International Aid:** `https://www.berea.edu/admissions/international` returned 404. It now points to `https://www.berea.edu/admissions/admission-information/apply/checklist-items/international-faqs`, Berea's current international applicant information page.

These external 404s do not establish which request produced the reported `404 NOT_FOUND` message. The exact failed URL or a browser network log is needed to attribute that specific message.
