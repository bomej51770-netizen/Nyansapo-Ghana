-- Run in Supabase SQL Editor after student_report_payments.sql and counselor_payments.sql.
-- Intents, capability hashes and verification records are never exposed directly to clients.
create table if not exists public.nyansa_payment_intents (
  reference text primary key,
  claim_hash text not null,
  owner_id uuid references auth.users(id) on delete set null,
  email text not null,
  plan text not null check (plan in ('premium_family_report','counselor_starter','counselor_pro')),
  amount integer not null,
  currency text not null check (currency='GHS'),
  environment text not null check (environment in ('test','live')),
  status text not null default 'pending' check (status in ('pending','verified','test_verified')),
  paid_at timestamptz,
  term_start timestamptz,
  term_end timestamptz,
  created_at timestamptz not null default now()
);
alter table public.nyansa_payment_intents enable row level security;
revoke all on public.nyansa_payment_intents from public, anon, authenticated;
grant select, insert, update on public.nyansa_payment_intents to service_role;

create or replace function public.complete_nyansa_payment(p_reference text,p_claim_hash text,p_paid_at timestamptz)
returns jsonb language plpgsql security definer set search_path=pg_catalog,public as $$
declare item public.nyansa_payment_intents%rowtype; receipt jsonb; result_status text; starts timestamptz; ends timestamptz;
begin
  if p_reference is null or p_claim_hash is null or p_paid_at is null then raise exception 'Invalid payment'; end if;
  select * into item from public.nyansa_payment_intents where reference=p_reference for update;
  if not found or item.claim_hash <> p_claim_hash then raise exception 'Invalid payment'; end if;
  if item.status in ('verified','test_verified') then
    return jsonb_build_object('reference',item.reference,'plan',item.plan,'status',item.status,'email',item.email,'term_start',item.term_start,'term_end',item.term_end);
  end if;
  if item.owner_id is not null then
    if item.plan='premium_family_report' then
      receipt := public.activate_student_report(item.reference,item.owner_id,item.amount,item.currency,item.environment,p_paid_at);
    else
      receipt := public.activate_counselor_payment(item.reference,item.owner_id,case when item.plan='counselor_starter' then 'starter' else 'pro' end,item.amount,item.currency,item.environment,p_paid_at);
      starts := (receipt->>'term_start')::timestamptz; ends := (receipt->>'term_end')::timestamptz;
    end if;
  elsif item.plan in ('counselor_starter','counselor_pro') then
    starts := now(); ends := starts + interval '90 days';
  end if;
  result_status := case when item.environment='test' then 'test_verified' else 'verified' end;
  update public.nyansa_payment_intents set status=result_status,paid_at=p_paid_at,term_start=starts,term_end=ends where reference=p_reference;
  return jsonb_build_object('reference',item.reference,'plan',item.plan,'status',result_status,'email',item.email,'term_start',starts,'term_end',ends);
end;
$$;
revoke all on function public.complete_nyansa_payment(text,text,timestamptz) from public, anon, authenticated;
grant execute on function public.complete_nyansa_payment(text,text,timestamptz) to service_role;
