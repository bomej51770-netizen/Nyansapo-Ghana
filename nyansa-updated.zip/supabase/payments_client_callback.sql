-- WARNING: This intentionally trusts a browser callback. Anyone can fabricate a
-- 'success' payment and local unlock; these rows MUST NOT be used as proof of payment.
-- Use only if you accept that risk. Server-side Paystack verification is safer.
-- Check for duplicate references before creating the unique index.
alter table public.payments alter column user_id drop not null;
create unique index if not exists payments_reference_unique on public.payments(reference);
alter table public.payments enable row level security;
grant insert (user_id, email, plan, amount, currency, reference, status) on public.payments to anon, authenticated;
grant select (reference) on public.payments to anon, authenticated;
drop policy if exists "Client reported payment callbacks" on public.payments;
create policy "Client reported payment callbacks" on public.payments for insert to anon, authenticated
with check (
  (user_id is null or user_id = (select auth.uid())) and
  currency = 'GHS' and status = 'success' and
  ((plan = 'premium_family_report' and amount = 2900) or
   (plan = 'counselor_starter' and amount = 40000) or
   (plan = 'counselor_pro' and amount = 90000))
);
