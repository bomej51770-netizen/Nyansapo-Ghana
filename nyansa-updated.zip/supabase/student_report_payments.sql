-- Run in the Supabase SQL editor; only the server service role can activate an unlock.
create table if not exists public.student_report_payments (
  reference text primary key, owner_id uuid not null references auth.users(id) on delete cascade,
  amount integer not null check (amount = 2900), currency text not null check (currency = 'GHS'),
  environment text not null check (environment in ('live','test')), paid_at timestamptz not null,
  created_at timestamptz not null default now()
);
create table if not exists public.student_report_entitlements (
  owner_id uuid not null references auth.users(id) on delete cascade,
  environment text not null check (environment in ('live','test')),
  status text not null check (status in ('unlocked','test_unlocked')),
  transaction_reference text not null references public.student_report_payments(reference),
  created_at timestamptz not null default now(), primary key(owner_id, environment)
);
alter table public.student_report_payments enable row level security;
alter table public.student_report_entitlements enable row level security;
revoke all on public.student_report_payments, public.student_report_entitlements from anon, authenticated;
grant select on public.student_report_payments, public.student_report_entitlements to authenticated;
drop policy if exists "Read own student report payments" on public.student_report_payments;
create policy "Read own student report payments" on public.student_report_payments for select to authenticated using ((select auth.uid())=owner_id);
drop policy if exists "Read own student report entitlement" on public.student_report_entitlements;
create policy "Read own student report entitlement" on public.student_report_entitlements for select to authenticated using ((select auth.uid())=owner_id);
create or replace function public.activate_student_report(p_reference text,p_user_id uuid,p_amount integer,p_currency text,p_environment text,p_paid_at timestamptz)
returns jsonb language plpgsql security definer set search_path=pg_catalog,public as $$
declare prior public.student_report_payments%rowtype; unlock_status text;
begin
  if p_user_id is null or p_reference is null or p_reference !~ '^[A-Za-z0-9._=-]{1,100}$' or p_amount is distinct from 2900 or p_currency is distinct from 'GHS' or p_environment not in ('live','test') or p_paid_at is null then raise exception 'Invalid payment'; end if;
  perform pg_advisory_xact_lock(hashtextextended('student-report-owner:'||p_user_id::text,0));
  perform pg_advisory_xact_lock(hashtextextended('student-report-ref:'||p_reference,0));
  select * into prior from public.student_report_payments where reference=p_reference;
  if found then
    if prior.owner_id <> p_user_id or prior.amount <> p_amount or prior.currency <> p_currency or prior.environment <> p_environment then raise exception 'Reference conflict'; end if;
  else
    insert into public.student_report_payments(reference,owner_id,amount,currency,environment,paid_at) values(p_reference,p_user_id,p_amount,p_currency,p_environment,p_paid_at);
  end if;
  unlock_status := case when p_environment='test' then 'test_unlocked' else 'unlocked' end;
  insert into public.student_report_entitlements(owner_id,environment,status,transaction_reference) values(p_user_id,p_environment,unlock_status,p_reference)
    on conflict(owner_id,environment) do update set status=excluded.status,transaction_reference=excluded.transaction_reference;
  return jsonb_build_object('reference',p_reference,'status',unlock_status);
end;
$$;
revoke all on function public.activate_student_report(text,uuid,integer,text,text,timestamptz) from public, anon, authenticated;
grant execute on function public.activate_student_report(text,uuid,integer,text,text,timestamptz) to service_role;
