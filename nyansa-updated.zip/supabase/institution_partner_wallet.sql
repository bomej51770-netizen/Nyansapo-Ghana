-- Apply to existing institution_partners, partner_leads and payments tables.
-- TESTING ONLY: client applications may be auto-approved. Replace with independent
-- institutional review before production. Check for duplicate references and opt-ins.
create unique index if not exists payments_reference_unique on public.payments(reference);
create unique index if not exists partner_leads_partner_student_unique on public.partner_leads(partner_id,student_user_id);
alter table public.institution_partners enable row level security;
alter table public.partner_leads enable row level security;
revoke insert, update, delete on public.institution_partners from public, anon, authenticated;
revoke insert, update, delete on public.partner_leads from public, anon, authenticated;
grant select on public.institution_partners, public.partner_leads to authenticated;
grant insert (user_id,institution_name,institution_type,contact_name,official_email,phone,billing_method,status,lead_credits) on public.institution_partners to authenticated;
grant insert (partner_id,student_user_id,student_name,student_email,programme_interest) on public.partner_leads to authenticated;
grant select on public.institution_partners to service_role;
grant select, insert on public.payments to service_role;
do $$ begin
  if not exists (select 1 from pg_constraint where conname='institution_partners_nonnegative_credits' and conrelid='public.institution_partners'::regclass) then
    alter table public.institution_partners add constraint institution_partners_nonnegative_credits check (lead_credits >= 0) not valid;
  end if;
end $$;
drop policy if exists "Read own institution" on public.institution_partners;
create policy "Read own institution" on public.institution_partners for select to authenticated using (user_id = (select auth.uid()));
drop policy if exists "Restrict institution reads to owner" on public.institution_partners;
create policy "Restrict institution reads to owner" on public.institution_partners as restrictive for select to authenticated using (user_id = (select auth.uid()));
drop policy if exists "Insert own testing institution" on public.institution_partners;
create policy "Insert own testing institution" on public.institution_partners for insert to authenticated with check (user_id = (select auth.uid()) and status = 'approved' and lead_credits = 0);
drop policy if exists "Read own institution leads" on public.partner_leads;
create policy "Read own institution leads" on public.partner_leads for select to authenticated using (student_user_id = (select auth.uid()) or exists (select 1 from public.institution_partners p where p.id=partner_id and p.user_id=(select auth.uid()) and p.status='approved'));
drop policy if exists "Restrict lead reads to participants" on public.partner_leads;
create policy "Restrict lead reads to participants" on public.partner_leads as restrictive for select to authenticated using (student_user_id = (select auth.uid()) or exists (select 1 from public.institution_partners p where p.id=partner_id and p.user_id=(select auth.uid()) and p.status='approved'));
drop policy if exists "Insert own consented partner lead" on public.partner_leads;
create policy "Insert own consented partner lead" on public.partner_leads for insert to authenticated with check (student_user_id = (select auth.uid()));

-- A direct lead insert is the consent action. The trigger validates the signed-in
-- student and deducts exactly one credit in the SAME database transaction.
create or replace function public.nyansa_partner_lead_before_insert() returns trigger
language plpgsql security definer set search_path=pg_catalog,public as $$
declare contact text; remaining integer;
begin
  if auth.uid() is null or new.student_user_id is distinct from auth.uid() then raise exception 'Sign-in and explicit consent are required'; end if;
  contact:=lower(trim(coalesce(auth.jwt()->>'email','')));
  if lower(trim(coalesce(new.student_email,''))) is distinct from contact or position('@' in contact)<2 or length(trim(coalesce(new.student_name,''))) not between 2 and 120 or length(trim(coalesce(new.programme_interest,''))) not between 2 and 250 then raise exception 'Invalid student details'; end if;
  perform pg_advisory_xact_lock(hashtextextended('institution-lead:'||new.partner_id::text||':'||new.student_user_id::text,0));
  if exists(select 1 from public.partner_leads where partner_id=new.partner_id and student_user_id=new.student_user_id) then raise exception 'This student has already opted in; no additional credit was deducted' using errcode='23505'; end if;
  update public.institution_partners set lead_credits=coalesce(lead_credits,0)-1 where id=new.partner_id and status='approved' and coalesce(lead_credits,0)>0 returning lead_credits into remaining;
  if not found then raise exception 'This partner has no available lead credits or is not approved'; end if;
  return new;
end $$;
revoke all on function public.nyansa_partner_lead_before_insert() from public, anon, authenticated;
drop trigger if exists nyansa_partner_lead_debit on public.partner_leads;
create trigger nyansa_partner_lead_debit before insert on public.partner_leads for each row execute function public.nyansa_partner_lead_before_insert();

-- The server verifies Paystack before inserting this service-role-only event. An
-- AFTER INSERT trigger applies the credit once; duplicate references never fire it.
create table if not exists public.institution_partner_wallet_events (
  reference text primary key,
  partner_id uuid not null references public.institution_partners(id),
  user_id uuid not null references auth.users(id),
  email text not null,
  credits integer not null check (credits in (50,100,150)),
  amount integer not null,
  currency text not null check (currency='GHS'),
  environment text not null check (environment in ('test','live')),
  paid_at timestamptz not null,
  credited boolean not null default false,
  created_at timestamptz not null default now(),
  check ((credits=50 and amount=50000) or (credits=100 and amount=100000) or (credits=150 and amount=150000))
);
alter table public.institution_partner_wallet_events enable row level security;
revoke all on public.institution_partner_wallet_events from public, anon, authenticated;
grant select, insert, update on public.institution_partner_wallet_events to service_role;
create or replace function public.nyansa_credit_partner_wallet_after_insert() returns trigger
language plpgsql security definer set search_path=pg_catalog,public as $$
declare current_balance integer; payment_plan text; inserted_ref text; previous public.payments%rowtype;
begin
  perform pg_advisory_xact_lock(hashtextextended('institution-payment:'||new.reference,0));
  select coalesce(lead_credits,0) into current_balance from public.institution_partners where id=new.partner_id and user_id=new.user_id and status='approved' for update;
  if not found then raise exception 'Partner not approved or not owned by this account'; end if;
  payment_plan:='partner_wallet_'||new.environment||'_'||new.credits::text;
  insert into public.payments(user_id,email,plan,amount,currency,reference,status,created_at)
    values(new.user_id,lower(trim(new.email)),payment_plan,new.amount,'GHS',new.reference,'success',now())
    on conflict(reference) do nothing returning reference into inserted_ref;
  if inserted_ref is null then
    select * into previous from public.payments where reference=new.reference;
    if not found or previous.user_id is distinct from new.user_id or previous.plan is distinct from payment_plan or previous.amount is distinct from new.amount or previous.currency is distinct from 'GHS' or previous.status is distinct from 'success' or lower(trim(previous.email)) is distinct from lower(trim(new.email)) then raise exception 'Payment reference conflict'; end if;
  else
    update public.institution_partners set lead_credits=current_balance+new.credits where id=new.partner_id;
  end if;
  update public.institution_partner_wallet_events set credited=true where reference=new.reference;
  return new;
end $$;
revoke all on function public.nyansa_credit_partner_wallet_after_insert() from public, anon, authenticated;
drop trigger if exists nyansa_credit_institution_wallet on public.institution_partner_wallet_events;
create trigger nyansa_credit_institution_wallet after insert on public.institution_partner_wallet_events for each row execute function public.nyansa_credit_partner_wallet_after_insert();

-- Readiness contains only booleans, allowing clients to avoid an unsafe direct
-- insert when the atomic lead trigger has not been installed.
create or replace view public.institution_partner_wallet_readiness as
  select exists(select 1 from pg_catalog.pg_trigger where tgrelid='public.partner_leads'::regclass and tgname='nyansa_partner_lead_debit' and not tgisinternal and tgenabled='O')
         and exists(select 1 from pg_catalog.pg_index where indexrelid=to_regclass('public.partner_leads_partner_student_unique') and indisunique and indisvalid) as lead_ready,
         exists(select 1 from pg_catalog.pg_trigger where tgrelid='public.institution_partner_wallet_events'::regclass and tgname='nyansa_credit_institution_wallet' and not tgisinternal and tgenabled='O')
         and exists(select 1 from pg_catalog.pg_index where indexrelid=to_regclass('public.payments_reference_unique') and indisunique and indisvalid) as wallet_ready;
revoke all on public.institution_partner_wallet_readiness from public, anon, authenticated;
grant select on public.institution_partner_wallet_readiness to authenticated, service_role;

-- The app no longer calls legacy RPCs; revoke their client/service execution to
-- avoid double deductions or credits when upgrading an earlier installation.
do $$ begin
  if to_regprocedure('public.submit_institution_partner_testing(text,text,text,text,text,text)') is not null then execute 'revoke all on function public.submit_institution_partner_testing(text,text,text,text,text,text) from public, anon, authenticated'; end if;
  if to_regprocedure('public.list_approved_institution_partners()') is not null then execute 'revoke all on function public.list_approved_institution_partners() from public, anon, authenticated'; end if;
  if to_regprocedure('public.opt_in_institution_partner(uuid,text,text,boolean)') is not null then execute 'revoke all on function public.opt_in_institution_partner(uuid,text,text,boolean) from public, anon, authenticated'; end if;
  if to_regprocedure('public.credit_institution_partner_wallet(text,uuid,uuid,text,integer,integer,text)') is not null then execute 'revoke all on function public.credit_institution_partner_wallet(text,uuid,uuid,text,integer,integer,text) from public, anon, authenticated, service_role'; end if;
end $$;
