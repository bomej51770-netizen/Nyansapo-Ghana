-- Run once in the Supabase SQL editor. Each signed-in counselor can access only their own workspace.
create table if not exists public.counselor_workspaces (
  owner_id uuid primary key references auth.users(id) on delete cascade,
  cohorts jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.counselor_workspaces enable row level security;
grant select, insert, update, delete on public.counselor_workspaces to authenticated;
drop policy if exists "Counselors manage their workspace" on public.counselor_workspaces;
create policy "Counselors manage their workspace" on public.counselor_workspaces
  for all to authenticated using ((select auth.uid()) = owner_id)
  with check ((select auth.uid()) = owner_id);
