-- Apply once to the existing payments table after checking for duplicate references.
-- A unique reference makes Paystack confirmation and retries idempotent.
-- Guest payments require a nullable user_id; authenticated payments retain their user_id.
alter table public.payments alter column user_id drop not null;
create unique index if not exists payments_reference_unique on public.payments(reference);
-- Keep RLS enabled and ensure clients cannot write payment status or access other users' rows.
alter table public.payments enable row level security;
revoke insert, update, delete on public.payments from public, anon, authenticated;
-- The application server uses the service role for verified inserts and reads.
grant select, insert on public.payments to service_role;
