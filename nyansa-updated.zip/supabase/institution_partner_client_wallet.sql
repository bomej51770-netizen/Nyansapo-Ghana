-- WARNING: This requested client-side wallet flow does NOT verify Paystack on a
-- server. An authenticated partner can fabricate a callback or directly set its
-- own lead_credits. Do not use this policy for production billing.
-- It also allows authenticated users to read all columns of approved institutions;
-- do not place private contact information in these rows without further safeguards.
-- Apply after institution_partner_wallet.sql and after resolving duplicate references.
create unique index if not exists payments_reference_unique on public.payments(reference);
alter table public.institution_partners enable row level security;
alter table public.payments enable row level security;
grant select on public.institution_partners to authenticated;
grant update (lead_credits) on public.institution_partners to authenticated;
grant insert (user_id,email,plan,amount,currency,reference,status) on public.payments to authenticated;

drop policy if exists "Restrict institution reads to owner" on public.institution_partners;
create policy "Restrict institution reads to owner" on public.institution_partners as restrictive for select to authenticated using (user_id=(select auth.uid()) or status='approved');
drop policy if exists "Read approved institution directory" on public.institution_partners;
create policy "Read approved institution directory" on public.institution_partners for select to authenticated using (status='approved');
drop policy if exists "Update own client reported wallet" on public.institution_partners;
create policy "Update own client reported wallet" on public.institution_partners for update to authenticated
  using (user_id=(select auth.uid()) and status='approved')
  with check (user_id=(select auth.uid()) and status='approved' and lead_credits>=0);

drop policy if exists "Insert client reported partner payment" on public.payments;
create policy "Insert client reported partner payment" on public.payments for insert to authenticated
with check (
  user_id=(select auth.uid()) and status='success' and currency='GHS' and
  lower(trim(email))=lower(trim(coalesce(auth.jwt()->>'email',''))) and
  ((plan in ('partner_wallet_test_50','partner_wallet_live_50') and amount=50000) or
   (plan in ('partner_wallet_test_100','partner_wallet_live_100') and amount=100000) or
   (plan in ('partner_wallet_test_150','partner_wallet_live_150') and amount=150000))
);
