-- Run in the Supabase SQL editor. Administrative approvals and lead qualification are service-role only.
create table if not exists public.partner_profiles (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null unique references auth.users(id) on delete cascade,
  institution_name text not null,
  institution_type text not null,
  contact_name text not null,
  official_email text not null,
  phone text not null,
  billing_method text not null check (billing_method in ('prepaid','invoice')),
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);
create table if not exists public.partner_wallets (
  partner_id uuid not null references public.partner_profiles(id) on delete cascade,
  environment text not null check (environment in ('live','test')),
  balance integer not null default 0 check (balance >= 0),
  updated_at timestamptz not null default now(),
  primary key (partner_id, environment)
);
create table if not exists public.partner_wallet_transactions (
  reference text primary key,
  partner_id uuid not null references public.partner_profiles(id),
  owner_id uuid not null references auth.users(id),
  credits integer not null check (credits in (50,100,150)),
  amount integer not null,
  currency text not null check (currency = 'GHS'),
  environment text not null check (environment in ('live','test')),
  paid_at timestamptz not null,
  created_at timestamptz not null default now()
);
create table if not exists public.partner_student_leads (
  id uuid primary key default gen_random_uuid(),
  partner_id uuid not null references public.partner_profiles(id) on delete cascade,
  student_id uuid not null references auth.users(id) on delete cascade,
  student_name text not null,
  contact_email text not null,
  interest text not null,
  consented_at timestamptz not null default now(),
  status text not null default 'pending_review' check (status in ('pending_review','released','rejected')),
  released_at timestamptz,
  unique (partner_id, student_id)
);
alter table public.partner_profiles enable row level security;
alter table public.partner_wallets enable row level security;
alter table public.partner_wallet_transactions enable row level security;
alter table public.partner_student_leads enable row level security;
revoke all on public.partner_profiles, public.partner_wallets, public.partner_wallet_transactions, public.partner_student_leads from anon, authenticated;
grant select on public.partner_profiles, public.partner_wallets, public.partner_wallet_transactions, public.partner_student_leads to authenticated;
drop policy if exists "Read own partner profile" on public.partner_profiles;
create policy "Read own partner profile" on public.partner_profiles for select to authenticated using (owner_id = (select auth.uid()));
drop policy if exists "Read own approved partner wallet" on public.partner_wallets;
create policy "Read own approved partner wallet" on public.partner_wallets for select to authenticated using (exists (select 1 from public.partner_profiles p where p.id = partner_id and p.owner_id = (select auth.uid()) and p.status = 'approved'));
drop policy if exists "Read own approved partner payments" on public.partner_wallet_transactions;
create policy "Read own approved partner payments" on public.partner_wallet_transactions for select to authenticated using (owner_id = (select auth.uid()) and exists (select 1 from public.partner_profiles p where p.id = partner_id and p.owner_id = (select auth.uid()) and p.status = 'approved'));
drop policy if exists "Read consented leads" on public.partner_student_leads;
create policy "Read consented leads" on public.partner_student_leads for select to authenticated using (student_id = (select auth.uid()) or (status = 'released' and exists (select 1 from public.partner_profiles p where p.id = partner_id and p.owner_id = (select auth.uid()) and p.status = 'approved')));

create or replace function public.submit_partner_application(p_institution_name text, p_institution_type text, p_contact_name text, p_official_email text, p_phone text, p_billing_method text)
returns jsonb language plpgsql security definer set search_path = pg_catalog, public as $$
declare new_id uuid;
begin
  if auth.uid() is null then raise exception 'Sign in required'; end if;
  if length(trim(coalesce(p_institution_name,''))) not between 2 and 160 or p_institution_type not in ('Public university','Private university','Technical university','College of Education','Nursing training institution','Other') or length(trim(coalesce(p_contact_name,''))) not between 2 and 120 or length(trim(coalesce(p_official_email,''))) not between 3 and 254 or position('@' in p_official_email) < 2 or length(trim(coalesce(p_phone,''))) not between 5 and 40 or p_billing_method not in ('prepaid','invoice') then raise exception 'Invalid application details'; end if;
  insert into public.partner_profiles(owner_id,institution_name,institution_type,contact_name,official_email,phone,billing_method,status)
    values(auth.uid(),trim(p_institution_name),p_institution_type,trim(p_contact_name),lower(trim(p_official_email)),trim(p_phone),p_billing_method,'pending') returning id into new_id;
  return jsonb_build_object('id',new_id,'status','pending');
end;
$$;
revoke all on function public.submit_partner_application(text,text,text,text,text,text) from public, anon;
grant execute on function public.submit_partner_application(text,text,text,text,text,text) to authenticated;

create or replace function public.list_approved_partners() returns table(id uuid,institution_name text,institution_type text)
language sql security definer set search_path = pg_catalog, public as $$
  select p.id,p.institution_name,p.institution_type from public.partner_profiles p where auth.uid() is not null and p.status = 'approved' order by p.institution_name;
$$;
revoke all on function public.list_approved_partners() from public, anon;
grant execute on function public.list_approved_partners() to authenticated;

create or replace function public.request_partner_lead(p_partner_id uuid,p_student_name text,p_interest text,p_consent boolean)
returns jsonb language plpgsql security definer set search_path = pg_catalog, public as $$
declare existing_id uuid; contact text;
begin
  if auth.uid() is null or p_consent is distinct from true then raise exception 'Explicit consent and sign-in required'; end if;
  contact := lower(trim(coalesce(auth.jwt()->>'email','')));
  if length(trim(coalesce(p_student_name,''))) not between 2 and 120 or length(trim(coalesce(p_interest,''))) not between 2 and 250 or position('@' in contact) < 2 then raise exception 'Invalid student details'; end if;
  if not exists(select 1 from public.partner_profiles where id = p_partner_id and status = 'approved') then raise exception 'Partner unavailable'; end if;
  perform pg_advisory_xact_lock(hashtextextended('partner-lead:' || p_partner_id::text || ':' || auth.uid()::text,0));
  select id into existing_id from public.partner_student_leads where partner_id = p_partner_id and student_id = auth.uid();
  if found then return jsonb_build_object('id',existing_id,'status','already_requested'); end if;
  insert into public.partner_student_leads(partner_id,student_id,student_name,contact_email,interest,status) values(p_partner_id,auth.uid(),trim(p_student_name),contact,trim(p_interest),'pending_review') returning id into existing_id;
  return jsonb_build_object('id',existing_id,'status','pending_review');
end;
$$;
revoke all on function public.request_partner_lead(uuid,text,text,boolean) from public, anon;
grant execute on function public.request_partner_lead(uuid,text,text,boolean) to authenticated;

-- Only call this after an administrator has independently qualified the lead.
-- Test credits never release real student information. Invoice leads do not debit a wallet.
create or replace function public.release_qualified_partner_lead(p_lead_id uuid) returns jsonb
language plpgsql security definer set search_path = pg_catalog, public as $$
declare l public.partner_student_leads%rowtype; p public.partner_profiles%rowtype; remaining integer;
begin
  select * into l from public.partner_student_leads where id = p_lead_id for update;
  if not found then raise exception 'Lead unavailable'; end if;
  if l.status = 'released' then return jsonb_build_object('id',l.id,'status','released'); end if;
  if l.status <> 'pending_review' then raise exception 'Lead not eligible for release'; end if;
  select * into p from public.partner_profiles where id = l.partner_id for update;
  if not found or p.status <> 'approved' then raise exception 'Partner unavailable'; end if;
  if p.billing_method = 'prepaid' then
    update public.partner_wallets set balance = balance - 1, updated_at = now() where partner_id = p.id and environment = 'live' and balance > 0 returning balance into remaining;
    if not found then raise exception 'Insufficient live wallet credits'; end if;
  end if;
  update public.partner_student_leads set status = 'released', released_at = now() where id = l.id;
  return jsonb_build_object('id',l.id,'status','released','balance',remaining);
end;
$$;
revoke all on function public.release_qualified_partner_lead(uuid) from public, anon, authenticated;
grant execute on function public.release_qualified_partner_lead(uuid) to service_role;

create or replace function public.credit_partner_wallet(p_reference text,p_partner_id uuid,p_owner_id uuid,p_credits integer,p_amount integer,p_currency text,p_environment text,p_paid_at timestamptz)
returns jsonb language plpgsql security definer set search_path = pg_catalog, public as $$
declare prior public.partner_wallet_transactions%rowtype; balance_now integer;
begin
  if p_reference is null or p_reference !~ '^[A-Za-z0-9._=-]{1,100}$' or p_partner_id is null or p_owner_id is null or p_currency <> 'GHS' or p_environment not in ('live','test') or p_paid_at is null or not ((p_credits=50 and p_amount=50000) or (p_credits=100 and p_amount=100000) or (p_credits=150 and p_amount=150000)) then raise exception 'Invalid payment details'; end if;
  perform pg_advisory_xact_lock(hashtextextended('partner-wallet:' || p_partner_id::text,0));
  perform pg_advisory_xact_lock(hashtextextended('partner-reference:' || p_reference,0));
  if not exists(select 1 from public.partner_profiles where id=p_partner_id and owner_id=p_owner_id and status='approved' and billing_method='prepaid') then raise exception 'Partner is not eligible'; end if;
  select * into prior from public.partner_wallet_transactions where reference=p_reference;
  if found then
    if prior.partner_id <> p_partner_id or prior.owner_id <> p_owner_id or prior.credits <> p_credits or prior.amount <> p_amount or prior.currency <> p_currency or prior.environment <> p_environment then raise exception 'Reference conflict'; end if;
    select balance into balance_now from public.partner_wallets where partner_id=p_partner_id and environment=p_environment;
    return jsonb_build_object('reference',p_reference,'credits',p_credits,'environment',p_environment,'balance',coalesce(balance_now,0));
  end if;
  insert into public.partner_wallet_transactions(reference,partner_id,owner_id,credits,amount,currency,environment,paid_at) values(p_reference,p_partner_id,p_owner_id,p_credits,p_amount,p_currency,p_environment,p_paid_at);
  insert into public.partner_wallets(partner_id,environment,balance,updated_at) values(p_partner_id,p_environment,p_credits,now())
    on conflict(partner_id,environment) do update set balance=public.partner_wallets.balance+excluded.balance,updated_at=now() returning balance into balance_now;
  return jsonb_build_object('reference',p_reference,'credits',p_credits,'environment',p_environment,'balance',balance_now);
end;
$$;
revoke all on function public.credit_partner_wallet(text,uuid,uuid,integer,integer,text,text,timestamptz) from public, anon, authenticated;
grant execute on function public.credit_partner_wallet(text,uuid,uuid,integer,integer,text,text,timestamptz) to service_role;
