-- Run in Supabase SQL Editor. Server verification calls the function using the service role only.
create table if not exists public.counselor_payment_transactions (
  reference text primary key,
  owner_id uuid not null references auth.users(id) on delete cascade,
  plan text not null check (plan in ('starter', 'pro')),
  amount integer not null,
  currency text not null check (currency = 'GHS'),
  environment text not null check (environment in ('test', 'live')),
  paid_at timestamptz not null,
  term_status text not null check (term_status in ('active', 'test_active')),
  term_start timestamptz not null,
  term_end timestamptz not null,
  created_at timestamptz not null default now()
);
create table if not exists public.counselor_entitlements (
  owner_id uuid not null references auth.users(id) on delete cascade,
  environment text not null check (environment in ('test', 'live')),
  plan text not null check (plan in ('starter', 'pro')),
  term_status text not null check (term_status in ('active', 'test_active')),
  term_start timestamptz not null,
  term_end timestamptz not null,
  transaction_reference text not null references public.counselor_payment_transactions(reference),
  updated_at timestamptz not null default now(),
  primary key (owner_id, environment)
);
alter table public.counselor_payment_transactions enable row level security;
alter table public.counselor_entitlements enable row level security;
revoke all on public.counselor_payment_transactions from anon, authenticated;
revoke all on public.counselor_entitlements from anon, authenticated;
grant select on public.counselor_payment_transactions, public.counselor_entitlements to authenticated;
drop policy if exists "Read own counselor payments" on public.counselor_payment_transactions;
create policy "Read own counselor payments" on public.counselor_payment_transactions for select to authenticated using ((select auth.uid()) = owner_id);
drop policy if exists "Read own counselor entitlement" on public.counselor_entitlements;
create policy "Read own counselor entitlement" on public.counselor_entitlements for select to authenticated using ((select auth.uid()) = owner_id);

create or replace function public.activate_counselor_payment(p_reference text, p_user_id uuid, p_plan text, p_amount integer, p_currency text, p_environment text, p_paid_at timestamptz)
returns jsonb language plpgsql security definer set search_path = pg_catalog, public as $$
declare
  previous public.counselor_payment_transactions%rowtype;
  current_term public.counselor_entitlements%rowtype;
  start_at timestamptz;
  end_at timestamptz;
  new_status text;
begin
  if p_user_id is null or p_reference is null or p_reference !~ '^[A-Za-z0-9._=-]{1,100}$' or p_currency <> 'GHS' or p_environment not in ('test','live') or p_paid_at is null or not ((p_plan = 'starter' and p_amount = 40000) or (p_plan = 'pro' and p_amount = 90000)) then
    raise exception 'Invalid payment data';
  end if;
  perform pg_advisory_xact_lock(hashtextextended('counselor-owner:' || p_user_id::text, 0));
  perform pg_advisory_xact_lock(hashtextextended('counselor-reference:' || p_reference, 0));
  select * into previous from public.counselor_payment_transactions where reference = p_reference;
  if found then
    if previous.owner_id <> p_user_id or previous.plan <> p_plan or previous.amount <> p_amount or previous.currency <> p_currency or previous.environment <> p_environment then raise exception 'Reference conflict'; end if;
    return jsonb_build_object('reference', previous.reference, 'plan', previous.plan, 'term_status', previous.term_status, 'term_start', previous.term_start, 'term_end', previous.term_end);
  end if;
  select * into current_term from public.counselor_entitlements where owner_id = p_user_id and environment = p_environment;
  start_at := now();
  if found and current_term.plan = p_plan and current_term.term_end > now() then start_at := current_term.term_end; end if;
  end_at := start_at + interval '90 days';
  new_status := case when p_environment = 'test' then 'test_active' else 'active' end;
  insert into public.counselor_payment_transactions(reference, owner_id, plan, amount, currency, environment, paid_at, term_status, term_start, term_end)
    values(p_reference, p_user_id, p_plan, p_amount, p_currency, p_environment, p_paid_at, new_status, start_at, end_at);
  insert into public.counselor_entitlements(owner_id, environment, plan, term_status, term_start, term_end, transaction_reference, updated_at)
    values(p_user_id, p_environment, p_plan, new_status, start_at, end_at, p_reference, now())
    on conflict (owner_id, environment) do update set plan = excluded.plan, term_status = excluded.term_status, term_start = excluded.term_start, term_end = excluded.term_end, transaction_reference = excluded.transaction_reference, updated_at = now();
  return jsonb_build_object('reference', p_reference, 'plan', p_plan, 'term_status', new_status, 'term_start', start_at, 'term_end', end_at);
end;
$$;
revoke all on function public.activate_counselor_payment(text, uuid, text, integer, text, text, timestamptz) from public, anon, authenticated;
grant execute on function public.activate_counselor_payment(text, uuid, text, integer, text, text, timestamptz) to service_role;
