-- Apply after institution_partner_wallet.sql to make the Edge Function the
-- authority for paid records and wallet credits. Do not expose a service key.
alter table public.payments enable row level security;
alter table public.institution_partners enable row level security;
revoke insert, update, delete on public.payments from public, anon, authenticated;
revoke insert (user_id,email,plan,amount,currency,reference,status) on public.payments from public, anon, authenticated;
revoke select (reference) on public.payments from anon;
revoke update on public.institution_partners from public, anon, authenticated;
revoke update (lead_credits) on public.institution_partners from public, anon, authenticated;
drop policy if exists "Update own client reported wallet" on public.institution_partners;
drop policy if exists "Insert client reported partner payment" on public.payments;
drop policy if exists "Client reported payment callbacks" on public.payments;
grant select (user_id,reference,plan,amount,currency,status,created_at) on public.payments to authenticated;
grant select, insert, update on public.payments to service_role;
grant select on public.institution_partners to service_role;
grant update (lead_credits) on public.institution_partners to service_role;
drop policy if exists "Read own payment history" on public.payments;
create policy "Read own payment history" on public.payments for select to authenticated using (user_id=(select auth.uid()));
drop policy if exists "Restrict payment history to owner" on public.payments;
create policy "Restrict payment history to owner" on public.payments as restrictive for select to authenticated using (user_id=(select auth.uid()));
-- The deployed verify-paystack function must verify with Paystack and perform
-- partner credit and payment logging atomically/idempotently server-side.
