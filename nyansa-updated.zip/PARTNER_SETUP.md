# Partner onboarding and lead wallet

## Setup

1. Apply `supabase/institution_partner_wallet.sql` and then `supabase/institution_partner_client_wallet.sql` to the existing tables after resolving duplicate references and opt-ins. Applications are automatically **approved for testing**; replace automatic approval with independent institutional review before production.
2. Configure `VITE_PAYSTACK_PUBLIC_KEY`, `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` at build time. Apply `supabase/verify_paystack_hardening.sql` to remove client-side credit/payment writes and enable owner-only payment-history reads. Never put Paystack or Supabase service-role secrets in browser code.
3. Use an isolated test project. Test callbacks update the same balance as live callbacks; never use test credentials with real student data. The supplied duplicate `pk_test_` prefix is normalized by the existing client helper.

## Approval, consent and qualification

The direct approved-partner query requires authenticated users to be able to read approved institution rows. With the included client-wallet policy, all columns of approved rows may be read by authenticated users; do not store private contact information there without further safeguards. A student consents to sharing their name, account email and interest with one selected institution.

A direct `partner_leads` insert remains guarded by a database trigger that deducts one credit in the same transaction, rejects insufficient balances and rolls back on duplicate opt-ins. The modal checks that the trigger is enabled before inserting. Opt-ins are immediately visible to the selected institution; they are not independently qualified.

## Payment recovery

The Paystack callback invokes the deployed `verify-paystack` Edge Function. Only `verified: true` permits a refresh of `institution_partners.lead_credits` and the account's `payments` history; the browser no longer increments credits or inserts a success record. The Edge Function must validate partner ownership and credit/log atomically and idempotently by reference before returning success. If the refreshed payment record is not visible, the modal keeps the reference and does not claim that credits were added.

If authentication or table permissions are unavailable, the modal displays the Supabase error. Existing table constraints and defaults must support the supplied field values; audit RLS and restore server verification before production.
