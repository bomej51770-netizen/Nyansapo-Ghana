# Scholarship directory sources and limits

The 22 entries are grouped 6 government/SLTF, 7 corporate/mining, 6 university aid and 3 international. They include allowances and a repayable loan as well as scholarships. Coverage badges describe a possible type of assistance, not a guarantee; document chips are examples to check, not an authoritative requirements list. Every deadline is labelled “check provider” rather than asserting that a scheme is open.

## Provider references

- [GETFund](https://www.getfund.gov.gh/) and [Ghana Scholarships Authority](https://scholarships.gov.gh/) for current local and bilateral notices.
- [Ministry of Health](https://moh.gov.gh/), [Ministry of Education](https://moe.gov.gh/) and [Students Loan Trust Fund](https://www.sltf.gov.gh/) for current allowance and loan policies. An SLTF loan is repayable.
- [MTN Ghana Foundation’s 2026 notice](https://mtn.com.gh/newsabout/mtn-ghana-foundation-opens-application-for-2026-bright-scholarship/) described tuition, accommodation and learning resources and focused on continuing students; it does not establish that a future intake is open. [NADeF](https://nadef.org/) describes scholarship beneficiaries, and [Gold Fields Ghana Foundation](https://www.goldfields-ghana.com/) lists education among its focus areas. Current awards and community rules still need confirmation.
- [Mastercard Foundation Scholars at Ashesi](https://ashesi.edu.gh/the-mastercard-foundation-scholars-program/) and [KNUST](https://www.knust.edu.gh/) for partner-specific applications; institutional aid offices should confirm their own current funds and requirements.
- [Ashinaga Africa Initiative](https://www.ashinaga.org/en/our-work/ashinaga-africa-initiative/), [Zawadi Africa](https://www.zawadiafrica.org/) and [Stipendium Hungaricum](https://stipendiumhungaricum.hu/) for international programme information.

The exact current Telecel Female STEM, Tullow, bank CSR and combined UDS/UEW/UMaT bursary schemes were not independently confirmed. They are explicitly labelled “Programme unconfirmed.” Documents shown for every entry are illustrative and must be checked against the provider’s current notice. The Essay Coach link provides a general drafting workspace; it does not imply that every scheme requires an essay.

## Shared eligibility screening

`src/dashboard/scholarshipData.ts` is the single source for both the directory and detailed filter. Each entry carries aggregate, income, field, region/community, gender/special-focus and institution criteria, with explicit reported, unconfirmed or unknown confidence. No numerical aggregate limits or fixed household-income thresholds were verified for these 22 entries, so they remain unknown rather than being invented. The aggregate slider and income band are displayed as context; financial need is self-reported separately and still requires provider assessment. “Qualified · known criteria” means only that reported, selected criteria match; unknown and unconfirmed checks remain visible and this is not a provider decision. The legacy matching bundle receives a generated adapter from this same data and treats uncertain eligibility as possible rather than guaranteed.
