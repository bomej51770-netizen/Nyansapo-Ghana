import { useEffect, useRef, useState } from 'react'
import type { Session } from '@supabase/supabase-js'
import { cloud } from '../cloudProfile'
import { getPaystackPublicKey, loadPaystack } from '../PaystackCheckout'
import { verifyPaystack } from '../paystackVerification'
import './partners.css'

type Tab = 'application' | 'wallet' | 'consent'
type Partner = { id: string; user_id: string; institution_name: string; institution_type: string; contact_name: string; official_email: string; phone: string; billing_method: 'prepaid' | 'invoice'; status: 'pending' | 'approved' | 'rejected'; lead_credits: number }
type PublicPartner = { id: string; institution_name: string; institution_type: string }
type Lead = { id: string; student_name: string; student_email: string; programme_interest: string; status: string; created_at: string }
type Bundle = 50 | 100 | 150
type Pending = { reference: string; partnerId: string; credits: Bundle; createdAt: string }
type PaymentHistory = { reference: string; plan: string; amount: number; currency: string; status: string; created_at: string }
const packs: Record<Bundle, { price: string; amount: number }> = { 50: { price: 'GHS 500', amount: 50000 }, 100: { price: 'GHS 1,000', amount: 100000 }, 150: { price: 'GHS 1,500', amount: 150000 } }
const pendingKey = (id: string) => `nyansa-partner-wallet-pending-${id}`
function readPending(id: string): Pending[] { try { const data = JSON.parse(localStorage.getItem(pendingKey(id)) || '[]'); return Array.isArray(data) ? data.filter((p: Pending) => p && typeof p.reference === 'string' && typeof p.partnerId === 'string' && [50, 100, 150].includes(p.credits)) : [] } catch { return [] } }
function savePending(id: string, item: Pending) { const list = [item, ...readPending(id).filter(p => p.reference !== item.reference)]; localStorage.setItem(pendingKey(id), JSON.stringify(list)); return list }
const emptyForm = { institution: '', type: 'Public university', contact: '', email: '', phone: '', billing: 'prepaid', accreditation: '' }
function errorText(error: unknown) { return error && typeof error === 'object' && 'message' in error && typeof error.message === 'string' ? error.message : '' }

export default function PartnerOnboarding() {
  const [open, setOpen] = useState(false)
  const [tab, setTab] = useState<Tab>('application')
  const [session, setSession] = useState<Session | null>(null)
  const [mode, setMode] = useState<'loading' | 'live' | 'error' | 'guest'>('loading')
  const [profile, setProfile] = useState<Partner | null>(null)
  const [partners, setPartners] = useState<PublicPartner[]>([])
  const [leads, setLeads] = useState<Lead[]>([])
  const [balance, setBalance] = useState(0)
  const [form, setForm] = useState(emptyForm)
  const [studentName, setStudentName] = useState('')
  const [studentInterest, setStudentInterest] = useState('')
  const [studentAggregate, setStudentAggregate] = useState('')
  const [studentPhone, setStudentPhone] = useState('')
  const [selectedPartner, setSelectedPartner] = useState('')
  const [consent, setConsent] = useState(false)
  const [pending, setPending] = useState<Pending[]>([])
  const [message, setMessage] = useState('')
  const [busy, setBusy] = useState(false)
  const [receipt, setReceipt] = useState<{ reference: string; credits: number; balance: number; environment: string } | null>(null)
  const [history, setHistory] = useState<PaymentHistory[] | null>(null)
  const completed = useRef(false)
  const environment = getPaystackPublicKey()?.startsWith('pk_live_') ? 'live' : 'test'

  const load = async () => {
    setMode('loading'); setSession(null); setPending([]); setProfile(null); setLeads([]); setPartners([]); setBalance(0); setHistory(null)
    try {
      if (!cloud) { setSession(null); setMode('error'); setMessage('Supabase is not configured. Please contact the site owner.'); return false }
      const { data: auth, error: authError } = await cloud.auth.getSession()
      if (authError) throw authError
      const current = auth.session; setSession(current)
      if (!current?.user.email) { setMode('guest'); return false }
      setPending(readPending(current.user.id))
      const { data: own, error: profileError } = await cloud.from('institution_partners').select('*').eq('user_id', current.user.id).order('created_at', { ascending: false }).limit(1).maybeSingle()
      if (profileError) throw profileError
      const partner = own as Partner | null; setProfile(partner)
      const { data: available, error: listError } = await cloud.from('institution_partners').select('id,institution_name,institution_type').eq('status', 'approved')
      if (listError) throw listError
      setPartners((available || []) as PublicPartner[])
      if (partner?.status === 'approved') {
        const leadResult = await cloud.from('partner_leads').select('*').eq('partner_id', partner.id).eq('status', 'verified').order('created_at', { ascending: false })
        if (leadResult.error) throw leadResult.error
        setBalance(partner.lead_credits || 0); setLeads((leadResult.data || []) as Lead[])
      }
      setMode('live')
      return true
    } catch (error) { const text = errorText(error) || 'Unknown Supabase error.'; console.error('Partner data:', text); setMode('error'); setMessage(text); return false }
  }

  useEffect(() => {
    const addStudentEntry = () => {
      if (window.location.pathname !== '/pricing') return
      const button = document.querySelector('button[data-source-loc="src/pages/Pricing.tsx:91:12"]')
      if (!button || button.parentElement?.querySelector('[data-student-partner-consent]')) return
      const link = document.createElement('button')
      link.type = 'button'; link.dataset.studentPartnerConsent = 'true'; link.className = 'partner-student-entry'; link.textContent = 'Student? Choose who can contact you →'
      button.insertAdjacentElement('afterend', link)
    }
    addStudentEntry()
    const observer = new MutationObserver(addStudentEntry)
    observer.observe(document.body, { childList: true, subtree: true })
    const click = (event: MouseEvent) => {
      const target = event.target
      if (!(target instanceof Element) || !['/pricing', '/schools', '/'].includes(window.location.pathname)) return
      const studentEntry = target.closest('button[data-student-partner-consent], button[data-open-partner-consent]')
      if (!studentEntry && !target.closest('button[data-source-loc="src/pages/Pricing.tsx:91:12"], button[data-open-partner]')) return
      event.preventDefault(); event.stopPropagation(); setTab(studentEntry ? 'consent' : 'application'); setMessage(''); setReceipt(null); setForm(emptyForm); setStudentName(''); setStudentInterest(''); setSelectedPartner(''); setConsent(false); setOpen(true); void load()
    }
    document.addEventListener('click', click, true)
    return () => { observer.disconnect(); document.removeEventListener('click', click, true) }
  }, [])

  useEffect(() => {
    if (!open) return
    const escape = (event: KeyboardEvent) => { if (event.key === 'Escape' && !busy) setOpen(false) }
    document.addEventListener('keydown', escape); return () => document.removeEventListener('keydown', escape)
  }, [open, busy])

  const submitApplication = async (event: React.FormEvent) => {
    event.preventDefault(); setMessage('')
    if (!cloud || !session) { setMessage('Sign in with your Supabase email account to submit an application.'); return }
    setBusy(true)
    try {
      const { error } = await cloud.from('institution_partners').insert({ user_id: session.user.id, institution_name: form.institution.trim(), institution_type: form.type, contact_name: form.contact.trim(), official_email: form.email.trim(), phone: form.phone.trim(), billing_method: form.billing, accreditation_details: form.accreditation.trim(), status: 'pending', lead_credits: 0 })
      if (error) throw error
      if (await load()) setMessage('Application submitted. Nyansa will review it and your lead wallet opens once approved.')
    } catch (error) { const text = errorText(error) || 'Unknown Supabase error.'; console.error('Partner application:', text); setMessage(text) }
    finally { setBusy(false) }
  }

  const shareLead = async (event: React.FormEvent) => {
    event.preventDefault(); setMessage('')
    if (!cloud || !session) { setMessage('Sign in with your Supabase email account before submitting an opt-in.'); return }
    if (!selectedPartner || !consent) { setMessage('Choose an institution and confirm your consent.'); return }
    setBusy(true)
    try {
      const { data: readiness, error: readinessError } = await cloud.from('institution_partner_wallet_readiness').select('lead_ready').maybeSingle()
      if (readinessError) throw readinessError
      if (!readiness?.lead_ready) throw new Error('Atomic lead debit trigger is not enabled. No opt-in was saved.')
      const { error } = await cloud.from('partner_leads').insert({ partner_id: selectedPartner, student_user_id: session.user.id, student_name: studentName.trim(), student_email: session.user.email, programme_interest: studentInterest.trim(), wassce_aggregate: studentAggregate ? Number(studentAggregate) : null, student_phone: studentPhone.trim() || null, status: 'pending_verification' })
      if (error) throw error
      if (selectedPartner === profile?.id && !(await load())) return
      setMessage('Your opt-in was saved and one lead credit was deducted atomically.')
      setConsent(false)
    } catch (error) { const text = errorText(error) || 'Unknown Supabase error.'; console.error('Partner opt-in:', text); setMessage(text) }
    finally { setBusy(false) }
  }

  const verifyTopUp = async (item: Pending, owner: Session) => {
    if (!cloud) { setMessage('Supabase is unavailable. Keep the payment reference and contact support.'); return }
    setBusy(true); setMessage(''); setReceipt(null)
    let verified = false
    try {
      const { data, error } = await cloud.auth.getSession(); const current = data.session
      if (error) throw error
      if (!current || current.user.id !== owner.user.id || !current.user.email) throw new Error('Your session has expired. Keep the reference and contact support.')
      await verifyPaystack({ reference:item.reference,email:current.user.email,plan:`partner_wallet_${environment}_${item.credits}`,amount:packs[item.credits].amount,user_id:current.user.id,partner_id:item.partnerId,credits:item.credits })
      verified = true
      const [wallet, payments] = await Promise.all([
        cloud.from('institution_partners').select('lead_credits').eq('id',item.partnerId).eq('user_id',current.user.id).maybeSingle(),
        cloud.from('payments').select('reference,plan,amount,currency,status,created_at').eq('user_id',current.user.id).order('created_at',{ascending:false}).limit(20),
      ])
      if (wallet.error) throw wallet.error
      if (payments.error) throw payments.error
      if (!wallet.data || !Number.isInteger(wallet.data.lead_credits)) throw new Error('The partner wallet balance could not be refreshed.')
      setBalance(wallet.data.lead_credits); setHistory((payments.data || []) as PaymentHistory[])
      if (!(payments.data || []).some(payment => payment.reference === item.reference)) throw new Error('The verified payment is not yet visible in payment history. Keep the reference and contact support before paying again.')
      setReceipt({ reference:item.reference, credits:item.credits, balance:wallet.data.lead_credits, environment })
      try { const list = readPending(current.user.id).filter(p => p.reference !== item.reference); localStorage.setItem(pendingKey(current.user.id), JSON.stringify(list)); setPending(list) } catch { /* Keep the reference visible if storage is unavailable. */ }
    } catch (e) { const text = errorText(e) || 'Payment verification failed.'; console.error('Partner wallet:', text); setMessage(verified ? `Payment ${item.reference} was verified, but the wallet or payment history could not be confirmed: ${text} Do not pay again; contact support.` : `${text} No credits were added by this page. Keep the reference and retry verification.`) }
    finally { setBusy(false) }
  }

  const topUp = async (credits: Bundle) => {
    if (!cloud || !session) { setMessage('Sign in with your Supabase email account before topping up.'); return }
    if (!profile || profile.status !== 'approved') { setMessage('Submit an institution application before topping up the wallet.'); return }
    if (mode !== 'live') { setMessage('The partner wallet could not be loaded. Check your connection and database setup.'); return }
    setBusy(true); setMessage(''); setReceipt(null); completed.current = false
    let reserved: Pending | null = null, checkoutAttempted = false
    try {
      const { data, error } = await cloud.auth.getSession(); const current = data.session
      if (error || !current?.user.email || current.user.id !== session.user.id) throw new Error('Sign in again before paying.')
      const key = getPaystackPublicKey()
      if (!key || !/^pk_(test|live)_[a-zA-Z0-9]+$/.test(key)) throw new Error('Paystack is not configured. Please contact the site owner.')
      const item: Pending = { reference: `nyansa_partner_${crypto.randomUUID().replaceAll('-', '')}`, partnerId: profile.id, credits, createdAt: new Date().toISOString() }
      try { setPending(savePending(current.user.id, item)); reserved = item } catch { throw new Error('Your browser cannot save the payment reference. Enable local storage before checkout.') }
      try { await loadPaystack() } catch { throw new Error('Paystack could not load. Check your connection or content blocker and try again.') }
      const handler = window.PaystackPop!.setup({
        key, email: current.user.email, amount: packs[credits].amount, currency: 'GHS', channels: ['card', 'mobile_money'], ref: item.reference,
        metadata: { product: 'partner_wallet', credits: String(credits), partner_id: profile.id, user_id: current.user.id, email: current.user.email },
        callback: response => { if (completed.current) return; completed.current = true; if (!response.reference || response.reference !== item.reference) { setMessage('Paystack did not return the expected reference. No credits have been confirmed.'); setBusy(false); return } const returned = { ...item, reference: response.reference }; try { setPending(savePending(current.user.id, returned)) } catch { setPending(old => [returned, ...old]); setMessage('Copy the reference shown below; browser storage could not save it.') } void verifyTopUp(returned, current) },
        onClose: () => { if (!completed.current) { setMessage('Checkout was closed. If you completed payment, keep the reference and contact support before paying again.'); setBusy(false) } },
        onError: error => { setMessage(error?.message || 'Checkout failed. Keep the reference and contact support before retrying.'); setBusy(false) },
      })
      checkoutAttempted = true; handler.openIframe()
    } catch (e) {
      if (reserved && !checkoutAttempted) { try { const remaining = readPending(session.user.id).filter(item => item.reference !== reserved?.reference); localStorage.setItem(pendingKey(session.user.id), JSON.stringify(remaining)); setPending(remaining) } catch { /* Keep any recoverable reference if storage is unavailable. */ } }
      setMessage(e instanceof Error ? e.message : 'Could not start checkout.'); setBusy(false)
    }
  }

  if (!open) return null
  return <div className="partner-overlay" onMouseDown={event => { if (event.target === event.currentTarget && !busy) setOpen(false) }}>
    <section className="partner-modal" role="dialog" aria-modal="true" aria-labelledby="partner-title">
      <div className="partner-stripe"/><div className="partner-header"><div><p className="partner-eyebrow">NYANSA FOR INSTITUTIONS</p><h2 id="partner-title">Partner onboarding <em>& lead wallet.</em></h2><p>Connect with students who choose to hear from you.</p></div><button type="button" aria-label="Close partner onboarding" disabled={busy} onClick={() => setOpen(false)}>×</button></div>
      <div className="partner-tabs" role="tablist" aria-label="Partner sections">{([['application','Application'],['wallet','Lead wallet'],['consent','Student opt-in']] as [Tab,string][]).map(([id,label]) => <button key={id} type="button" role="tab" aria-selected={tab === id} className={tab === id ? 'active' : ''} onClick={() => { setTab(id); setMessage(''); setReceipt(null) }}>{label}</button>)}</div>
      <div className="partner-body">
        {mode === 'loading' && <p className="partner-banner">Loading your account…</p>}
        {mode === 'guest' && <div className="partner-banner"><strong>Sign in to continue</strong><p>Use your Supabase email account to submit an application, top up or opt in.</p><a href="/match">Sign in with email →</a></div>}
        {mode === 'error' && <div className="partner-banner"><strong>Partner data is unavailable</strong><p>Check the database setup and your connection, then try again.</p><button type="button" onClick={() => { setMessage(''); void load() }}>Retry →</button></div>}
        {message && <p className="partner-message" role="status">{message}</p>}
        {tab === 'application' && <>
          <div className="partner-section-title"><div><span>01 / GET STARTED</span><h3>Institution partner application</h3><p>Tell us who will manage admissions inquiries. Every application is reviewed by the Nyansa team before approval.</p></div><span className="partner-pill">{profile ? profile.status : 'REVIEW REQUIRED'}</span></div>
          {profile ? <div className="partner-application-summary"><b>{profile.institution_name}</b><p>{profile.institution_type} · {profile.official_email}</p><p>Billing: {profile.billing_method === 'prepaid' ? 'Prepaid Lead Wallet' : 'Institutional Invoice'} · Status: {profile.status}</p><small>Only the approved account owner can view its wallet and opted-in leads.</small></div> : <form onSubmit={submitApplication}><div className="partner-form-grid">
            <label>Institution name<input required minLength={2} maxLength={160} value={form.institution} onChange={e => setForm({ ...form, institution: e.target.value })} placeholder="Name of institution"/></label>
            <label>Institution type<select value={form.type} onChange={e => setForm({ ...form, type: e.target.value })}>{['Public university','Private university','Technical university','College of Education','Nursing training institution','Other'].map(t => <option key={t}>{t}</option>)}</select></label>
            <label>Admissions contact name<input required minLength={2} maxLength={120} value={form.contact} onChange={e => setForm({ ...form, contact: e.target.value })} placeholder="Full name"/></label>
            <label>Official email<input required type="email" maxLength={254} value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="admissions@institution.edu.gh"/></label>
            <label>Phone number<input required type="tel" minLength={5} maxLength={40} value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="024 123 4567"/></label>
            <label>Preferred billing method<select value={form.billing} onChange={e => setForm({ ...form, billing: e.target.value })}><option value="prepaid">Prepaid Lead Wallet via Paystack</option><option value="invoice">Institutional Invoice</option></select></label>
            <label>Accreditation details<input required minLength={3} maxLength={300} value={form.accreditation} onChange={e => setForm({ ...form, accreditation: e.target.value })} placeholder="e.g. GTEC accreditation number"/></label>
          </div><button className="partner-primary" disabled={busy || mode === 'loading'}>{busy ? 'Submitting…' : 'Submit Application'}</button><p className="partner-note">Your application stays pending until the Nyansa team approves it.</p></form>}
        </>}
        {tab === 'wallet' && <>
          <div className="partner-section-title"><div><span>02 / FOR APPROVED PARTNERS</span><h3>Partner lead wallet</h3><p>GHS 10 per opted-in lead. One credit is deducted when a student submits an opt-in.</p></div><span className="partner-pill">{profile?.status || 'APPLICATION REQUIRED'}</span></div>
          {profile?.status === 'approved' ? <div className="partner-balance"><div><span>AVAILABLE LEAD CREDITS</span><strong>{balance}</strong><p>{environment === 'test' ? 'Test credits use this same balance; use an isolated test project.' : 'One credit per submitted opt-in'}</p></div><div className="partner-balance-side">GHS 10 <small>per lead</small></div></div> : <div className="partner-wallet-locked"><b>Apply to access your wallet.</b><p>Sign in and submit an institution application before topping up or viewing leads.</p></div>}
          <div className="partner-bundle-head"><h4>Top up your wallet</h4><p>{environment === 'test' ? 'Use an isolated test project; test payments are not paid credits.' : 'Choose a bundle and pay with Paystack.'}</p><p>The payment service must verify the reference before the wallet and history are refreshed.</p></div><div className="partner-bundles">{([50,100,150] as Bundle[]).map(n => <div key={n}><span>LEAD BUNDLE</span><strong>{n} <small>leads</small></strong><p>{packs[n].price}</p><button type="button" disabled={busy || mode === 'loading'} onClick={() => void topUp(n)}>Top up →</button></div>)}</div>
          {receipt && <div className="partner-success" role="status"><strong>{receipt.environment === 'test' ? 'Test payment verified' : 'Payment verified'}</strong><p>{receipt.credits}-lead bundle · reference {receipt.reference}</p><p>Refreshed balance: {receipt.balance} credits{receipt.environment === 'test' ? ' · test transaction' : ''}.</p></div>}
          {history && <div className="partner-leads"><h4>Payment history <span>{history.length}</span></h4>{history.length ? history.map(payment => <article key={payment.reference}><strong>{payment.plan}</strong><span>{payment.currency} {(payment.amount/100).toLocaleString()}</span><span>{payment.reference}</span><small>{payment.status}</small></article>) : <div className="partner-empty">No payment history is available for this account.</div>}</div>}
          {profile?.status === 'approved' && <div className="partner-leads"><h4>Opted-in leads <span>{leads.length}</span></h4><p>Only students who explicitly opted in to your institution appear here.</p>{leads.length ? leads.map(lead => <article key={lead.id}><strong>{lead.student_name}</strong><span>{lead.programme_interest}</span><a href={`mailto:${lead.student_email}`}>{lead.student_email}</a><small>Submitted {new Date(lead.created_at).toLocaleDateString()}</small></article>) : <div className="partner-empty">No opted-in leads yet.</div>}</div>}
          {session && pending.length > 0 && <div className="partner-pending"><b>References awaiting verification</b><p>Keep a copy and retry verification before paying again.</p>{pending.map(item => <div key={item.reference}><span><strong>{item.credits} leads</strong><code>{item.reference}</code></span><button type="button" onClick={() => { if (!navigator.clipboard) { setMessage('Select and copy the reference manually.'); return } void navigator.clipboard.writeText(item.reference).then(() => setMessage('Reference copied.'), () => setMessage('Select and copy the reference manually.')) }}>Copy</button><button type="button" disabled={busy} onClick={() => void verifyTopUp(item, session)}>Retry verification</button></div>)}</div>}
        </>}
        {tab === 'consent' && <><div className="partner-section-title"><div><span>03 / STUDENT CHOICE</span><h3>Choose who can contact you</h3><p>Share your name, account email, interest and WASSCE aggregate with one approved institution. Nyansa verifies each opt-in before the institution sees it.</p></div></div><form onSubmit={shareLead}><div className="partner-form-grid"><label>WASSCE aggregate<input type="number" min={6} max={54} value={studentAggregate} onChange={e => setStudentAggregate(e.target.value)} placeholder="e.g. 12"/></label><label>Phone (optional)<input type="tel" maxLength={40} value={studentPhone} onChange={e => setStudentPhone(e.target.value)} placeholder="024 123 4567"/></label><label>Approved institution<select required value={selectedPartner} onChange={e => setSelectedPartner(e.target.value)}><option value="">Select an institution</option>{partners.map(p => <option key={p.id} value={p.id}>{p.institution_name} · {p.institution_type}</option>)}</select></label><label>Your name<input required minLength={2} maxLength={120} value={studentName} onChange={e => setStudentName(e.target.value)} placeholder="Full name"/></label><label className="partner-wide">Programme or career interest<input required minLength={2} maxLength={250} value={studentInterest} onChange={e => setStudentInterest(e.target.value)} placeholder="e.g. engineering, nursing, business"/></label></div>{partners.length === 0 && <p className="partner-note">{session ? 'No approved partners are currently available.' : 'Sign in to choose an approved partner.'}</p>}<label className="partner-consent"><input type="checkbox" required checked={consent} onChange={e => setConsent(e.target.checked)}/><span>I consent to sharing my name, account email and stated interest with the selected institution. My grades and financial details are not shared.</span></label><button className="partner-primary" disabled={busy || !partners.length}>{busy ? 'Saving…' : 'Submit consented request →'}</button><p className="partner-note">This is not an admission or scholarship application. Duplicate requests are not charged twice.</p></form></>}
      </div>
    </section>
  </div>
}
