import { useEffect, useState } from 'react'
import type { Session } from '@supabase/supabase-js'
import { cloud } from '../cloudProfile'

// UI visibility only. Real enforcement is the database policies in supabase/admin_panel.sql.
export const ADMIN_EMAIL = 'bomej51770@gmail.com'
export const isAdminSession = (session: Session | null) => (session?.user?.email || '').trim().toLowerCase() === ADMIN_EMAIL

export function useAdminSession() {
  const [session, setSession] = useState<Session | null>(null)
  const [ready, setReady] = useState(!cloud)
  useEffect(() => {
    if (!cloud) return
    let mounted = true
    cloud.auth.getSession().then(({ data }) => { if (mounted) { setSession(data.session); setReady(true) } })
    const { data } = cloud.auth.onAuthStateChange((_e, current) => { if (mounted) setSession(current) })
    return () => { mounted = false; data.subscription.unsubscribe() }
  }, [])
  return { session, ready, isAdmin: isAdminSession(session) }
}

export function useIsAdmin() { return useAdminSession().isAdmin }
