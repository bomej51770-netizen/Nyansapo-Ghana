import { useCallback, useEffect, useState } from 'react'
import { cloud } from '../cloudProfile'
import { useAdminSession } from './useIsAdmin'
import './admin.css'

type Tab = 'partners' | 'leads' | 'scholarships'
type Partner = { id: string; institution_name: string; institution_type: string; contact_name: string; official_email: string; phone: string; accreditation_details: string | null; status: string; lead_credits: number | null; created_at: string }
type Lead = { id: string; student_name: string; student_email: string; student_phone: string | null; wassce_aggregate: number | null; programme_interest: string; status: string; created_at: string; institution_partners: { institution_name: string } | null }
type Scholarship = { id: string; name: string; provider: string; coverage: string; application_window: string | null; deadline: string | null; link: string | null; created_at: string }

const msg = (e: unknown) => (e && typeof e === 'object' && 'message' in e && typeof e.message === 'string' ? e.message : 'Something went wrong.')
const emptyScholarship = { name: '', provider: '', coverage: '', application_window: '', deadline: '', link: '' }

export default function AdminPanel() {
  const { ready, isAdmin } = useAdminSession()
  const [tab, setTab] = useState<Tab>('partners')
  const [partners, setPartners] = useState<Partner[]>([])
  const [leads, setLeads] = useState<Lead[]>([])
  const [scholarships, setScholarships] = useState<Scholarship[]>([])
  const [notice, setNotice] = useState('')
  const [busy, setBusy] = useState('')
  const [form, setForm] = useState(emptyScholarship)
  const [editing, setEditing] = useState<Record<string, { deadline: string; application_window: string; coverage: string }>>({})

  const load = useCallback(async () => {
    if (!cloud) return
    const [p, l, s] = await Promise.all([
      cloud.from('institution_partners').select('id,institution_name,institution_type,contact_name,official_email,phone,accreditation_details,status,lead_credits,created_at').order('created_at', { ascending: false }),
      cloud.from('partner_leads').select('id,student_name,student_email,student_phone,wassce_aggregate,programme_interest,status,created_at,institution_partners(institution_name)').eq('status', 'pending_verification').order('created_at', { ascending: false }),
      cloud.from('scholarships').select('*').order('deadline', { ascending: true, nullsFirst: false }),
    ])
    const err = p.error || l.error || s.error
    if (err) setNotice(`Could not load everything: ${err.message}. Run supabase/admin_panel.sql if you have not yet.`)
    setPartners((p.data as Partner[]) || []); setLeads((l.data as unknown as Lead[]) || []); setScholarships((s.data as Scholarship[]) || [])
  }, [])
  useEffect(() => { if (isAdmin) load() }, [isAdmin, load])

  if (!ready) return <main className="db-main admin-page"><p>Loading…</p></main>
  if (!isAdmin) return <main className="db-main admin-page"><h1 className="admin-title">Page not found</h1><p><a href="/">Go home</a></p></main>

  const run = async (key: string, action: () => PromiseLike<{ error: { message: string } | null }>, ok: string) => {
    setBusy(key); setNotice('')
    try { const { error } = await action(); if (error) throw error; setNotice(ok); await load() } catch (e) { setNotice(msg(e)) } finally { setBusy('') }
  }
  const setPartnerStatus = (id: string, status: 'approved' | 'rejected') => run(id + status, () => cloud!.from('institution_partners').update({ status }).eq('id', id), `Institution ${status}.`)
  const verifyLead = (id: string) => run(id, () => cloud!.from('partner_leads').update({ status: 'verified' }).eq('id', id), 'Lead verified and released to the institution.')
  const addScholarship = (e: React.FormEvent) => {
    e.preventDefault()
    const row = { name: form.name.trim(), provider: form.provider.trim(), coverage: form.coverage.trim(), application_window: form.application_window.trim() || null, deadline: form.deadline || null, link: form.link.trim() || null }
    run('add', async () => { const r = await cloud!.from('scholarships').insert(row); if (!r.error) setForm(emptyScholarship); return r }, 'Scholarship added.')
  }
  const saveScholarship = (s: Scholarship) => {
    const v = editing[s.id]; if (!v) return
    run(s.id, async () => { const r = await cloud!.from('scholarships').update({ deadline: v.deadline || null, application_window: v.application_window.trim() || null, coverage: v.coverage.trim() }).eq('id', s.id); if (!r.error) setEditing(({ [s.id]: _, ...rest }) => rest); return r }, 'Scholarship updated.')
  }
  const counts = { pending: partners.filter(p => p.status === 'pending').length }

  return <main className="db-main admin-page">
    <div className="db-breadcrumb">NYANSA <span>/</span> ADMIN</div>
    <h1 className="admin-title">Admin control panel</h1>
    <div className="admin-tabs" role="tablist">
      <button role="tab" aria-selected={tab === 'partners'} onClick={() => setTab('partners')}>Partner applications {counts.pending > 0 && <span>{counts.pending}</span>}</button>
      <button role="tab" aria-selected={tab === 'leads'} onClick={() => setTab('leads')}>Lead verification {leads.length > 0 && <span>{leads.length}</span>}</button>
      <button role="tab" aria-selected={tab === 'scholarships'} onClick={() => setTab('scholarships')}>Scholarships</button>
    </div>
    {notice && <p className="admin-notice" role="status">{notice}</p>}

    {tab === 'partners' && <div className="admin-list">{partners.length === 0 && <p className="admin-empty">No institution applications yet.</p>}
      {partners.map(p => <article className="admin-card" key={p.id}>
        <div className="admin-card-head"><b>{p.institution_name}</b><span className={`admin-status ${p.status}`}>{p.status}</span></div>
        <p>{p.institution_type} · {p.contact_name}</p>
        <p><a href={`mailto:${p.official_email}`}>{p.official_email}</a> · {p.phone}</p>
        <p><small>Accreditation:</small> {p.accreditation_details || 'Not provided'}</p>
        <p><small>Lead credits:</small> {p.lead_credits ?? 0}</p>
        <div className="admin-actions">
          <button className="admin-approve" disabled={!!busy || p.status === 'approved'} onClick={() => setPartnerStatus(p.id, 'approved')}>Approve</button>
          <button className="admin-reject" disabled={!!busy || p.status === 'rejected'} onClick={() => setPartnerStatus(p.id, 'rejected')}>Reject</button>
        </div>
      </article>)}</div>}

    {tab === 'leads' && <div className="admin-list">{leads.length === 0 && <p className="admin-empty">No leads waiting for verification.</p>}
      {leads.map(l => <article className="admin-card" key={l.id}>
        <div className="admin-card-head"><b>{l.student_name}</b><span className="admin-status pending">pending verification</span></div>
        <p><small>Institution:</small> {l.institution_partners?.institution_name || '—'}</p>
        <p><small>WASSCE aggregate:</small> {l.wassce_aggregate ?? 'Not provided'}</p>
        <p><small>Interest:</small> {l.programme_interest}</p>
        <p><a href={`mailto:${l.student_email}`}>{l.student_email}</a>{l.student_phone ? ` · ${l.student_phone}` : ''}</p>
        <div className="admin-actions"><button className="admin-approve" disabled={!!busy} onClick={() => verifyLead(l.id)}>Verify & Release Lead</button></div>
      </article>)}</div>}

    {tab === 'scholarships' && <>
      <form className="admin-card admin-form" onSubmit={addScholarship}>
        <b>+ Add Scholarship</b>
        <div className="admin-form-grid">
          <label>Name<input required maxLength={200} value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></label>
          <label>Provider<input required maxLength={200} value={form.provider} onChange={e => setForm({ ...form, provider: e.target.value })} /></label>
          <label>Coverage<input required maxLength={300} value={form.coverage} onChange={e => setForm({ ...form, coverage: e.target.value })} placeholder="e.g. Full tuition + stipend" /></label>
          <label>Application window<input maxLength={120} value={form.application_window} onChange={e => setForm({ ...form, application_window: e.target.value })} placeholder="e.g. March – May" /></label>
          <label>Deadline<input type="date" value={form.deadline} onChange={e => setForm({ ...form, deadline: e.target.value })} /></label>
          <label>Link<input type="url" maxLength={500} value={form.link} onChange={e => setForm({ ...form, link: e.target.value })} placeholder="https://" /></label>
        </div>
        <button className="admin-approve" disabled={!!busy}>{busy === 'add' ? 'Adding…' : 'Add scholarship'}</button>
      </form>
      <div className="admin-list">{scholarships.length === 0 && <p className="admin-empty">No scholarships saved yet.</p>}
        {scholarships.map(s => { const e = editing[s.id]; return <article className="admin-card" key={s.id}>
          <div className="admin-card-head"><b>{s.name}</b><span>{s.provider}</span></div>
          {e ? <div className="admin-form-grid">
            <label>Deadline<input type="date" value={e.deadline} onChange={x => setEditing({ ...editing, [s.id]: { ...e, deadline: x.target.value } })} /></label>
            <label>Application window<input value={e.application_window} onChange={x => setEditing({ ...editing, [s.id]: { ...e, application_window: x.target.value } })} /></label>
            <label>Coverage<input required value={e.coverage} onChange={x => setEditing({ ...editing, [s.id]: { ...e, coverage: x.target.value } })} /></label>
          </div> : <>
            <p><small>Deadline:</small> {s.deadline || 'Not set'} · <small>Window:</small> {s.application_window || 'Not set'}</p>
            <p><small>Coverage:</small> {s.coverage}</p>
          </>}
          <div className="admin-actions">{e
            ? <><button className="admin-approve" disabled={!!busy} onClick={() => saveScholarship(s)}>Save</button><button className="admin-reject" onClick={() => setEditing(({ [s.id]: _, ...rest }) => rest)}>Cancel</button></>
            : <button className="admin-edit" onClick={() => setEditing({ ...editing, [s.id]: { deadline: s.deadline || '', application_window: s.application_window || '', coverage: s.coverage } })}>Edit deadline / window & coverage</button>}</div>
        </article> })}</div>
    </>}
  </main>
}
