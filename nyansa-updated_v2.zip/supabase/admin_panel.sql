-- Nyansa Admin Control Panel. Run once in the Supabase SQL editor (after the earlier partner scripts).
-- Admin = the signed-in account whose verified email is bomej51770@gmail.com. Enforced here, not just in the UI.

create or replace function public.nyansa_is_admin() returns boolean
language sql stable security definer set search_path = pg_catalog, public as $$
  select coalesce(lower(auth.jwt()->>'email') = 'bomej51770@gmail.com', false)
     and exists (select 1 from auth.users u where u.id = auth.uid() and u.email_confirmed_at is not null
                 and lower(u.email) = 'bomej51770@gmail.com')
$$;
revoke all on function public.nyansa_is_admin() from public, anon;
grant execute on function public.nyansa_is_admin() to authenticated;

-- 1. Institution applications: manual review only.
alter table public.institution_partners add column if not exists accreditation_details text;
grant insert (accreditation_details) on public.institution_partners to authenticated;
alter table public.institution_partners alter column status set default 'pending';
drop policy if exists "Insert own testing institution" on public.institution_partners;
drop policy if exists "Insert own pending institution" on public.institution_partners;
create policy "Insert own pending institution" on public.institution_partners for insert to authenticated
  with check (user_id = (select auth.uid()) and status = 'pending' and lead_credits = 0);

-- Admin can read every institution and change status only.
drop policy if exists "Restrict institution reads to owner" on public.institution_partners;
create policy "Restrict institution reads to owner" on public.institution_partners as restrictive for select to authenticated
  using (user_id = (select auth.uid()) or public.nyansa_is_admin());
drop policy if exists "Admin reads institutions" on public.institution_partners;
create policy "Admin reads institutions" on public.institution_partners for select to authenticated using (public.nyansa_is_admin());
grant update (status) on public.institution_partners to authenticated;
drop policy if exists "Admin reviews institutions" on public.institution_partners;
create policy "Admin reviews institutions" on public.institution_partners for update to authenticated
  using (public.nyansa_is_admin()) with check (public.nyansa_is_admin() and status in ('pending','approved','rejected'));

-- 2. Student leads: pending_verification until admin releases them.
alter table public.partner_leads add column if not exists wassce_aggregate integer check (wassce_aggregate between 6 and 54);
alter table public.partner_leads add column if not exists student_phone text check (length(student_phone) <= 40);
alter table public.partner_leads add column if not exists status text;
do $$ declare c record; begin
  for c in select conname from pg_constraint where conrelid = 'public.partner_leads'::regclass and contype = 'c' and pg_get_constraintdef(oid) ilike '%status%' loop
    execute format('alter table public.partner_leads drop constraint %I', c.conname);
  end loop;
end $$;
update public.partner_leads set status = 'verified' where status is null or status not in ('pending_verification','verified','rejected');
alter table public.partner_leads alter column status set default 'pending_verification';
alter table public.partner_leads alter column status set not null;
alter table public.partner_leads add constraint partner_leads_status_check check (status in ('pending_verification','verified','rejected'));
grant insert (wassce_aggregate, student_phone, status) on public.partner_leads to authenticated;
drop policy if exists "Insert own consented partner lead" on public.partner_leads;
create policy "Insert own consented partner lead" on public.partner_leads for insert to authenticated
  with check (student_user_id = (select auth.uid()) and status = 'pending_verification');

-- Institutions only see verified leads; students see their own; admin sees all.
drop policy if exists "Read own institution leads" on public.partner_leads;
create policy "Read own institution leads" on public.partner_leads for select to authenticated using (
  student_user_id = (select auth.uid()) or public.nyansa_is_admin()
  or (status = 'verified' and exists (select 1 from public.institution_partners p where p.id = partner_id and p.user_id = (select auth.uid()) and p.status = 'approved')));
drop policy if exists "Restrict lead reads to participants" on public.partner_leads;
create policy "Restrict lead reads to participants" on public.partner_leads as restrictive for select to authenticated using (
  student_user_id = (select auth.uid()) or public.nyansa_is_admin()
  or (status = 'verified' and exists (select 1 from public.institution_partners p where p.id = partner_id and p.user_id = (select auth.uid()) and p.status = 'approved')));
grant update (status) on public.partner_leads to authenticated;
drop policy if exists "Admin verifies leads" on public.partner_leads;
create policy "Admin verifies leads" on public.partner_leads for update to authenticated
  using (public.nyansa_is_admin()) with check (public.nyansa_is_admin());

-- 3. Scholarships: public read, admin write.
create table if not exists public.scholarships (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(name) between 2 and 200),
  provider text not null check (length(provider) between 2 and 200),
  coverage text not null check (length(coverage) between 2 and 300),
  application_window text check (length(application_window) <= 120),
  deadline date,
  link text check (link is null or link ~* '^https?://'),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select on public.scholarships to anon, authenticated;
grant insert, update, delete on public.scholarships to authenticated;
grant all on public.scholarships to service_role;
alter table public.scholarships enable row level security;
drop policy if exists "Anyone reads scholarships" on public.scholarships;
create policy "Anyone reads scholarships" on public.scholarships for select to anon, authenticated using (true);
drop policy if exists "Admin manages scholarships" on public.scholarships;
create policy "Admin manages scholarships" on public.scholarships for all to authenticated
  using (public.nyansa_is_admin()) with check (public.nyansa_is_admin());
